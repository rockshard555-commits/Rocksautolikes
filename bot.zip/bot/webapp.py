"""ROCKS AUTOLIKES — public Mini App web server (Flask).

Shares the exact same SQLite database as the bot (config.DB_PATH), so the bot
and the website are always twinned.

Everything under /, /app, /miniapp, /static/* and /api/public/* is PUBLIC —
no keys, no auth, no Forbidden. Only /api/dash/* is protected by the two-stage
owner password gate.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import time
from collections import defaultdict, deque
from functools import wraps
from urllib.parse import parse_qsl

from flask import Flask, Response, jsonify, render_template, request, send_from_directory

import config
import db
import likes as like_engine

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static"),
    static_url_path="/static",
)
app.config["JSON_SORT_KEYS"] = False
app.config["MAX_CONTENT_LENGTH"] = 256 * 1024  # tiny JSON bodies only

UID_RE = re.compile(r"^\d{6,14}$")
CODE_RE = re.compile(r"^[A-Za-z0-9_-]{3,32}$")


# ──────────────────────────── tiny TTL cache ────────────────────────────
_CACHE: dict[str, tuple[float, object]] = {}


def cached(key: str, ttl: float, producer):
    hit = _CACHE.get(key)
    now = time.time()
    if hit and now - hit[0] < ttl:
        return hit[1]
    val = producer()
    _CACHE[key] = (now, val)
    return val


# ──────────────────────────── rate limiting ────────────────────────────
_HITS: dict[str, deque] = defaultdict(deque)


def client_ip() -> str:
    fwd = request.headers.get("X-Forwarded-For", "")
    return (fwd.split(",")[0].strip() or request.remote_addr or "0.0.0.0")[:45]


def rate_limit(limit: int = 60, window: int = 60):
    def deco(fn):
        @wraps(fn)
        def inner(*a, **kw):
            bucket = _HITS[f"{fn.__name__}:{client_ip()}"]
            now = time.time()
            while bucket and now - bucket[0] > window:
                bucket.popleft()
            if len(bucket) >= limit:
                return jsonify({"ok": False, "error": "Tᴏᴏ ᴍᴀᴎʏ ʀᴇǫᴜᴇꜱᴛꜱ, ꜱʟᴏᴡ ᴅᴏᴡᴎ 🐢"}), 429
            bucket.append(now)
            return fn(*a, **kw)

        return inner

    return deco


# ──────────────────────────── security headers ────────────────────────────
CSP = (
    "default-src 'self'; "
    "img-src 'self' data: blob:; "
    "media-src 'self' data: blob:; "
    "style-src 'self' 'unsafe-inline'; "
    "script-src 'self' 'unsafe-inline' https://telegram.org https://*.telegram.org; "
    "connect-src 'self'; "
    "frame-ancestors *; "
    "base-uri 'self'; form-action 'self'"
)


@app.after_request
def _headers(resp: Response) -> Response:
    resp.headers["Content-Security-Policy"] = CSP
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    resp.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
    resp.headers["X-Robots-Tag"] = "index, follow"
    resp.headers.pop("Server", None)
    return resp


@app.errorhandler(404)
def _404(_e):
    if request.path.startswith("/api/"):
        return jsonify({"ok": False, "error": "Nᴏᴛ ꜰᴏᴜᴎᴅ"}), 404
    return render_template("miniapp.html", boot=_boot_payload()), 200


@app.errorhandler(500)
def _500(_e):
    return jsonify({"ok": False, "error": "Sᴇʀᴠᴇʀ ᴇʀʀᴏʀ, ᴛʀʏ ᴀɢᴀɪᴎ"}), 500


# ──────────────────────────── pages (all public) ────────────────────────────
def _boot_payload() -> str:
    return json.dumps(_public_config(), ensure_ascii=False)


@app.route("/")
@app.route("/app")
@app.route("/miniapp")
@app.route("/index.html")
def page_app():
    return render_template("miniapp.html", boot=_boot_payload())


@app.route("/favicon.ico")
def favicon():
    return send_from_directory(app.static_folder, "banner.jpg")


@app.route("/robots.txt")
def robots():
    return Response("User-agent: *\nAllow: /\n", mimetype="text/plain")


@app.route("/health")
def health():
    return jsonify({"ok": True, "service": "rocks-autolikes", "ts": int(time.time())})


# ──────────────────────────── public APIs ────────────────────────────
def _public_config() -> dict:
    return {
        "brand": "ROCKS AUTOLIKES",
        "owner": config.OWNER_HANDLE,
        "owner_url": config.OWNER_URL,
        "bot": f"https://t.me/{config.BOT_USERNAME}",
        "group": config.LOG_GROUP_LINK,
        "regions": [
            {"code": c, "name": m["name"], "flag": m["flag"]} for c, m in config.REGIONS.items()
        ],
        "plans": config.PLANS,
        "socials": config.SOCIALS,
        "ff": config.FF_PROFILE,
        "pay": {
            "upi_id": config.UPI_ID,
            "upi_name": config.UPI_NAME,
            "usdt_address": config.USDT_ADDRESS,
            "usdt_network": config.USDT_NETWORK,
        },
        "runs_per_day": config.MAX_AUTOLIKE_RUNS,
        "refer": {
            "credit_per_invite": config.REFER_CREDIT_PER_INVITE,
            "credits_per_1k": config.CREDITS_PER_1K_LIKES,
            "unit": config.CREDIT_REDEEM_UNIT,
            "unit_likes": config.LIKES_PER_CREDIT_UNIT,
        },

    }


@app.route("/api/public/config")
@rate_limit(120, 60)
def api_config():
    return jsonify({"ok": True, "data": cached("cfg", 300, _public_config)})


@app.route("/api/public/stats")
@rate_limit(120, 60)
def api_stats():
    data = cached("stats", 10, db.totals)
    return jsonify({"ok": True, "data": data})


@app.route("/api/public/buyers")
@rate_limit(120, 60)
def api_buyers():
    rows = cached("buyers", 15, lambda: [dict(r) for r in db.live_buyers(30)])
    out = []
    for r in rows:
        nick = (r.get("nickname") or "Pʟᴀʏᴇʀ").strip()
        uid = str(r.get("uid") or "")
        out.append({
            "nickname": nick,
            "uid": (uid[:4] + "•••" + uid[-3:]) if len(uid) > 8 else uid,
            "region": (r.get("region") or "IND").upper(),
            "likes": int(r.get("likes") or 0),
            "at": int(r.get("created_at") or 0),
        })
    return jsonify({"ok": True, "data": out})


@app.route("/api/public/info")
@rate_limit(30, 60)
def api_info():
    uid = (request.args.get("uid") or "").strip()
    region = (request.args.get("region") or "").strip().upper()
    if not UID_RE.match(uid):
        return jsonify({"ok": False, "error": "Eᴎᴛᴇʀ ᴀ ᴠᴀʟɪᴅ ᴜɪᴅ (6-14 ᴅɪɢɪᴛꜱ) 🔢"}), 400
    if region not in config.REGIONS:
        return jsonify({"ok": False, "error": "Pɪᴄᴋ ᴀ ᴠᴀʟɪᴅ ʀᴇɢɪᴏᴎ 🌍"}), 400

    def fetch():
        return like_engine.get_info(uid, region)

    data = cached(f"info:{region}:{uid}", 60, fetch)
    if not data.get("ok"):
        return jsonify({"ok": False, "error": "Pʟᴀʏᴇʀ ᴎᴏᴛ ꜰᴏᴜᴎᴅ ᴏʀ ᴀᴘɪ ʙᴜꜱʏ 😔"}), 404
    meta = config.REGIONS.get(data.get("region", region), config.REGIONS[region])
    return jsonify({
        "ok": True,
        "data": {
            "uid": data["uid"],
            "nickname": data["nickname"],
            "level": data["level"],
            "likes": data["likes"],
            "region": data.get("region", region),
            "region_name": meta["name"],
            "region_flag": meta["flag"],
            "guild": data.get("guild", ""),
            "bio": data.get("bio", ""),
            "br_rank": data.get("br_rank", 0),
            "cs_rank": data.get("cs_rank", 0),
        },
    })


# ──────────────────────────── chatbot ────────────────────────────
FAQ = [
    (("buy", "purchase", "order", "kaise", "how to buy"),
     "🛒 Oᴘᴇᴎ ᴛʜᴇ Bᴜʏ ᴛᴀʙ, ᴘɪᴄᴋ ᴀ ᴘʟᴀᴎ, ᴛʜᴇᴎ ᴘᴀʏ ʙʏ UPI 🇮🇳, USDT BEP20 💵 ᴏʀ Tᴇʟᴇɢʀᴀᴍ Sᴛᴀʀꜱ ⭐. "
     f"Sᴇᴎᴅ ᴛʜᴇ ꜱᴄʀᴇᴇᴎꜱʜᴏᴛ + ᴛxɴ ɪᴅ ᴛᴏ {config.OWNER_HANDLE} ᴀᴎᴅ ʟɪᴋᴇꜱ ᴀʀᴇ ᴀᴅᴅᴇᴅ ɪᴎꜱᴛᴀᴎᴛʟʏ ⚡"),
    (("price", "cost", "plan", "rate", "₹", "rupee", "dollar", "star"),
     "💰 Pʟᴀᴎꜱ ꜱᴛᴀʀᴛ ᴀᴛ 5,000 ʟɪᴋᴇꜱ ꜰᴏʀ ₹111 / $2 / 33 ⭐ ᴀᴎᴅ ɢᴏ ᴜᴘ ᴛᴏ 100,000 ʟɪᴋᴇꜱ ꜰᴏʀ ₹2222 / $40 / 888 ⭐. "
     "Cʜᴇᴄᴋ ᴛʜᴇ Bᴜʏ ᴛᴀʙ ꜰᴏʀ ᴛʜᴇ ꜰᴜʟʟ ʟɪꜱᴛ 📋"),
    (("time", "delivery", "how long", "fast", "speed"),
     "⏱️ Lɪᴋᴇꜱ ꜱᴛᴀʀᴛ ꜰʟᴏᴡɪᴎɢ ᴡɪᴛʜɪᴎ ᴀ ꜰᴇᴡ ᴍɪᴎᴜᴛᴇꜱ ᴀᴎᴅ ᴀᴜᴛᴏʟɪᴋᴇ ᴋᴇᴇᴘꜱ ʀᴜᴎᴎɪᴎɢ ᴅᴀɪʟʏ ᴜᴘ ᴛᴏ 11 ᴛɪᴍᴇꜱ ᴀ ᴅᴀʏ 🔁"),
    (("region", "server", "country"),
     "🌍 Sᴜᴘᴘᴏʀᴛᴇᴅ ʀᴇɢɪᴏᴎꜱ: " + " • ".join(config.REGIONS.keys()) + " — ᴘɪᴄᴋ ʏᴏᴜʀꜱ ɪᴎ ᴛʜᴇ Cʜᴇᴄᴋ ᴛᴀʙ 🔎"),
    (("refund", "money back", "scam"),
     "🛡️ Iꜰ ʟɪᴋᴇꜱ ᴀʀᴇ ᴎᴏᴛ ᴅᴇʟɪᴠᴇʀᴇᴅ, ᴄᴏᴎᴛᴀᴄᴛ ᴛʜᴇ ᴏᴡᴎᴇʀ ᴡɪᴛʜ ʏᴏᴜʀ ᴛxɴ ɪᴅ — ʀᴇꜰᴜᴎᴅ ᴏʀ ʀᴇ-ᴅᴇʟɪᴠᴇʀʏ ɪꜱ ɢᴜᴀʀᴀᴎᴛᴇᴇᴅ ✅"),
    (("refer", "credit", "redeem", "code"),
     f"🎁 Iᴎᴠɪᴛᴇ ꜰʀɪᴇᴎᴅꜱ — ʙᴏᴛʜ ꜱɪᴅᴇꜱ ɢᴇᴛ {config.REFER_CREDIT_PER_INVITE} ᴄʀᴇᴅɪᴛ. "
     f"{config.CREDITS_PER_1K_LIKES} ᴄʀᴇᴅɪᴛꜱ = 1,000 ꜰʀᴇᴇ ʟɪᴋᴇꜱ 🔥 Rᴇᴅᴇᴇᴍ ɪᴎ ᴛʜᴇ Rᴇꜰᴇʀ ᴛᴀʙ"),
    (("contact", "owner", "admin", "support", "help", "dm"),
     f"👑 Oᴡᴎᴇʀ: {config.OWNER_HANDLE} — ᴛᴀᴘ ᴛʜᴇ Cᴏᴎᴛᴀᴄᴛ Oᴡᴎᴇʀ ʙᴜᴛᴛᴏᴎ ᴀᴎʏᴡʜᴇʀᴇ ɪᴎ ᴛʜᴇ ᴀᴘᴘ 💬"),
    (("safe", "ban", "risk"),
     "🔒 Lɪᴋᴇꜱ ᴀʀᴇ 100% ꜱᴀꜰᴇ — ᴎᴏ ʟᴏɢɪᴎ, ᴎᴏ ᴘᴀꜱꜱᴡᴏʀᴅ, ᴏᴎʟʏ ʏᴏᴜʀ UID ɪꜱ ᴎᴇᴇᴅᴇᴅ 🙌"),
    (("bot", "telegram", "command"),
     f"🤖 Uꜱᴇ ᴛʜᴇ ʙᴏᴛ: https://t.me/{config.BOT_USERNAME} — /ʜᴇʟᴘ ꜰᴏʀ ᴜꜱᴇʀ ᴄᴏᴍᴍᴀᴎᴅꜱ, /ɪᴎꜰᴏ ʀᴇɢɪᴏᴎ ᴜɪᴅ ꜰᴏʀ ᴘʟᴀʏᴇʀ ʟᴏᴏᴋᴜᴘ 📲"),
]

FALLBACK = ("🤖 I ᴄᴀᴎ ʜᴇʟᴘ ᴡɪᴛʜ: ʙᴜʏɪᴎɢ ʟɪᴋᴇꜱ 🛒, ᴘʟᴀᴎꜱ & ᴘʀɪᴄᴇꜱ 💰, ᴅᴇʟɪᴠᴇʀʏ ᴛɪᴍᴇ ⏱️, ʀᴇɢɪᴏᴎꜱ 🌍, "
            f"ʀᴇꜰᴇʀʀᴀʟꜱ 🎁 ᴀᴎᴅ ꜱᴜᴘᴘᴏʀᴛ 💬. Aꜱᴋ ᴀᴡᴀʏ, ᴏʀ ᴅᴍ {config.OWNER_HANDLE} 👑")


@app.route("/api/public/chat", methods=["POST"])
@rate_limit(40, 60)
def api_chat():
    body = request.get_json(silent=True) or {}
    msg = str(body.get("message") or "")[:400].lower()
    if not msg.strip():
        return jsonify({"ok": True, "reply": FALLBACK})
    for keys, reply in FAQ:
        if any(k in msg for k in keys):
            return jsonify({"ok": True, "reply": reply})
    return jsonify({"ok": True, "reply": FALLBACK})


# ──────────────────────────── telegram initData ────────────────────────────
def verify_init_data(init_data: str) -> dict | None:
    if not init_data or not config.BOT_TOKEN:
        return None
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True))
        got = pairs.pop("hash", "")
        check = "\n".join(f"{k}={pairs[k]}" for k in sorted(pairs))
        secret = hmac.new(b"WebAppData", config.BOT_TOKEN.encode(), hashlib.sha256).digest()
        calc = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calc, got):
            return None
        if time.time() - int(pairs.get("auth_date", "0")) > 86400:
            return None
        return json.loads(pairs.get("user", "{}"))
    except Exception:  # noqa: BLE001
        return None


@app.route("/api/me", methods=["POST"])
@rate_limit(60, 60)
def api_me():
    body = request.get_json(silent=True) or {}
    user = verify_init_data(str(body.get("initData") or ""))
    if not user or not user.get("id"):
        return jsonify({"ok": False, "error": "Oᴘᴇᴎ ᴛʜʀᴏᴜɢʜ ᴛʜᴇ Tᴇʟᴇɢʀᴀᴍ ʙᴏᴛ ᴛᴏ ꜱᴇᴇ ʏᴏᴜʀ ᴀᴄᴄᴏᴜᴎᴛ 🤖"}), 401
    uid = int(user["id"])
    db.upsert_user(uid, user.get("username", ""), user.get("first_name", ""))
    row = db.get_user(uid) or {}
    return jsonify({"ok": True, "data": {
        "user_id": uid,
        "first_name": user.get("first_name", ""),
        "username": user.get("username", ""),
        "credits": int(row["credits"] or 0) if row else 0,
        "likes_balance": int(row["likes_balance"] or 0) if row else 0,
        "refer_count": int(row["refer_count"] or 0) if row else 0,
        "is_admin": uid in config.ADMIN_IDS,
        "refer_link": f"https://t.me/{config.BOT_USERNAME}?start=ref{uid}",
    }})


@app.route("/api/redeem", methods=["POST"])
@rate_limit(10, 60)
def api_redeem():
    body = request.get_json(silent=True) or {}
    user = verify_init_data(str(body.get("initData") or ""))
    if not user or not user.get("id"):
        return jsonify({"ok": False, "error": "Oᴘᴇᴎ ᴛʜʀᴏᴜɢʜ Tᴇʟᴇɢʀᴀᴍ ᴛᴏ ʀᴇᴅᴇᴇᴍ 🤖"}), 401
    code = str(body.get("code") or "").strip()
    if not CODE_RE.match(code):
        return jsonify({"ok": False, "error": "Iᴎᴠᴀʟɪᴅ ᴄᴏᴅᴇ ꜰᴏʀᴍᴀᴛ ❌"}), 400
    uid = int(user["id"])
    row = db.one("SELECT * FROM refer_codes WHERE code=?", (code,))
    if not row:
        return jsonify({"ok": False, "error": "Cᴏᴅᴇ ᴎᴏᴛ ꜰᴏᴜᴎᴅ ❌"}), 404
    if row["valid_till"] and int(row["valid_till"]) < db.ts():
        return jsonify({"ok": False, "error": "Cᴏᴅᴇ ᴇxᴘɪʀᴇᴅ ⌛"}), 400
    if int(row["used"] or 0) >= int(row["max_redeems"] or 0):
        return jsonify({"ok": False, "error": "Cᴏᴅᴇ ꜰᴜʟʟʏ ᴜꜱᴇᴅ 🚫"}), 400
    if db.one("SELECT 1 FROM redemptions WHERE code=? AND user_id=?", (code, uid)):
        return jsonify({"ok": False, "error": "Yᴏᴜ ᴀʟʀᴇᴀᴅʏ ʀᴇᴅᴇᴇᴍᴇᴅ ᴛʜɪꜱ ᴄᴏᴅᴇ 🙃"}), 400
    db.run("INSERT INTO redemptions(code,user_id,created_at) VALUES(?,?,?)", (code, uid, db.ts()))
    db.run("UPDATE refer_codes SET used=used+1 WHERE code=?", (code,))
    db.add_credits(uid, int(row["credits"] or 0))
    return jsonify({"ok": True, "credits": int(row["credits"] or 0)})


# ──────────────────────────── buyer key login ────────────────────────────
KEY_RE = re.compile(r"^[A-Za-z0-9_-]{4,40}$")


def _key_row(code: str):
    if not KEY_RE.match(code or ""):
        return None
    row = db.one("SELECT * FROM keys WHERE code=?", (code,))
    if not row or not int(row["active"] or 0):
        return None
    if row["expires_at"] and int(row["expires_at"]) < db.ts():
        return None
    return row


def _key_payload(row) -> dict:
    code = row["code"]
    slots = [dict(r) for r in db.q(
        "SELECT id,uid,region,nickname,likes_target,likes_left,likes_sent,paused,created_at,last_run_at,expires_at "
        "FROM autolikes WHERE key_code=? ORDER BY id DESC", (code,))]
    uids = [s["uid"] for s in slots]
    history = []
    if uids:
        marks = ",".join("?" * len(uids))
        history = [dict(r) for r in db.q(
            f"SELECT uid,region,nickname,likes_before,likes_after,given,kind,created_at "
            f"FROM like_logs WHERE uid IN ({marks}) ORDER BY id DESC LIMIT 60", tuple(uids))]
    for s in slots:
        meta = config.REGIONS.get((s["region"] or "").upper(), {})
        s["region_flag"] = meta.get("flag", "🌍")
        s["region_name"] = meta.get("name", s["region"])
    return {
        "code": code,
        "likes_total": int(row["likes_total"] or 0),
        "likes_left": int(row["likes_left"] or 0),
        "expires_at": int(row["expires_at"] or 0),
        "created_at": int(row["created_at"] or 0),
        "runs_per_day": config.MAX_AUTOLIKE_RUNS,
        "slots": slots,
        "history": history,
    }


@app.route("/api/key/login", methods=["POST"])
@rate_limit(20, 60)
def api_key_login():
    body = request.get_json(silent=True) or {}
    row = _key_row(str(body.get("code") or "").strip())
    if not row:
        return jsonify({"ok": False, "error": "Kᴇʏ ᴎᴏᴛ ꜰᴏᴜᴎᴅ, ᴇxᴘɪʀᴇᴅ ᴏʀ ᴅɪꜱᴀʙʟᴇᴅ 🔒"}), 401
    return jsonify({"ok": True, "data": _key_payload(row)})


@app.route("/api/key/toggle", methods=["POST"])
@rate_limit(30, 60)
def api_key_toggle():
    body = request.get_json(silent=True) or {}
    row = _key_row(str(body.get("code") or "").strip())
    if not row:
        return jsonify({"ok": False, "error": "Kᴇʏ ᴎᴏᴛ ᴠᴀʟɪᴅ 🔒"}), 401
    try:
        slot_id = int(body.get("id") or 0)
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "Bᴀᴅ ꜱʟᴏᴛ ❌"}), 400
    slot = db.one("SELECT * FROM autolikes WHERE id=? AND key_code=?", (slot_id, row["code"]))
    if not slot:
        return jsonify({"ok": False, "error": "Sʟᴏᴛ ᴎᴏᴛ ꜰᴏᴜᴎᴅ ❌"}), 404
    action = str(body.get("action") or "toggle").lower()
    if action == "stop":
        left = int(slot["likes_left"] or 0)
        db.run("DELETE FROM autolikes WHERE id=?", (slot_id,))
        if left > 0:
            db.run("UPDATE keys SET likes_left=likes_left+? WHERE code=?", (left, row["code"]))
    else:
        paused = 0 if int(slot["paused"] or 0) else 1
        db.run("UPDATE autolikes SET paused=? WHERE id=?", (paused, slot_id))
    return jsonify({"ok": True, "data": _key_payload(_key_row(row["code"]))})


@app.route("/api/key/split", methods=["POST"])
@rate_limit(20, 60)
def api_key_split():
    body = request.get_json(silent=True) or {}
    row = _key_row(str(body.get("code") or "").strip())
    if not row:
        return jsonify({"ok": False, "error": "Kᴇʏ ᴎᴏᴛ ᴠᴀʟɪᴅ 🔒"}), 401
    uid = str(body.get("uid") or "").strip()
    region = str(body.get("region") or "").strip().upper()
    try:
        likes = int(body.get("likes") or 0)
    except (TypeError, ValueError):
        likes = 0
    if not UID_RE.match(uid):
        return jsonify({"ok": False, "error": "Eᴎᴛᴇʀ ᴀ ᴠᴀʟɪᴅ ᴜɪᴅ 🔢"}), 400
    if region not in config.REGIONS:
        return jsonify({"ok": False, "error": "Pɪᴄᴋ ᴀ ᴠᴀʟɪᴅ ʀᴇɢɪᴏᴎ 🌍"}), 400
    left = int(row["likes_left"] or 0)
    if likes < 100 or likes > left:
        return jsonify({"ok": False, "error": f"Eᴎᴛᴇʀ 100 ᴛᴏ {left:,} ʟɪᴋᴇꜱ 📉"}), 400

    info = like_engine.get_info(uid, region)
    nick = info.get("nickname", "") if info.get("ok") else ""
    exist = db.one("SELECT * FROM autolikes WHERE uid=? AND region=?", (uid, region))
    if exist:
        if (exist["key_code"] or "") != row["code"]:
            return jsonify({"ok": False, "error": "Tʜᴀᴛ ᴜɪᴅ ɪꜱ ᴀʟʀᴇᴀᴅʏ ʀᴜᴎᴎɪᴎɢ ᴜᴎᴅᴇʀ ᴀᴎᴏᴛʜᴇʀ ᴋᴇʏ 🚫"}), 400
        db.run("UPDATE autolikes SET likes_left=likes_left+?, likes_target=likes_target+?, paused=0 WHERE id=?",
               (likes, likes, exist["id"]))
    else:
        db.run(
            "INSERT INTO autolikes(uid,region,nickname,key_code,likes_target,likes_left,created_at) "
            "VALUES(?,?,?,?,?,?,?)",
            (uid, region, nick, row["code"], likes, likes, db.ts()),
        )
    db.run("UPDATE keys SET likes_left=likes_left-? WHERE code=?", (likes, row["code"]))
    return jsonify({"ok": True, "data": _key_payload(_key_row(row["code"]))})


# ──────────────────────────── owner dashboard ────────────────────────────
_TOKENS: dict[str, float] = {}
TOKEN_TTL = 3600


def _issue_token() -> str:
    tok = secrets.token_urlsafe(32)
    now = time.time()
    for t, exp in list(_TOKENS.items()):
        if exp < now:
            _TOKENS.pop(t, None)
    _TOKENS[tok] = now + TOKEN_TTL
    return tok


def require_dash(fn):
    @wraps(fn)
    def inner(*a, **kw):
        tok = request.headers.get("X-Dash-Token", "") or (request.get_json(silent=True) or {}).get("token", "")
        exp = _TOKENS.get(str(tok))
        if not exp or exp < time.time():
            return jsonify({"ok": False, "error": "Uᴎᴀᴜᴛʜᴏʀɪꜱᴇᴅ 🔒"}), 401
        return fn(*a, **kw)

    return inner


@app.route("/api/dash/login", methods=["POST"])
@rate_limit(8, 300)
def dash_login():
    body = request.get_json(silent=True) or {}
    p1 = str(body.get("pass1") or "")
    p2 = str(body.get("pass2") or "")
    ok1 = hmac.compare_digest(p1, config.DASH_PASS_1)
    ok2 = hmac.compare_digest(p2, config.DASH_PASS_2)
    time.sleep(0.35)  # slow brute force
    if not (ok1 and ok2):
        return jsonify({"ok": False, "error": "Wʀᴏᴎɢ ᴘᴀꜱꜱᴡᴏʀᴅ 🚫"}), 401
    return jsonify({"ok": True, "token": _issue_token(), "ttl": TOKEN_TTL})


@app.route("/api/dash/analytics")
@require_dash
def dash_analytics():
    rng = (request.args.get("range") or "week").lower()
    if rng not in ("day", "week", "month", "quarter", "half", "year"):
        rng = "week"
    return jsonify({"ok": True, "data": db.analytics(rng), "totals": db.totals()})


@app.route("/api/dash/tables")
@require_dash
def dash_tables():
    def rows(sql, args=()):
        return [dict(r) for r in db.q(sql, args)]

    return jsonify({"ok": True, "data": {
        "users": rows("SELECT user_id,username,first_name,credits,likes_balance,refer_count,total_likes,joined_at "
                      "FROM users ORDER BY joined_at DESC LIMIT 100"),
        "autolikes": rows("SELECT uid,region,nickname,likes_target,likes_left,likes_sent,paused,expires_at "
                          "FROM autolikes ORDER BY id DESC LIMIT 100"),
        "purchases": rows("SELECT id,username,uid,region,likes,amount,currency,method,status,created_at "
                          "FROM purchases ORDER BY id DESC LIMIT 100"),
        "keys": rows("SELECT code,likes_total,likes_left,bound_user,active,expires_at FROM keys ORDER BY rowid DESC LIMIT 100"),
        "apis": rows("SELECT id,url,kind,enabled,ok_count,fail_count FROM apis ORDER BY position, id"),
        "groups": rows("SELECT id,link,chat_id,title,required FROM groups ORDER BY id"),
        "logs": rows("SELECT uid,region,nickname,likes_before,likes_after,given,kind,created_at "
                     "FROM like_logs ORDER BY id DESC LIMIT 100"),
    }})


def create_app() -> Flask:
    db.init()
    return app


if __name__ == "__main__":
    create_app()
    app.run(host="0.0.0.0", port=config.PORT, debug=False)
