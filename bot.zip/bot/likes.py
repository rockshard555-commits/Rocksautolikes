"""ROCKS AUTOLIKES — like + info engine (shared by the bot and the mini app).

APIs are never named in output. They are exposed as V1, V2, V3 … and a source
that errors or delivers 0 likes is simply not shown.
"""
import concurrent.futures
import re
import time

import requests

import db

TIMEOUT = 12
HEADERS = {"User-Agent": "RocksAutolikes/4.0", "Accept": "application/json, text/plain, */*"}

_NUM = re.compile(r"-?\d+")


def _first(d: dict, *keys, default=None):
    low = {str(k).lower().replace(" ", "").replace("_", ""): v for k, v in d.items()}
    for k in keys:
        kk = k.lower().replace(" ", "").replace("_", "")
        if kk in low and low[kk] not in (None, ""):
            return low[kk]
    return default


def _to_int(v, default=0):
    if v is None:
        return default
    if isinstance(v, bool):
        return default
    if isinstance(v, (int, float)):
        return int(v)
    m = _NUM.search(str(v).replace(",", ""))
    return int(m.group()) if m else default


def _flatten(obj) -> dict:
    """Flatten one level of nested dicts so different API shapes look alike."""
    out = {}
    if not isinstance(obj, dict):
        return out
    for k, v in obj.items():
        if isinstance(v, dict):
            for k2, v2 in v.items():
                out.setdefault(str(k2), v2)
            out.setdefault(str(k), v)
        else:
            out[str(k)] = v
    return out


# ───────────────────────────── INFO ─────────────────────────────
def get_info(uid: str, region: str = "IND") -> dict:
    """Try info API 1 (needs region), then API 2 (region ignored)."""
    uid = str(uid).strip()
    region = (region or "IND").upper()
    last_err = "ᴜᴎᴋᴎᴏᴡᴎ"
    for api in db.info_apis():
        url = (api["url"].replace("{UID}", uid).replace("{uid}", uid)
               .replace("{REGION}", region).replace("{region}", region)
               .replace("{server_name}", region))
        try:
            r = requests.get(url, timeout=TIMEOUT, headers=HEADERS)
            if r.status_code != 200:
                last_err = f"HTTP {r.status_code}"
                db.bump_api(api["id"], False)
                continue
            data = r.json()
            flat = _flatten(data if isinstance(data, dict) else {"data": data})
            name = _first(flat, "nickname", "playerNickname", "name", "AccountName", "player_name")
            if not name:
                db.bump_api(api["id"], False)
                last_err = "ᴎᴏ ᴅᴀᴛᴀ"
                continue
            db.bump_api(api["id"], True)
            return {
                "ok": True,
                "uid": uid,
                "region": (_first(flat, "region", "server", "AccountRegion", default=region) or region).upper(),
                "nickname": str(name),
                "level": _to_int(_first(flat, "level", "AccountLevel", "playerLevel"), 0),
                "likes": _to_int(_first(flat, "likes", "AccountLikes", "player_likes"), 0),
                "exp": _to_int(_first(flat, "exp", "AccountEXP"), 0),
                "bio": str(_first(flat, "signature", "bio", default="") or ""),
                "guild": str(_first(flat, "guildName", "clanName", "GuildName", default="") or ""),
                "created": str(_first(flat, "createAt", "AccountCreateTime", "created_at", default="") or ""),
                "last_login": str(_first(flat, "lastLoginAt", "AccountLastLogin", default="") or ""),
                "br_rank": _to_int(_first(flat, "brRankPoint", "BrRankPoint"), 0),
                "cs_rank": _to_int(_first(flat, "csRankPoint", "CsRankPoint"), 0),
                "raw": flat,
            }
        except Exception as e:  # noqa: BLE001
            last_err = type(e).__name__
            db.bump_api(api["id"], False)
            continue
    return {"ok": False, "uid": uid, "region": region, "error": last_err}


# ───────────────────────────── LIKES ─────────────────────────────
def _call_like(api: dict, uid: str, region: str) -> dict:
    url = (api["url"].replace("{uid}", uid).replace("{UID}", uid)
           .replace("{player_uid}", uid)
           .replace("{region}", region).replace("{REGION}", region)
           .replace("{server_name}", region).replace("{server}", region))
    try:
        r = requests.get(url, timeout=TIMEOUT, headers=HEADERS)
        if r.status_code != 200:
            db.bump_api(api["id"], False)
            return {"ok": False, "given": 0}
        try:
            data = r.json()
        except Exception:
            db.bump_api(api["id"], False)
            return {"ok": False, "given": 0}
        flat = _flatten(data if isinstance(data, dict) else {"data": data})
        before = _to_int(_first(flat, "LikesbeforeCommand", "likes_before", "before", "PreviousLikes"), 0)
        after = _to_int(_first(flat, "LikesafterCommand", "likes_after", "after", "NewLikes"), 0)
        given = _to_int(_first(flat, "LikesGivenByAPI", "likes_given", "givenLikes", "added"), 0)
        if not given and after and before:
            given = max(0, after - before)
        status = str(_first(flat, "status", "message", default="") or "").lower()
        nickname = _first(flat, "PlayerNickname", "nickname", "name", default="")
        already = ("already" in status) or (before and after and after == before)
        db.bump_api(api["id"], given > 0)
        return {"ok": given > 0, "given": given, "before": before, "after": after,
                "nickname": nickname, "already": bool(already)}
    except Exception:
        db.bump_api(api["id"], False)
        return {"ok": False, "given": 0}


def send_likes(uid: str, region: str, target: int = 100, max_workers: int = 8,
               on_progress=None) -> dict:
    """Hit every enabled like source until `target` likes are delivered.

    `on_progress(state)` fires on every real step (player lookup, each source
    that answers, final verification) so the caller can render a live percent
    instead of a frozen 10% bar. Only sources that actually delivered likes
    are returned, always as V1/V2/V3 …
    """
    uid = str(uid).strip()
    region = (region or "IND").upper()
    apis = db.like_apis()
    total_steps = len(apis) + 2  # lookup + each source + verify

    state = {"stage": "lookup", "pct": 0.0, "done": 0, "total": len(apis),
             "likes": 0, "nickname": ""}

    def emit(**kw):
        state.update(kw)
        if on_progress:
            try:
                on_progress(dict(state))
            except Exception:
                pass

    emit(stage="lookup", pct=100.0 / total_steps)

    info_before = get_info(uid, region)
    nickname = info_before.get("nickname") or "Unknown"
    before = info_before.get("likes") or 0
    emit(stage="sending", nickname=nickname, pct=100.0 / total_steps)

    sources, already, total = [], [], 0
    started = time.time()
    finished = 0

    def worker(idx_api):
        idx, api = idx_api
        return idx, api, _call_like(api, uid, region)

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = [pool.submit(worker, (i + 1, a)) for i, a in enumerate(apis)]
        for fut in concurrent.futures.as_completed(futures):
            try:
                idx, api, res = fut.result()
            except Exception:
                finished += 1
                emit(done=finished, pct=100.0 * (finished + 1) / total_steps)
                continue
            if res.get("given", 0) > 0:
                sources.append({"v": f"V{idx}", "given": res["given"]})
                total += res["given"]
            elif res.get("already"):
                already.append(f"V{idx}")
            finished += 1
            emit(stage="sending", done=finished, likes=total,
                 pct=100.0 * (finished + 1) / total_steps)
            if total >= target:
                for f in futures:
                    f.cancel()
                break

    emit(stage="verify", pct=100.0 * (total_steps - 0.4) / total_steps)
    info_after = get_info(uid, region)
    after = info_after.get("likes") or (before + total)
    if before and after and after > before:
        total = max(total, after - before)
    emit(stage="done", pct=100.0, likes=total)

    sources.sort(key=lambda s: int(s["v"][1:]))
    return {
        "ok": True,
        "uid": uid,
        "region": region,
        "nickname": info_after.get("nickname") or nickname,
        "level": info_after.get("level") or info_before.get("level") or 0,
        "before": before,
        "after": after,
        "given": total,
        "sources": sources,
        "already": already,
        "took": round(time.time() - started, 1),
        "api_total": len(apis),
        "info": info_after if info_after.get("ok") else info_before,
    }

