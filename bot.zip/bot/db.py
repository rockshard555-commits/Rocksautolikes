"""ROCKS AUTOLIKES — single SQLite database shared by the bot and the mini app.

Every query is parameterised (no SQL injection surface). WAL mode + a lock keep
the bot thread and the web threads safe inside the one Wispbyte process.
"""
import json
import os
import sqlite3
import threading
import time
from datetime import datetime, timedelta, timezone

import config

_LOCK = threading.RLock()
_LOCAL = threading.local()

IST = timezone(timedelta(hours=5, minutes=30))


def now_ist() -> datetime:
    return datetime.now(IST)


def ts() -> int:
    return int(time.time())


def conn() -> sqlite3.Connection:
    c = getattr(_LOCAL, "conn", None)
    if c is None:
        c = sqlite3.connect(config.DB_PATH, timeout=30, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA foreign_keys=ON")
        _LOCAL.conn = c
    return c


def q(sql: str, args: tuple = ()) -> list:
    with _LOCK:
        cur = conn().execute(sql, args)
        rows = cur.fetchall()
        return [dict(r) for r in rows]


def one(sql: str, args: tuple = ()):
    rows = q(sql, args)
    return rows[0] if rows else None


def run(sql: str, args: tuple = ()) -> int:
    with _LOCK:
        c = conn()
        cur = c.execute(sql, args)
        c.commit()
        return cur.lastrowid


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id      INTEGER PRIMARY KEY,
    username     TEXT,
    first_name   TEXT,
    joined_at    INTEGER,
    credits      INTEGER DEFAULT 0,
    likes_balance INTEGER DEFAULT 0,
    referred_by  INTEGER,
    refer_count  INTEGER DEFAULT 0,
    banned       INTEGER DEFAULT 0,
    last_like_at INTEGER DEFAULT 0,
    total_likes  INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS autolikes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    uid          TEXT NOT NULL,
    region       TEXT NOT NULL,
    nickname     TEXT,
    owner_id     INTEGER,
    key_code     TEXT,
    likes_target INTEGER DEFAULT 100,
    likes_left   INTEGER DEFAULT 0,
    likes_sent   INTEGER DEFAULT 0,
    paused       INTEGER DEFAULT 0,
    created_at   INTEGER,
    expires_at   INTEGER,
    last_run_at  INTEGER DEFAULT 0,
    total_days   INTEGER DEFAULT 0,
    days_done    INTEGER DEFAULT 0,
    UNIQUE(uid, region)
);
CREATE TABLE IF NOT EXISTS like_logs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    uid        TEXT, region TEXT, nickname TEXT,
    likes_before INTEGER, likes_after INTEGER, given INTEGER,
    sources    TEXT, kind TEXT, actor_id INTEGER, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS purchases (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER, username TEXT, uid TEXT, region TEXT, nickname TEXT,
    likes      INTEGER, amount REAL, currency TEXT, method TEXT,
    status     TEXT DEFAULT 'pending', txn TEXT, created_at INTEGER, approved_at INTEGER
);
CREATE TABLE IF NOT EXISTS keys (
    code       TEXT PRIMARY KEY,
    likes_total INTEGER, likes_left INTEGER,
    owner_id   INTEGER, bound_user INTEGER,
    created_at INTEGER, expires_at INTEGER, active INTEGER DEFAULT 1, note TEXT
);
CREATE TABLE IF NOT EXISTS refer_codes (
    code       TEXT PRIMARY KEY,
    credits    INTEGER, max_redeems INTEGER, used INTEGER DEFAULT 0,
    valid_till INTEGER, created_by INTEGER, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS redemptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT, user_id INTEGER, created_at INTEGER, UNIQUE(code, user_id)
);
CREATE TABLE IF NOT EXISTS referrals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inviter INTEGER, invitee INTEGER UNIQUE, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS apis (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT UNIQUE, kind TEXT DEFAULT 'like', enabled INTEGER DEFAULT 1,
    ok_count INTEGER DEFAULT 0, fail_count INTEGER DEFAULT 0, position INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    link TEXT UNIQUE, chat_id TEXT, title TEXT, required INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT, amount REAL DEFAULT 0, meta TEXT, created_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_logs_time ON like_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_events_time ON events(created_at);
CREATE INDEX IF NOT EXISTS idx_purch_time ON purchases(created_at);
"""


def init():
    with _LOCK:
        c = conn()
        c.executescript(SCHEMA)
        c.commit()
    # seed / reseed like sources — the revision key guarantees old APIs are
    # dropped the first time a new source list ships.
    rev = getattr(config, "LIKE_API_REVISION", "v1")
    if get_setting("like_api_revision") != rev:
        run("DELETE FROM apis WHERE kind='like'")
        set_setting("like_api_revision", rev)
    if not q("SELECT id FROM apis WHERE kind='like'"):
        for i, u in enumerate(config.DEFAULT_LIKE_APIS):
            run("INSERT OR IGNORE INTO apis(url,kind,position) VALUES(?,?,?)", (u, "like", i))
    if not q("SELECT id FROM apis WHERE kind='info'"):
        for i, u in enumerate(config.DEFAULT_INFO_APIS):
            run("INSERT OR IGNORE INTO apis(url,kind,position) VALUES(?,?,?)", (u, "info", i))

    if not q("SELECT id FROM groups"):
        run("INSERT OR IGNORE INTO groups(link,title,required) VALUES(?,?,1)",
            (config.LOG_GROUP_LINK, "Rocks Community"))
    if get_setting("runs_per_day") is None:
        set_setting("runs_per_day", "1")
        set_setting("run_times", json.dumps(["04:00"]))
    _migrate_legacy_json()


# ───────────────────────── settings ─────────────────────────
def get_setting(k: str, default=None):
    r = one("SELECT v FROM settings WHERE k=?", (k,))
    return r["v"] if r else default


def set_setting(k: str, v):
    run("INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, str(v)))


def get_json(k: str, default):
    raw = get_setting(k)
    if not raw:
        return default
    try:
        return json.loads(raw)
    except Exception:
        return default


# ───────────────────────── users ─────────────────────────
def upsert_user(user_id: int, username: str = "", first_name: str = ""):
    run("""INSERT INTO users(user_id,username,first_name,joined_at)
           VALUES(?,?,?,?)
           ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,
                                              first_name=excluded.first_name""",
        (user_id, username or "", first_name or "", ts()))
    return get_user(user_id)


def get_user(user_id: int):
    return one("SELECT * FROM users WHERE user_id=?", (user_id,))


def add_credits(user_id: int, amount: int):
    run("UPDATE users SET credits = credits + ? WHERE user_id=?", (amount, user_id))


def add_likes_balance(user_id: int, amount: int):
    run("UPDATE users SET likes_balance = likes_balance + ? WHERE user_id=?", (amount, user_id))


# ───────────────────────── apis ─────────────────────────
def like_apis():
    return q("SELECT * FROM apis WHERE kind='like' AND enabled=1 ORDER BY position, id")


def info_apis():
    return q("SELECT * FROM apis WHERE kind='info' AND enabled=1 ORDER BY position, id")


def bump_api(api_id: int, ok: bool):
    col = "ok_count" if ok else "fail_count"
    run(f"UPDATE apis SET {col} = {col} + 1 WHERE id=?", (api_id,))


# ───────────────────────── logging / analytics ─────────────────────────
def log_like(uid, region, nickname, before, after, given, sources, kind, actor_id):
    run("""INSERT INTO like_logs(uid,region,nickname,likes_before,likes_after,given,sources,kind,actor_id,created_at)
           VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (uid, region, nickname, before, after, given, json.dumps(sources), kind, actor_id, ts()))
    event("likes", given, {"uid": uid, "region": region, "kind": kind})


def event(kind: str, amount: float = 0, meta: dict | None = None):
    run("INSERT INTO events(kind,amount,meta,created_at) VALUES(?,?,?,?)",
        (kind, amount, json.dumps(meta or {}), ts()))


RANGES = {
    "day": 1, "week": 7, "month": 30, "quarter": 91, "half": 182, "year": 365,
}


def analytics(range_key: str = "week") -> dict:
    days = RANGES.get(range_key, 7)
    since = ts() - days * 86400
    likes = one("SELECT COALESCE(SUM(given),0) s, COUNT(*) c FROM like_logs WHERE created_at>=?", (since,))
    sales = one("""SELECT COALESCE(SUM(CASE WHEN currency='INR' THEN amount END),0) inr,
                          COALESCE(SUM(CASE WHEN currency='USD' THEN amount END),0) usd,
                          COALESCE(SUM(likes),0) likes, COUNT(*) c
                   FROM purchases WHERE status='approved' AND created_at>=?""", (since,))
    users = one("SELECT COUNT(*) c FROM users WHERE joined_at>=?", (since,))
    # bucketed series
    buckets = min(days, 30) if days > 1 else 24
    step = 3600 if days == 1 else int(days * 86400 / buckets)
    series = []
    for i in range(buckets):
        a = ts() - (buckets - i) * step
        b = a + step
        row = one("SELECT COALESCE(SUM(given),0) s FROM like_logs WHERE created_at>=? AND created_at<?", (a, b))
        prow = one("""SELECT COALESCE(SUM(amount),0) s FROM purchases
                      WHERE status='approved' AND created_at>=? AND created_at<?""", (a, b))
        series.append({
            "t": datetime.fromtimestamp(a, IST).strftime("%d %b" if days > 1 else "%H:%M"),
            "likes": row["s"], "sales": prow["s"],
        })
    return {
        "range": range_key,
        "likes_sent": likes["s"], "like_runs": likes["c"],
        "sales_inr": sales["inr"], "sales_usd": sales["usd"],
        "likes_sold": sales["likes"], "orders": sales["c"],
        "new_users": users["c"], "series": series,
    }


def totals() -> dict:
    return {
        "users": one("SELECT COUNT(*) c FROM users")["c"],
        "autolikes": one("SELECT COUNT(*) c FROM autolikes")["c"],
        "likes_sent": one("SELECT COALESCE(SUM(given),0) s FROM like_logs")["s"],
        "orders": one("SELECT COUNT(*) c FROM purchases WHERE status='approved'")["c"],
        "revenue_inr": one("SELECT COALESCE(SUM(amount),0) s FROM purchases WHERE status='approved' AND currency='INR'")["s"],
        "revenue_usd": one("SELECT COALESCE(SUM(amount),0) s FROM purchases WHERE status='approved' AND currency='USD'")["s"],
        "apis": one("SELECT COUNT(*) c FROM apis WHERE kind='like' AND enabled=1")["c"],
    }


def live_buyers(limit: int = 25):
    return q("""SELECT uid, region, nickname, likes, created_at FROM purchases
                WHERE status='approved' ORDER BY created_at DESC LIMIT ?""", (limit,))


# ───────────────────────── legacy import ─────────────────────────
def _migrate_legacy_json():
    if get_setting("legacy_imported") == "1" or not os.path.exists(config.LEGACY_JSON):
        return
    try:
        with open(config.LEGACY_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        set_setting("legacy_imported", "1")
        return
    for uid, item in (data.get("autolike_uids") or data.get("uids") or {}).items():
        if isinstance(item, dict):
            run("""INSERT OR IGNORE INTO autolikes(uid,region,nickname,likes_target,likes_left,created_at,total_days)
                   VALUES(?,?,?,?,?,?,?)""",
                (str(uid), (item.get("region") or "IND").upper(), item.get("nickname", ""),
                 int(item.get("likes", 100) or 100), int(item.get("likes_left", 0) or 0), ts(),
                 int(item.get("days", 0) or 0)))
    for uid in (data.get("users") or []):
        try:
            run("INSERT OR IGNORE INTO users(user_id,joined_at) VALUES(?,?)", (int(uid), ts()))
        except Exception:
            pass
    set_setting("legacy_imported", "1")
