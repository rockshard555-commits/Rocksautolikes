"""ROCKS AUTOLIKES — inline keyboards + message builders.

Font rule: every word is  Rᴀʏᴀɴ  (first letter capital, rest small-caps).
Emoji rule: emojis only on the LEFT of a line, never on the right.
"""
from datetime import datetime, timedelta

from telegram import InlineKeyboardButton as B
from telegram import InlineKeyboardMarkup as M
from telegram import WebAppInfo

import config
import db
from style import (LINE, SHORT_LINE, fancy, progress_bar, spoiler, wrap,
                   wrap_support)

WEBAPP = config.PUBLIC_URL


def kb(rows):
    return M(rows)


def expire_str(days: int) -> str:
    return (datetime.now() + timedelta(days=days)).strftime("%d %b %Y")


# ─────────────────────────── MENUS ───────────────────────────
def main_menu(is_admin: bool = False):
    """One wide button on top, then two per row (owner's reference layout)."""
    rows = [
        [B("🎁 Gᴇᴛ Fʀᴇᴇ Cʀᴇᴅɪᴛ", callback_data="m:refer")],
        [B("💖 Aᴅᴅ Lɪᴋᴇ", callback_data="m:like"),
         B("🔎 Pʟᴀʏᴇʀ Iᴎꜰᴏ", callback_data="m:info")],
        [B("🛒 Bᴜʏ Lɪᴋᴇꜱ", callback_data="m:plans"),
         B("🤖 Aᴜᴛᴏʟɪᴋᴇ", callback_data="m:auto")],
        [B("💰 Cʜᴇᴄᴋ Cʀᴇᴅɪᴛꜱ", callback_data="m:bal"),
         B("🎉 Rᴇꜰᴇʀ & Eᴀʀᴎ", callback_data="m:refer")],
        [B("🎟 Rᴇᴅᴇᴇᴍ Cᴏᴅᴇ", callback_data="m:redeem"),
         B("ℹ️ Hᴇʟᴘ", callback_data="m:help")],
        [B("🚨 Mᴏʀᴇ Fʀᴇᴇ Fɪʀᴇ Sᴇʀᴠɪᴄᴇꜱ", callback_data="m:services")],
        [B("📱 Oᴘᴇᴎ Mɪᴎɪ Aᴘᴘ", web_app=WebAppInfo(url=WEBAPP))],
        [B("➕ Mᴏʀᴇ", callback_data="m:more"),
         B("📞 Aᴅᴍɪᴎ Cᴏᴎᴛᴀᴄᴛ", url=config.OWNER_URL)],
    ]
    if is_admin:
        rows.append([B("👑 Oᴡᴎᴇʀ Dᴀꜱʜʙᴏᴀʀᴅ", callback_data="a:panel")])
    return kb(rows)


def more_menu(is_admin=False):
    rows = [
        [B("🌍 Rᴇɢɪᴏᴎꜱ", callback_data="m:regions"),
         B("📊 Sᴛᴀᴛꜱ", callback_data="m:stats")],
        [B("🏆 Lᴇᴀᴅᴇʀʙᴏᴀʀᴅ", callback_data="m:top"),
         B("📜 Aʟʟ Cᴏᴍᴍᴀᴎᴅꜱ", callback_data="m:cmds")],
        [B("ℹ️ Aʙᴏᴜᴛ", callback_data="m:about"),
         B("🔑 Mʏ Kᴇʏꜱ", callback_data="m:keys")],
        [B("🚨 Mᴏʀᴇ Fʀᴇᴇ Fɪʀᴇ Sᴇʀᴠɪᴄᴇꜱ", callback_data="m:services")],
        [B("💬 Cᴏᴍᴍᴜᴎɪᴛʏ Gʀᴏᴜᴘ", url=config.LOG_GROUP_LINK)],
        [B("👑 Cᴏᴎᴛᴀᴄᴛ Oᴡᴎᴇʀ", url=config.OWNER_URL)],
        [B("⬅️ Bᴀᴄᴋ", callback_data="m:home")],
    ]
    if is_admin:
        rows.insert(3, [B("📡 Aᴘɪ Sᴛᴀᴛᴜꜱ", callback_data="m:apis")])
    return kb(rows)


def back_row(target="m:home", more=None):
    row = [B("⬅️ Bᴀᴄᴋ", callback_data=target)]
    if more:
        row.append(B("➕ Mᴏʀᴇ", callback_data=more))
    return row


def region_keyboard(prefix: str, page: int = 0):
    codes = list(config.REGIONS.keys())
    per = 8
    chunk = codes[page * per:(page + 1) * per]
    rows, buf = [], []
    for c in chunk:
        meta = config.REGIONS[c]
        buf.append(B(f"{meta['flag']} {c}", callback_data=f"{prefix}:{c}"))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)
    nav = []
    if page > 0:
        nav.append(B("⬅️ Pʀᴇᴠ", callback_data=f"{prefix}#pg:{page-1}"))
    if (page + 1) * per < len(codes):
        nav.append(B("➕ Mᴏʀᴇ", callback_data=f"{prefix}#pg:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append(back_row())
    return kb(rows)


def plans_keyboard():
    """Plan picker in the reference style — likes first, price second."""
    rows = []
    for p in config.PLANS:
        tag = f"  {p['tag'].split(' ')[0]}" if p["tag"] else ""
        rows.append([B(f"{p['label']}{tag} • {p['likes']:,} • ₹{p['inr']} / ${p['usd']} / {p['stars']}⭐",
                       callback_data=f"p:{p['id']}")])
    rows.append([B("📱 Bᴜʏ Iᴎ Mɪᴎɪ Aᴘᴘ", web_app=WebAppInfo(url=WEBAPP + "/#plans"))])
    rows.append([B("👑 Cᴏᴎᴛᴀᴄᴛ Oᴡᴎᴇʀ", url=config.OWNER_URL)])
    rows.append(back_row(more="m:more"))
    return kb(rows)


def plan_pay_keyboard(plan_id: int):
    return kb([
        [B("🇮🇳 Pᴀʏ Wɪᴛʜ Uᴘɪ (Iᴎʀ)", callback_data=f"pay:inr:{plan_id}")],
        [B("💵 Pᴀʏ Wɪᴛʜ Uꜱᴅᴛ (Bᴇᴘ20)", callback_data=f"pay:usd:{plan_id}")],
        [B("⭐ Pᴀʏ Wɪᴛʜ Tᴇʟᴇɢʀᴀᴍ Sᴛᴀʀꜱ", callback_data=f"pay:star:{plan_id}")],
        [B("👑 Bᴜʏ Vɪᴀ Oᴡᴎᴇʀ Dᴍ", url=config.OWNER_URL)],
        back_row("m:plans", more="m:more"),
    ])


def pay_timer_keyboard(order_id: int):
    return kb([
        [B("✅ I Hᴀᴠᴇ Pᴀɪᴅ", callback_data=f"paid:{order_id}")],
        [B("❌ Cᴀᴎᴄᴇʟ Oʀᴅᴇʀ", callback_data=f"cancel:{order_id}")],
    ])


def about_menu():
    rows, buf = [], []
    for s in config.SOCIALS:
        buf.append(B(f"{s['emoji']} {fancy(s['title'])}", callback_data=f"ab:{s['key']}"))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)
    rows.append([B("👑 Oᴡᴎᴇʀ", url=config.OWNER_URL)])
    rows.append(back_row(more="m:more"))
    return kb(rows)


def about_page_kb(key: str, url: str):
    return kb([
        [B("🔗 Oᴘᴇᴎ Lɪᴎᴋ", url=url)],
        back_row("m:about", more="m:more"),
    ])


def refer_menu():
    return kb([
        [B("🔗 Mʏ Rᴇꜰᴇʀ Lɪᴎᴋ", callback_data="rf:link")],
        [B("🎟 Rᴇᴅᴇᴇᴍ Cᴏᴅᴇ", callback_data="rf:redeem"),
         B("🎁 Cʟᴀɪᴍ Aᴜᴛᴏʟɪᴋᴇ", callback_data="rf:claim")],
        [B("📈 Mʏ Rᴇꜰᴇʀʀᴀʟꜱ", callback_data="rf:list")],
        back_row(more="m:more"),
    ])


def info_kb(uid: str, region: str):
    return kb([
        [B("📋 Fᴜʟʟ Iᴎꜰᴏ", callback_data=f"fi:{region}:{uid}"),
         B("💖 Aᴅᴅ Lɪᴋᴇ", callback_data="m:like")],
        [B("🎮 Aᴅᴅ Fʀɪᴇᴎᴅ Iᴎ Gᴀᴍᴇ", url=config.ff_share_link(uid, region))],
        back_row(more="m:more"),
    ])


def admin_menu():
    return kb([
        [B("📊 Aᴎᴀʟʏᴛɪᴄꜱ", callback_data="a:an:week"), B("👥 Uꜱᴇʀꜱ", callback_data="a:users")],
        [B("🤖 Aᴜᴛᴏʟɪᴋᴇ Lɪꜱᴛ", callback_data="a:auto"), B("▶️ Rᴜᴎ Aʟʟ", callback_data="a:runall")],
        [B("🔑 Kᴇʏꜱ", callback_data="a:keys"), B("🎟 Rᴇꜰᴇʀ Cᴏᴅᴇꜱ", callback_data="a:codes")],
        [B("📡 Aᴘɪ Sʟᴏᴛꜱ", callback_data="m:apis"), B("⏰ Rᴜᴎ Tɪᴍᴇꜱ", callback_data="a:runs")],
        [B("🧾 Pᴇᴎᴅɪᴎɢ Oʀᴅᴇʀꜱ", callback_data="a:orders"), B("📢 Bʀᴏᴀᴅᴄᴀꜱᴛ", callback_data="a:bc")],
        [B("🌐 Oᴘᴇᴎ Wᴇʙ Dᴀꜱʜʙᴏᴀʀᴅ", url=WEBAPP + "/dashboard")],
        back_row(more="m:more"),
    ])


def analytics_kb():
    return kb([
        [B("📅 Dᴀʏ", callback_data="a:an:day"), B("🗓 Wᴇᴇᴋ", callback_data="a:an:week"),
         B("📆 Mᴏᴎᴛʜ", callback_data="a:an:month")],
        [B("📈 Qᴜᴀʀᴛᴇʀ", callback_data="a:an:quarter"), B("📉 Hᴀʟꜰ", callback_data="a:an:half"),
         B("🏆 Yᴇᴀʀ", callback_data="a:an:year")],
        back_row("a:panel", more="m:more"),
    ])


# ─────────────────────────── TEXTS ───────────────────────────
def start_text(name: str, is_admin: bool) -> str:
    t = db.totals()
    body = (
        f"👋 <b>{fancy('Welcome')} {name}!</b>\n"
        f"🔥 <b>{fancy('Rocks Autolikes')}</b> — {fancy('Fastest Free Fire Like Service')}\n\n"
        f"❤️ {fancy('Instant Likes')}\n"
        f"🤖 {fancy('Daily Autolike Upto 7 Runs Per Day')}\n"
        f"🌍 {fancy('All Regions Supported')}\n"
        f"👥 {fancy('Total Users')}: <b>{t['users']}</b>\n"
        f"💖 {fancy('Likes Delivered')}: <b>{t['likes_sent']:,}</b>\n"
        f"🚀 {fancy('Autolike Slots Running')}: <b>{t['autolikes']}</b>\n\n"
        f"👇 {fancy('Use The Buttons Below To Start')}"
    )
    if is_admin:
        body += f"\n\n👑 {fancy('Admin Mode Active')}"
    return wrap(body)


def progress_text(state: dict, uid: str, region: str) -> str:
    stages = {
        "lookup": fancy("Fetching Player Data"),
        "sending": fancy("Sending Likes"),
        "verify": fancy("Verifying Final Likes"),
        "done": fancy("Finishing"),
    }
    stage = stages.get(state.get("stage", "sending"), fancy("Working"))
    body = (
        f"⚡ <b>{fancy('Sending Likes')}</b>\n\n"
        f"🎮 {fancy('Player')}: <b>{state.get('nickname') or fancy('Loading')}</b>\n"
        f"🪪 {fancy('Uid')}: <b>{uid}</b>\n"
        f"🌍 {fancy('Region')}: <b>{config.region_label(region)}</b>\n\n"
        f"{progress_bar(state.get('pct', 0))}\n"
        f"🔄 {stage}\n"
        f"💖 {fancy('Likes Counted')}: <b>{state.get('likes', 0)}</b>"
    )
    return wrap(body)


def like_result_text(res: dict, extra: dict | None = None) -> str:
    """Owner-approved layout. Emojis on the left side only."""
    extra = extra or {}
    lines = [
        f"👤  Pʟᴀʏᴇʀ Nɪᴄᴋɴᴀᴍᴇ: {res['nickname']}",
        f"🪪  Uɪᴅ: {res['uid']}",
        f"🌍  Rᴇɢɪᴏɴ: {config.region_label(res['region'])}",
        f"📊  Pʟᴀʏᴇʀ Lᴇᴠᴇʟ: {res.get('level') or fancy('Unknown')}",
        f"📉  Lɪᴋᴇꜱ Bᴇꜰᴏʀᴇ: {res['before']:,}",
        f"➕ Lɪᴋᴇꜱ Gɪᴠᴇɴ Bʏ Bᴏᴛ: {res['given']}",
        f"📈 Lɪᴋᴇꜱ Aꜰᴛᴇʀ: {res['after']:,}",
        f"⚡ Sᴘᴇᴇᴅ: {res['took']}ꜱ",
    ]
    if extra.get("days_left") is not None:
        lines.append(f"📅 Dᴀʏꜱ Rᴇᴍᴀɪɴɪɴɢ: {extra['days_left']}/{extra.get('days_total', 0)}")
    if extra.get("likes_left") is not None:
        lines.append(f"🎯 Lɪᴋᴇꜱ Rᴇᴍᴀɪɴɪɴɢ: {extra['likes_left']:,}/{extra.get('likes_total', 0):,}")
    if extra.get("expire"):
        lines.append(f"⏳ Exᴘɪʀᴇ Dᴀᴛᴇ: {extra['expire']}")

    lines += ["", SHORT_LINE, "👾 Source:", SHORT_LINE, ""]
    for s in res["sources"]:
        lines.append(f"⚙️ Rᴇᴄᴇɪᴠᴇᴅ Lɪᴋᴇꜱ Fʀᴏᴍ {s['v']}: {s['given']} 🪽")
    for v in res.get("already", []):
        lines.append(f"🚫 Aʟʀᴇᴀᴅʏ Sᴇɴᴛ Fʀᴏᴍ {v}")
    lines.append("")
    lines.append(f"😮‍💨 Total likes: {res['given']} 👽")

    return wrap_support("\n".join(lines), title="✅ Lɪᴋᴇꜱ Dᴇʟɪᴠᴇʀᴇᴅ Sᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ")


def info_text(i: dict) -> str:
    if not i.get("ok"):
        return wrap(f"❌ <b>{fancy('Player Not Found')}</b>\n🔍 {fancy('Check The Uid And Region And Try Again')}")
    body = [
        "🔎 <b>Pʟᴀʏᴇʀ Iɴꜰᴏʀᴍᴀᴛɪᴏɴ</b>", "",
        f"🔹 Nᴀᴍᴇ: {i['nickname']}",
        f"🔸 Uɪᴅ: {i['uid']}",
        f"🔸 Rᴇɢɪᴏɴ: {config.region_label(i['region'])}",
        f"🔸 Lᴇᴠᴇʟ: {i['level'] or fancy('Unknown')}",
        f"🔸 Lɪᴋᴇꜱ: {i['likes']:,}",
    ]
    if i.get("guild"):
        body.append(f"🔸 Gᴜɪʟᴅ: {i['guild']}")
    if i.get("br_rank"):
        body.append(f"🔸 Bʀ Pᴏɪɴᴛꜱ: {i['br_rank']:,}")
    if i.get("cs_rank"):
        body.append(f"🔸 Cꜱ Pᴏɪɴᴛꜱ: {i['cs_rank']:,}")
    if i.get("bio"):
        body.append(f"🔸 Bɪᴏ: {i['bio'][:150]}")
    return wrap("\n".join(body))


# ── full info: everything the API returns, grouped ──
FULL_GROUPS = [
    ("👤 BASIC INFO", [
        ("Account ID", ["accountId", "uid", "account_id"]),
        ("Nickname", ["nickname", "playerNickname", "name"]),
        ("Region", ["region", "server", "accountRegion"]),
        ("Level", ["level", "accountLevel"]),
        ("EXP", ["exp", "accountExp"]),
        ("Likes", ["likes", "accountLikes"]),
        ("Elite Pass", ["hasElitePass", "elitePass"]),
        ("Badge Count", ["badgeCnt", "badgeCount"]),
        ("Badge ID", ["badgeId"]),
        ("Pin ID", ["pinId"]),
        ("Title ID", ["title", "titleId"]),
        ("Banner ID", ["bannerId"]),
        ("Head Pic", ["headPic"]),
        ("Season ID", ["seasonId"]),
        ("Version", ["releaseVersion", "version"]),
        ("Created At", ["createAt", "createdAt", "accountCreateTime"]),
        ("Last Login", ["lastLoginAt", "accountLastLogin"]),
        ("Show Rank", ["showRank"]),
        ("Pregame Choice", ["pregameChoice", "preGameChoice"]),
    ]),
    ("🏆 RANK INFO", [
        ("BR Rank", ["rank", "brRank"]),
        ("BR Points", ["rankingPoints", "brRankPoint", "brPoints"]),
        ("BR Max Rank", ["maxRank", "brMaxRank"]),
        ("Show BR Rank", ["showBrRank"]),
        ("CS Rank", ["csRank"]),
        ("CS Points", ["csRankingPoints", "csRankPoint", "csPoints"]),
        ("CS Max Rank", ["csMaxRank"]),
        ("Show CS Rank", ["showCsRank"]),
    ]),
    ("🎨 PROFILE INFO", [
        ("Avatar ID", ["avatarId"]),
        ("Clothes", ["clothes", "equippedOutfit"]),
        ("Skills", ["equippedSkills", "skills"]),
        ("Primary Weapon", ["primaryWeapon"]),
        ("End Time", ["endTime"]),
    ]),
    ("🔫 WEAPON SKINS", [("", ["equippedWeapon", "weaponSkins", "weapons"])]),
    ("👥 CLAN INFO", [
        ("Clan Name", ["clanName", "guildName"]),
        ("Clan ID", ["clanId", "guildId"]),
        ("Captain ID", ["captainId"]),
        ("Clan Level", ["clanLevel", "guildLevel"]),
        ("Members", ["memberNum", "members"]),
        ("Capacity", ["capacity"]),
    ]),
    ("🐾 PET INFO", [
        ("Name", ["petName"]),
        ("Pet ID", ["petId"]),
        ("Level", ["petLevel"]),
        ("EXP", ["petExp"]),
        ("Skin ID", ["skinId"]),
        ("Skill ID", ["selectedSkillId", "skillId"]),
        ("Selected", ["isSelected", "selected"]),
    ]),
    ("💬 SOCIAL INFO", [
        ("Language", ["language"]),
        ("Rank Show", ["rankShow"]),
        ("Signature", ["signature", "bio"]),
        ("Mode Prefer", ["modePrefer"]),
    ]),
    ("📊 CREDIT INFO", [
        ("Credit Score", ["creditScore"]),
        ("Summary End", ["periodicSummaryEndTime", "summaryEnd"]),
    ]),
    ("🔗 EXTERNAL ICON", [
        ("Status", ["externalIconStatus", "status"]),
        ("Show Type", ["externalIconShowType", "showType"]),
    ]),
]


def _norm(k: str) -> str:
    return str(k).lower().replace("_", "").replace(" ", "")


def _walk(obj, out: dict):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, (dict, list)):
                _walk(v, out)
            else:
                out.setdefault(_norm(k), v)
    elif isinstance(obj, list):
        for v in obj:
            _walk(v, out)


def _fmt_val(v) -> str:
    if isinstance(v, bool):
        return "Yes" if v else "No"
    if isinstance(v, list):
        return ", ".join(str(x) for x in v)
    if isinstance(v, dict):
        return ", ".join(f"{k}: {x}" for k, x in v.items())
    if isinstance(v, int) and 1000000000 < v < 4000000000:
        try:
            return datetime.fromtimestamp(v).strftime("%d-%m-%Y %I:%M:%S %p")
        except Exception:
            return str(v)
    return str(v)


def full_info_text(i: dict) -> str:
    """Print EVERYTHING the info API returned, organised into groups."""
    if not i.get("ok"):
        return wrap(f"❌ <b>{fancy('Player Not Found')}</b>")
    raw = i.get("raw_full") or i.get("raw") or {}
    flat: dict = {}
    _walk(raw, flat)

    used = set()
    out = [LINE, "🎮 FREE FIRE PLAYER INFO", LINE, ""]
    for title, fields in FULL_GROUPS:
        block = []
        for label, keys in fields:
            for k in keys:
                nk = _norm(k)
                if nk in flat and flat[nk] not in (None, "", [], {}):
                    used.add(nk)
                    val = _fmt_val(flat[nk])
                    block.append(f"• {label}: {val}" if label else f"• {val}")
                    break
        if block:
            out.append(title)
            out.extend(block)
            out.append("")

    extras = [f"• {k}: {_fmt_val(v)}" for k, v in flat.items()
              if k not in used and v not in (None, "", [], {})]
    if extras:
        out.append("🧩 OTHER INFO")
        out.extend(extras[:60])
        out.append("")

    out += [LINE, f"👑 Oᴡɴᴇʀ: {config.OWNER_HANDLE}", LINE]
    return "<b>" + "\n".join(out)[:3900] + "</b>"


def plans_text() -> str:
    rows = ["💎 <b>Rᴏᴄᴋꜱ Aᴜᴛᴏʟɪᴋᴇꜱ Pʀɪᴄᴇ Lɪꜱᴛ</b>", ""]
    for p in config.PLANS:
        tag = f"  {p['tag']}" if p["tag"] else ""
        rows.append(
            f"{p['label']}{tag}\n"
            f"   💖 {p['likes']:,} Lɪᴋᴇꜱ\n"
            f"   🇮🇳 ₹{p['inr']}  •  💵 ${p['usd']}  •  ⭐ {p['stars']}"
        )
    rows += ["", "🕔 Dᴇʟɪᴠᴇʀʏ: Iɴꜱᴛᴀɴᴛ Tᴏ 24 Hᴏᴜʀꜱ",
             "🔐 Sᴀꜰᴇ Aɴᴅ Mᴀɴᴜᴀʟ Vᴇʀɪꜰɪᴇᴅ",
             "💬 Sᴜᴘᴘᴏʀᴛ 24x7"]
    return wrap("\n".join(rows))


def services_text() -> str:
    """Owner's Free Fire services catalogue."""
    return (
        "<b>"
        f"{LINE}\n"
        "🚨 Fʀᴇᴇ Fɪʀᴇ Sᴇʀᴠɪᴄᴇꜱ Aᴠᴀɪʟᴀʙʟᴇ:\n"
        f"{LINE}\n\n"
        "📈 Aᴜᴛᴏ Lᴇᴠᴇʟ Iɴᴄʀᴇᴀꜱᴇ\n"
        "• Pᴇʀ Dᴀʏ Uᴘᴛᴏ 50ᴋ Exᴘ\n\n"
        "👍🏼 Aᴜᴛᴏ Lɪᴋᴇ Iɴᴄʀᴇᴀꜱᴇ\n"
        "• Uᴘᴛᴏ 1700-2220+ Pᴇʀ Dᴀʏ\n\n"
        "🥷🏻 Aᴜᴛᴏ Gᴜɪʟᴅ Gʟᴏʀʏ Iɴᴄʀᴇᴀꜱᴇ\n"
        "• Eᴀꜱʏ 1 Tᴏ 7\n\n"
        f"{SHORT_LINE}\n"
        "🔥 Tᴄᴘ Bᴏᴛ Aᴠᴀɪʟᴀʙʟᴇ:\n"
        f"{SHORT_LINE}\n"
        "• Lᴀᴛᴇꜱᴛ Oʙ Bᴏᴛ\n"
        "• Aɴᴛɪ Bᴀɴ\n"
        "• Aʟʟ Eᴍᴏᴛᴇꜱ\n"
        "• Eᴠᴏ Bᴜɴᴅʟᴇꜱ\n"
        "• Pᴄ Lᴏɢᴏ\n"
        "• Cᴜꜱᴛᴏᴍ Bʀᴀɴᴅɪɴɢ\n"
        "• Pʀᴇᴍɪᴜᴍ Cʟᴇᴀɴ Cʜᴀᴛ Uɪ\n"
        "• Aʟʟ Bᴀᴅɢᴇ Sᴘᴀᴍ\n"
        "• 3 / 4 / 5 Pʟᴀʏᴇʀ Gʀᴏᴜᴘꜱ\n"
        "• Aɴᴅ Mᴜᴄʜ Mᴏʀᴇ\n\n"
        "📦 Bᴏᴛʜ Aᴠᴀɪʟᴀʙʟᴇ:\n"
        "• Sᴏᴜʀᴄᴇ Cᴏᴅᴇ Wɪᴛʜ Gᴜɪᴅᴇ\n"
        "• 24/7 Hᴏꜱᴛɪɴɢ + Sᴏᴜʀᴄᴇ Cᴏᴅᴇ Wɪᴛʜ Gᴜɪᴅᴇ\n\n"
        f"{SHORT_LINE}\n"
        "🌐 Gᴜᴇꜱᴛ Aᴄᴄᴏᴜɴᴛ Gᴇɴᴇʀᴀᴛᴏʀ Wᴇʙꜱɪᴛᴇ + Aᴜᴛᴏ Sᴘɪɴɴᴇʀ Fᴏʀ Eᴠᴇɴᴛꜱ\n"
        f"{SHORT_LINE}\n"
        "• Aʟʟ Sᴇʀᴠᴇʀꜱ Aᴠᴀɪʟᴀʙʟᴇ\n"
        "• Aᴜᴛᴏ Aᴄᴛɪᴠᴀᴛᴇ\n"
        "• Aᴜᴛᴏ Cᴜꜱᴛᴏᴍ Nᴀᴍᴇ\n"
        "• Aᴜᴛᴏ Cᴜꜱᴛᴏᴍ Pᴀꜱꜱᴡᴏʀᴅ\n"
        "• Aᴜᴛᴏ Cᴜꜱᴛᴏᴍ Bɪᴏ\n"
        "• Aᴜᴛᴏ Iᴘ Cʜᴀɴɢᴇʀ\n"
        "• Cᴏᴍᴘʟᴇᴛᴇ Sᴇᴛᴜᴘ Tᴜᴛᴏʀɪᴀʟ\n"
        "• Mᴏᴅᴇʀɴ Wᴇʙ Uɪ\n"
        "• Fᴀꜱᴛ Aɴᴅ Eᴀꜱʏ Iɴꜱᴛᴀʟʟᴀᴛɪᴏɴ\n"
        "• Pʏᴛʜᴏɴ + Tᴇʀᴍᴜx Sᴜᴘᴘᴏʀᴛ\n"
        "• Uᴘᴅᴀᴛᴇᴅ Vᴇʀꜱɪᴏɴ\n\n"
        f"{LINE}\n"
        f"👑 Tᴏ Bᴜʏ Cᴏɴᴛᴀᴄᴛ: {config.OWNER_HANDLE}\n"
        f"{LINE}"
        "</b>"
    )


def services_kb():
    return kb([
        [B("👑 Cᴏᴎᴛᴀᴄᴛ Oᴡᴎᴇʀ Tᴏ Bᴜʏ", url=config.OWNER_URL)],
        [B("💬 Cᴏᴍᴍᴜᴎɪᴛʏ Gʀᴏᴜᴘ", url=config.LOG_GROUP_LINK)],
        back_row(more="m:more"),
    ])


def help_text() -> str:
    body = [
        "🆘 <b>Uꜱᴇʀ Cᴏᴍᴍᴀɴᴅꜱ</b>", "",
        f"💖 <code>/like ind 3688500765</code> — {fancy('Send Free Likes')}",
        f"🔎 <code>/info ind 3688500765</code> — {fancy('Player Info')}",
        f"📋 <code>/fullinfo ind 3688500765</code> — {fancy('Everything The Api Returns')}",
        f"💎 <code>/plans</code> — {fancy('Price List')}",
        f"🎁 <code>/refer</code> — {fancy('Earn Credits By Inviting Friends')}",
        f"🎟 <code>/redeem</code> — {fancy('Redeem A Credit Code')}",
        f"🏆 <code>/claim ind 3688500765</code> — {fancy('Turn Credits Into Autolike')}",
        f"💰 <code>/balance</code> — {fancy('Your Credits And Likes')}",
        f"🔑 <code>/mykeys</code> — {fancy('Your Purchase Keys')}",
        f"ℹ️ <code>/about</code> — {fancy('Socials And Scanners')}",
        f"📱 <code>/app</code> — {fancy('Open The Mini App')}",
        f"📜 <code>/commands</code> — {fancy('All Commands')}",
        "",
        f"🚀 {fancy('Buy A Plan To Get Daily Autolike Upto 7 Runs Per Day')}",
    ]
    return wrap("\n".join(body))


def regions_text() -> str:
    lines = ["🌍 <b>Sᴜᴘᴘᴏʀᴛᴇᴅ Rᴇɢɪᴏɴꜱ</b>", ""]
    for code, meta in config.REGIONS.items():
        lines.append(f"{meta['flag']} <b>{code}</b> — {fancy(meta['name'])}")
    return wrap("\n".join(lines))


def payment_text(plan: dict, currency: str, order_id: int, seconds_left: int) -> str:
    mm, ss = divmod(max(0, seconds_left), 60)
    bar = progress_bar(100 * seconds_left / max(1, config.PAYMENT_TIMER_SECONDS))
    if currency == "INR":
        pay = (f"🇮🇳 Aᴍᴏᴜɴᴛ: <b>₹{plan['inr']}</b>\n"
               f"🏦 Uᴘɪ Iᴅ: {spoiler(f'<code>{config.UPI_ID}</code>')}\n"
               f"👤 Nᴀᴍᴇ: {spoiler(config.UPI_NAME)}")
    else:
        pay = (f"💵 Aᴍᴏᴜɴᴛ: <b>${plan['usd']} Uꜱᴅᴛ</b>\n"
               f"🔗 Nᴇᴛᴡᴏʀᴋ: <b>{config.USDT_NETWORK}</b>\n"
               f"📥 Aᴅᴅʀᴇꜱꜱ: {spoiler(f'<code>{config.USDT_ADDRESS}</code>')}")
    body = (
        f"🧾 <b>Oʀᴅᴇʀ #{order_id}</b> — {plan['label']}\n"
        f"💖 Lɪᴋᴇꜱ: <b>{plan['likes']:,}</b>\n\n"
        f"{pay}\n\n"
        f"🔒 Tᴀᴘ Tʜᴇ Hɪᴅᴅᴇɴ Tᴇxᴛ Tᴏ Rᴇᴠᴇᴀʟ Aɴᴅ Cᴏᴘʏ\n\n"
        f"⏳ Tɪᴍᴇ Lᴇꜰᴛ: <b>{mm:02d}:{ss:02d}</b>\n{bar}\n\n"
        f"📸 Aꜰᴛᴇʀ Pᴀʏɪɴɢ Tᴀᴘ I Hᴀᴠᴇ Pᴀɪᴅ Aɴᴅ Sᴇɴᴅ Tʜᴇ Sᴄʀᴇᴇɴꜱʜᴏᴛ"
    )
    return wrap(body)


def keys_text(user_id: int) -> str:
    rows = db.q("SELECT * FROM keys WHERE bound_user=? OR owner_id=? ORDER BY created_at DESC LIMIT 10",
                (user_id, user_id))
    out = ["🔑 <b>Yᴏᴜʀ Kᴇʏꜱ</b>", ""]
    if not rows:
        out.append(f"📭 {fancy('No Keys Yet')}")
        out.append(f"💎 {fancy('Buy A Plan To Get One')}")
    for r in rows:
        out.append(f"🔐 <code>{r['code']}</code>")
        out.append(f"💖 Lɪᴋᴇꜱ Lᴇꜰᴛ: {r['likes_left']:,}/{r['likes_total']:,}")
        if r["expires_at"]:
            out.append(f"📅 Vᴀʟɪᴅ Tɪʟʟ: {datetime.fromtimestamp(r['expires_at']).strftime('%d %b %Y')}")
        out.append("")
    out.append("🌐 Lᴏɢɪɴ Oɴ Tʜᴇ Wᴇʙꜱɪᴛᴇ Wɪᴛʜ Yᴏᴜʀ Kᴇʏ Tᴏ Mᴀɴᴀɢᴇ Aᴜᴛᴏʟɪᴋᴇ")
    return wrap("\n".join(out))


# ─────────────────────── COMMAND BOOK (100+) ───────────────────────
USER_COMMANDS = [
    ("start", "Oᴘᴇɴ Tʜᴇ Mᴀɪɴ Mᴇɴᴜ"),
    ("help", "Hᴇʟᴘ Aɴᴅ Bᴀꜱɪᴄꜱ"),
    ("cmds", "Tʜɪꜱ Cᴏᴍᴍᴀɴᴅ Bᴏᴏᴋ"),
    ("commands", "Sᴀᴍᴇ Aꜱ Cᴍᴅꜱ"),
    ("menu", "Mᴀɪɴ Mᴇɴᴜ"),
    ("home", "Mᴀɪɴ Mᴇɴᴜ"),
    ("about", "Aʙᴏᴜᴛ Aɴᴅ Sᴏᴄɪᴀʟꜱ"),
    ("owner", "Cᴏɴᴛᴀᴄᴛ Tʜᴇ Oᴡɴᴇʀ"),
    ("support", "Sᴜᴘᴘᴏʀᴛ Cʜᴀɴɴᴇʟ"),
    ("group", "Cᴏᴍᴍᴜɴɪᴛʏ Gʀᴏᴜᴘ"),
    ("app", "Oᴘᴇɴ Tʜᴇ Mɪɴɪ Aᴘᴘ"),
    ("web", "Oᴘᴇɴ Tʜᴇ Wᴇʙꜱɪᴛᴇ"),
    ("site", "Oᴘᴇɴ Tʜᴇ Wᴇʙꜱɪᴛᴇ"),
    ("miniapp", "Oᴘᴇɴ Tʜᴇ Mɪɴɪ Aᴘᴘ"),
    ("like", "Sᴇɴᴅ Lɪᴋᴇꜱ — /like ind 3688500765"),
    ("likes", "Sᴀᴍᴇ Aꜱ Lɪᴋᴇ"),
    ("addlike", "Sᴀᴍᴇ Aꜱ Lɪᴋᴇ"),
    ("boost", "Sᴀᴍᴇ Aꜱ Lɪᴋᴇ"),
    ("info", "Pʟᴀʏᴇʀ Iɴꜰᴏ — /info ind 3688500765"),
    ("player", "Sᴀᴍᴇ Aꜱ Iɴꜰᴏ"),
    ("uid", "Sᴀᴍᴇ Aꜱ Iɴꜰᴏ"),
    ("check", "Sᴀᴍᴇ Aꜱ Iɴꜰᴏ"),
    ("fullinfo", "Eᴠᴇʀʏᴛʜɪɴɢ Tʜᴇ Aᴘɪ Rᴇᴛᴜʀɴꜱ"),
    ("full", "Sᴀᴍᴇ Aꜱ Fᴜʟʟɪɴꜰᴏ"),
    ("raw", "Sᴀᴍᴇ Aꜱ Fᴜʟʟɪɴꜰᴏ"),
    ("profile", "Sᴀᴍᴇ Aꜱ Fᴜʟʟɪɴꜰᴏ"),
    ("addfriend", "Iɴ Gᴀᴍᴇ Aᴅᴅ Fʀɪᴇɴᴅ Lɪɴᴋ"),
    ("ffshare", "Fʀᴇᴇ Fɪʀᴇ Sʜᴀʀᴇ Lɪɴᴋ"),
    ("plans", "Pʀɪᴄᴇ Lɪꜱᴛ"),
    ("price", "Pʀɪᴄᴇ Lɪꜱᴛ"),
    ("buy", "Bᴜʏ Lɪᴋᴇꜱ"),
    ("shop", "Bᴜʏ Lɪᴋᴇꜱ"),
    ("pay", "Pᴀʏᴍᴇɴᴛ Oᴘᴛɪᴏɴꜱ"),
    ("upi", "Uᴘɪ Pᴀʏᴍᴇɴᴛ Dᴇᴛᴀɪʟꜱ"),
    ("usdt", "Uꜱᴅᴛ Pᴀʏᴍᴇɴᴛ Dᴇᴛᴀɪʟꜱ"),
    ("stars", "Tᴇʟᴇɢʀᴀᴍ Sᴛᴀʀꜱ Cʜᴇᴄᴋᴏᴜᴛ"),
    ("services", "Mᴏʀᴇ Fʀᴇᴇ Fɪʀᴇ Sᴇʀᴠɪᴄᴇꜱ"),
    ("tcp", "Tᴄᴘ Bᴏᴛ Sᴇʀᴠɪᴄᴇ"),
    ("guest", "Gᴜᴇꜱᴛ Aᴄᴄᴏᴜɴᴛ Gᴇɴᴇʀᴀᴛᴏʀ"),
    ("level", "Aᴜᴛᴏ Lᴇᴠᴇʟ Sᴇʀᴠɪᴄᴇ"),
    ("glory", "Gᴜɪʟᴅ Gʟᴏʀʏ Sᴇʀᴠɪᴄᴇ"),
    ("refer", "Rᴇꜰᴇʀ Aɴᴅ Eᴀʀɴ"),
    ("referral", "Rᴇꜰᴇʀ Aɴᴅ Eᴀʀɴ"),
    ("invite", "Yᴏᴜʀ Iɴᴠɪᴛᴇ Lɪɴᴋ"),
    ("mylink", "Yᴏᴜʀ Iɴᴠɪᴛᴇ Lɪɴᴋ"),
    ("myrefs", "Yᴏᴜʀ Rᴇꜰᴇʀʀᴀʟꜱ"),
    ("credits", "Yᴏᴜʀ Cʀᴇᴅɪᴛꜱ"),
    ("balance", "Yᴏᴜʀ Wᴀʟʟᴇᴛ"),
    ("bal", "Yᴏᴜʀ Wᴀʟʟᴇᴛ"),
    ("wallet", "Yᴏᴜʀ Wᴀʟʟᴇᴛ"),
    ("redeem", "Rᴇᴅᴇᴇᴍ A Cʀᴇᴅɪᴛ Cᴏᴅᴇ"),
    ("code", "Rᴇᴅᴇᴇᴍ A Cʀᴇᴅɪᴛ Cᴏᴅᴇ"),
    ("claim", "Tᴜʀɴ Cʀᴇᴅɪᴛꜱ Iɴᴛᴏ Aᴜᴛᴏʟɪᴋᴇ"),
    ("claimlikes", "Sᴀᴍᴇ Aꜱ Cʟᴀɪᴍ"),
    ("mykeys", "Yᴏᴜʀ Pᴜʀᴄʜᴀꜱᴇ Kᴇʏꜱ"),
    ("keys", "Yᴏᴜʀ Pᴜʀᴄʜᴀꜱᴇ Kᴇʏꜱ"),
    ("usekey", "Aᴄᴛɪᴠᴀᴛᴇ Aᴜᴛᴏʟɪᴋᴇ Wɪᴛʜ A Kᴇʏ"),
    ("keyinfo", "Kᴇʏ Bᴀʟᴀɴᴄᴇ Aɴᴅ Vᴀʟɪᴅɪᴛʏ"),
    ("myauto", "Yᴏᴜʀ Aᴜᴛᴏʟɪᴋᴇ Sʟᴏᴛꜱ"),
    ("mystats", "Yᴏᴜʀ Pᴇʀꜱᴏɴᴀʟ Sᴛᴀᴛꜱ"),
    ("mylikes", "Lɪᴋᴇꜱ Yᴏᴜ Rᴇᴄᴇɪᴠᴇᴅ"),
    ("history", "Yᴏᴜʀ Rᴇᴄᴇɴᴛ Aᴄᴛɪᴠɪᴛʏ"),
    ("orderstatus", "Yᴏᴜʀ Oʀᴅᴇʀꜱ"),
    ("stopauto", "Pᴀᴜꜱᴇ Yᴏᴜʀ Oᴡɴ Sʟᴏᴛ"),
    ("startauto", "Rᴇꜱᴜᴍᴇ Yᴏᴜʀ Oᴡɴ Sʟᴏᴛ"),
    ("splitkey", "Sᴘʟɪᴛ Kᴇʏ Lɪᴋᴇꜱ Aᴄʀᴏꜱꜱ Uɪᴅꜱ"),
    ("regions", "Sᴜᴘᴘᴏʀᴛᴇᴅ Rᴇɢɪᴏɴꜱ"),
    ("servers", "Sᴜᴘᴘᴏʀᴛᴇᴅ Rᴇɢɪᴏɴꜱ"),
    ("stats", "Lɪᴠᴇ Sᴛᴀᴛɪꜱᴛɪᴄꜱ"),
    ("top", "Tᴏᴘ Pʟᴀʏᴇʀꜱ"),
    ("leaderboard", "Tᴏᴘ Pʟᴀʏᴇʀꜱ"),
    ("runs", "Aᴜᴛᴏʟɪᴋᴇ Rᴜɴ Tɪᴍᴇꜱ"),
    ("faq", "Cᴏᴍᴍᴏɴ Qᴜᴇꜱᴛɪᴏɴꜱ"),
    ("rules", "Sᴇʀᴠɪᴄᴇ Rᴜʟᴇꜱ"),
    ("terms", "Tᴇʀᴍꜱ Oꜰ Uꜱᴇ"),
    ("privacy", "Pʀɪᴠᴀᴄʏ Nᴏᴛᴇ"),
    ("refund", "Rᴇꜰᴜɴᴅ Pᴏʟɪᴄʏ"),
    ("speed", "Dᴇʟɪᴠᴇʀʏ Sᴘᴇᴇᴅ"),
    ("ping", "Bᴏᴛ Rᴇꜱᴘᴏɴꜱᴇ Tɪᴍᴇ"),
    ("status", "Sᴇʀᴠɪᴄᴇ Sᴛᴀᴛᴜꜱ"),
    ("uptime", "Bᴏᴛ Uᴘᴛɪᴍᴇ"),
    ("id", "Yᴏᴜʀ Tᴇʟᴇɢʀᴀᴍ Iᴅ"),
    ("me", "Yᴏᴜʀ Aᴄᴄᴏᴜɴᴛ Cᴀʀᴅ"),
    ("dashboard", "Oᴘᴇɴ Tʜᴇ Wᴇʙ Dᴀꜱʜʙᴏᴀʀᴅ"),
    ("version", "Bᴏᴛ Vᴇʀꜱɪᴏɴ"),
]

ADMIN_COMMANDS = [
    ("panel", "Oᴡɴᴇʀ Dᴀꜱʜʙᴏᴀʀᴅ"),
    ("admin", "Oᴡɴᴇʀ Dᴀꜱʜʙᴏᴀʀᴅ"),
    ("analytics", "Aɴᴀʟʏᴛɪᴄꜱ Bʏ Rᴀɴɢᴇ"),
    ("autolike", "Aᴅᴅ Aɴ Aᴜᴛᴏʟɪᴋᴇ Sʟᴏᴛ"),
    ("listauto", "Lɪꜱᴛ Aʟʟ Sʟᴏᴛꜱ"),
    ("removeauto", "Rᴇᴍᴏᴠᴇ A Sʟᴏᴛ"),
    ("pause", "Pᴀᴜꜱᴇ A Sʟᴏᴛ"),
    ("resume", "Rᴇꜱᴜᴍᴇ A Sʟᴏᴛ"),
    ("runall", "Rᴜɴ Eᴠᴇʀʏ Sʟᴏᴛ Nᴏᴡ"),
    ("setruns", "Sᴇᴛ Rᴜɴꜱ Pᴇʀ Dᴀʏ (1-7)"),
    ("genkey", "Cʀᴇᴀᴛᴇ A Bᴜʏᴇʀ Kᴇʏ"),
    ("delkey", "Dɪꜱᴀʙʟᴇ A Kᴇʏ"),
    ("gencode", "Cʀᴇᴀᴛᴇ A Cʀᴇᴅɪᴛ Cᴏᴅᴇ"),
    ("orders", "Pᴇɴᴅɪɴɢ Oʀᴅᴇʀꜱ"),
    ("approve", "Aᴘᴘʀᴏᴠᴇ Aɴ Oʀᴅᴇʀ"),
    ("reject", "Rᴇᴊᴇᴄᴛ Aɴ Oʀᴅᴇʀ"),
    ("addcredits", "Gɪᴠᴇ Cʀᴇᴅɪᴛꜱ Tᴏ A Uꜱᴇʀ"),
    ("addlikes", "Gɪᴠᴇ Lɪᴋᴇ Bᴀʟᴀɴᴄᴇ"),
    ("addapi", "Aᴅᴅ A Sᴏᴜʀᴄᴇ"),
    ("delapi", "Rᴇᴍᴏᴠᴇ A Sᴏᴜʀᴄᴇ"),
    ("listapi", "Sᴏᴜʀᴄᴇ Hᴇᴀʟᴛʜ"),
    ("addgroup", "Aᴅᴅ A Gʀᴏᴜᴘ Sʟᴏᴛ"),
    ("bindlog", "Bɪɴᴅ Tʜɪꜱ Cʜᴀᴛ Aꜱ Lᴏɢ"),
    ("broadcast", "Mᴇꜱꜱᴀɢᴇ Eᴠᴇʀʏ Uꜱᴇʀ"),
    ("ban", "Bᴀɴ A Uꜱᴇʀ"),
    ("unban", "Uɴʙᴀɴ A Uꜱᴇʀ"),
    ("users", "Lᴀᴛᴇꜱᴛ Uꜱᴇʀꜱ"),
    ("finduser", "Sᴇᴀʀᴄʜ A Uꜱᴇʀ"),
    ("backup", "Sᴇɴᴅ Tʜᴇ Dᴀᴛᴀʙᴀꜱᴇ"),
    ("cleanup", "Rᴇᴍᴏᴠᴇ Fɪɴɪꜱʜᴇᴅ Sʟᴏᴛꜱ"),
]


def cmds_text(admin: bool = False) -> str:
    out = [f"📜 <b>{fancy('Command Book')}</b>", ""]
    for c, d in USER_COMMANDS:
        out.append(f"🔹 <code>/{c}</code> — {d}")
    if admin:
        out += ["", f"👑 <b>{fancy('Owner Commands')}</b>", ""]
        for c, d in ADMIN_COMMANDS:
            out.append(f"🔸 <code>/{c}</code> — {d}")
    out += ["", f"🧮 {fancy('Total Commands')}: <b>{len(USER_COMMANDS) + len(ADMIN_COMMANDS)}</b>"]
    return "<b>" + "\n".join(out)[:3900] + "</b>"


def claim_text(credits: int) -> str:
    unit = config.CREDIT_REDEEM_UNIT
    blocks = credits // unit
    body = [
        f"🎁 <b>{fancy('Claim Free Autolike')}</b>", "",
        f"🎟 {fancy('Your Credits')}: <b>{credits}</b>",
        f"📦 {fancy('Usable Blocks')}: <b>{blocks}</b> x {unit} {fancy('Credits')}",
        f"❤️ {fancy('Autolike Likes')}: <b>{blocks * config.LIKES_PER_CREDIT_UNIT:,}</b>",
        f"🧮 {fancy('Leftover Credits')}: <b>{credits % unit}</b>", "",
        f"💡 {unit} {fancy('Credits')} = <b>{config.LIKES_PER_CREDIT_UNIT:,} {fancy('Autolike Likes')}</b>",
        f"🌍 {fancy('Pick The Region Then Send The Uid')} 👇",
    ]
    return wrap("\n".join(body))
