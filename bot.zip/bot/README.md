# 🔥 ROCKS AUTOLIKES — Telegram Bot + Neon Mini App

One process, one database. The Telegram bot and the public website (`https://rocksautolikes.freesrv.com`)
read and write the exact same SQLite file, so they are always twinned.

---

## 🚀 Wispbyte / VPS setup

| Setting | Value |
|---|---|
| Start command | `python start.py` |
| Port | `9306` |
| Bind | `0.0.0.0` (already handled by `start.py`) |
| Python | 3.10+ |

```sh
pip install -r requirements.txt
python start.py
```

### Environment variables

| Variable | Required | Default | Purpose |
|---|---|---|---|
| `TELEGRAM_BOT_TOKEN` | ✅ | — | Bot token from @BotFather. If missing, the website still boots alone. |
| `PORT` | ➖ | `9306` | Web port. |
| `HOST` | ➖ | `0.0.0.0` | Bind address — do not change on Wispbyte. |
| `PUBLIC_URL` | ➖ | `https://rocksautolikes.freesrv.com` | Used for Mini App buttons and links. |
| `BOT_USERNAME` | ➖ | `rockschatbot` | Used for refer links. |
| `ADMIN_IDS` | ➖ | `6394789927,7127454894,8664344820` | Comma separated admin IDs. |
| `LOG_GROUP_ID` | ➖ | — | Numeric `-100…` id, or set it live with `/bindlog`. |
| `ROCKS_DB` | ➖ | `rocks.db` next to the code | Shared database path. |
| `DASH_PASS_1` / `DASH_PASS_2` | ➖ | `ROCK$765` / `RAYANROCKSYT3688500765` | Owner dashboard gate. |
| `WEB_THREADS` | ➖ | `8` | Waitress worker threads. |

> **Forbidden error fix:** the site binds `0.0.0.0` on `$PORT` and every public route
> (`/`, `/app`, `/miniapp`, `/static/*`, `/health`, `/api/public/*`) is open with no key.

---

## 🌐 Website routes

| Route | Access | What it is |
|---|---|---|
| `/`, `/app`, `/miniapp` | public | Neon Black + Blue Mini App (Home, Check, Buy, Refer, About) |
| `/static/*` | public | Banner + cropped QR scanners |
| `/health` | public | Uptime JSON |
| `/api/public/config` | public | Brand, regions, plans, socials, payment details |
| `/api/public/stats` | public | Live totals (players, likes, orders) |
| `/api/public/buyers` | public | Live buyers feed (UID masked) |
| `/api/public/info?uid=&region=` | public | Player lookup, info API 1 → API 2 fallback |
| `/api/public/chat` | public | Rocks Assistant chatbot |
| `/api/me`, `/api/redeem` | Telegram `initData` verified | Account + redeem |
| `/api/dash/*` | two-password token | Owner dashboard |

### 👑 Owner Dashboard

Long-press the top-left **ROCKS AUTOLIKES** logo for 5 seconds →
password 1 `ROCK$765` → password 2 `RAYANROCKSYT3688500765` →
charts (day / week / month / quarter / half / year) for likes, purchases and revenue,
plus users, autolikes, purchases, keys, APIs, groups and logs tables.

---

## 🤖 Bot commands

**User**

| Command | What it does |
|---|---|
| `/start` | Welcome card + inline menu |
| `/help`, `/cmds` | All commands, grouped by category |
| `/like` | Send likes — region → UID → likes (group only for normal users) |
| `/info <region> <uid>` | Player name, UID, level, likes |
| `/plans` | 8 plans in ₹ / $ / ⭐ |
| `/regions` | All 12 supported regions |
| `/balance` | Credits + likes balance |
| `/refer`, `/claim`, `/redeem <code>` | Referral system — 5 invites = 5 credits = 1,000 likes |
| `/usekey <key>` | Redeem a likes key |
| `/about`, `/app` | About pages + Mini App button |

**Admin only**

| Command | What it does |
|---|---|
| `/autolike` | Region → UID → likes, unlimited slots |
| `/listauto`, `/removeauto`, `/pause`, `/resume` | Manage autolike slots |
| `/runall` | Run every slot now and post to the log group |
| `/setruns 1-11` | Runs per day with per-slot times |
| `/code`, `/genkey` | Create redeem codes and likes keys |
| `/orders`, `/approve` | Payment queue |
| `/stats`, `/analytics`, `/panel` | Totals, graphs, owner panel |
| `/addapi`, `/delapi`, `/listapi` | Manage the 17 like APIs + 2 info APIs |
| `/addgroup`, `/bindlog` | Force-join groups and log group binding |
| `/broadcast`, `/ban`, `/unban` | Broadcast and moderation |

---

## 💳 Payments

- **UPI (INR):** `ayeshataj2300@oksbi` — scanner in `static/qr_upi.jpg`
- **USDT (BEP20):** `0x707d4c5F6f86BbC0395c39e3bB66e87eae6373Da` — scanner in `static/qr_usdt.jpg`
- **Telegram Stars:** native checkout inside the bot
- 7-minute live countdown with **Paid** / **Cancel** buttons, screenshot + txn id forwarded to the owner.

---

## 🗄️ Database

Single SQLite file (`rocks.db` by default) holding users, autolikes, like logs, purchases,
keys, refer codes, referrals, APIs, groups and events. A legacy `bot_data.json` sitting next
to the code is imported automatically on first boot. Back it up by copying that one file.

---

## 🔒 Security

Validated input on every endpoint (UID digits only, region allowlist, code pattern),
Telegram `initData` HMAC verification on writes, per-IP rate limiting, hashed-compare
dashboard passwords with expiring tokens, CSP + hardening headers, no directory listing,
JSON error pages and parameterised SQL everywhere.
