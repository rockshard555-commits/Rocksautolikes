"""ROCKS AUTOLIKES — one-process launcher (Telegram bot + Mini App website).

Runs the public website with waitress on 0.0.0.0:$PORT (default 9306) in a
daemon thread, and the Telegram bot polling loop in the main thread.
Both sides share the exact same SQLite database (config.DB_PATH).

Wispbyte start command:  python start.py
"""
from __future__ import annotations

import logging
import os
import signal
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config  # noqa: E402
import db  # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("rocks.start")

HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", str(config.PORT)))
THREADS = int(os.getenv("WEB_THREADS", "8"))

_stop = threading.Event()


def banner() -> None:
    line = "═" * 58
    print(f"\n\033[96m{line}\033[0m")
    print("\033[94m  🔥 ROCKS AUTOLIKES — BOT + MINI APP\033[0m")
    print(f"\033[96m{line}\033[0m")
    print(f"  🌐 Local      : http://{HOST}:{PORT}/")
    print(f"  🚀 Public     : {config.PUBLIC_URL}")
    print(f"  📲 Mini App   : {config.PUBLIC_URL}/miniapp")
    print(f"  💬 Log group  : {config.LOG_GROUP_LINK}")
    print(f"  🗄️  Database   : {config.DB_PATH}")
    print(f"  👑 Admins     : {', '.join(str(a) for a in config.ADMIN_IDS)}")
    print(f"  🤖 Bot token  : {'set ✅' if config.BOT_TOKEN else 'MISSING ❌ (website only)'}")
    print(f"\033[96m{line}\033[0m\n")


def serve_web() -> None:
    """Serve the Flask app with waitress (falls back to Flask dev server)."""
    try:
        import webapp

        app = webapp.create_app()
    except Exception:  # noqa: BLE001
        log.exception("❌ website failed to start")
        return
    try:
        from waitress import serve

        log.info("🌐 website listening on http://%s:%s (waitress, %s threads)", HOST, PORT, THREADS)
        serve(app, host=HOST, port=PORT, threads=THREADS, ident="rocks", clear_untrusted_proxy_headers=True)
    except ImportError:
        log.warning("⚠️ waitress not installed — falling back to the Flask server")
        app.run(host=HOST, port=PORT, debug=False, threaded=True, use_reloader=False)
    except Exception:  # noqa: BLE001
        log.exception("❌ website crashed")


def run_bot() -> None:
    import main as bot_main

    bot_main.main()


def _shutdown(signum, _frame):
    log.info("👋 signal %s received — shutting down", signum)
    _stop.set()
    os._exit(0)


def start() -> None:
    db.init()
    banner()

    web = threading.Thread(target=serve_web, name="rocks-web", daemon=True)
    web.start()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, _shutdown)
        except (ValueError, AttributeError):
            pass

    if not config.BOT_TOKEN:
        log.warning("⚠️ TELEGRAM_BOT_TOKEN is not set — running the website only")
        while not _stop.is_set() and web.is_alive():
            time.sleep(1)
        return

    try:
        run_bot()
    except KeyboardInterrupt:
        log.info("👋 stopped by keyboard")
    except SystemExit as exc:
        log.error("❌ bot exited: %s", exc)
        while not _stop.is_set() and web.is_alive():
            time.sleep(1)


if __name__ == "__main__":
    start()
