"""ROCKS AUTOLIKES — central configuration (bot + mini app share this)."""
import os

# ─────────────────────────── CORE ───────────────────────────
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "8715963259:AAFxiQMILZpFpkuPYUoLfecQsUG1rk3vmfk").strip()
BOT_USERNAME = os.getenv("BOT_USERNAME", "rockschatbot").lstrip("@")

OWNER_HANDLE = "@rockschatbot"
OWNER_URL = "https://t.me/rockschatbot"
SUPPORT_HANDLE = "@rockschatbot"

ADMIN_IDS = [
    int(x) for x in os.getenv("ADMIN_IDS", "6394789927,7127454894,8664344820").replace(" ", "").split(",") if x
]
OWNER_ID = ADMIN_IDS[0]

LOG_GROUP_LINK = "https://t.me/+4gCNKEKKh-YwOTI1"
LOG_GROUP_ID = os.getenv("LOG_GROUP_ID", "")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.getenv("ROCKS_DB", os.path.join(BASE_DIR, "rocks.db"))
LEGACY_JSON = os.path.join(BASE_DIR, "bot_data.json")

PORT = int(os.getenv("PORT", "9306"))
PUBLIC_URL = os.getenv("PUBLIC_URL", "https://rocksautolikes.freesrv.com")

# Owner dashboard — two-stage gate (long-press the logo for 5s)
DASH_PASS_1 = os.getenv("DASH_PASS_1", "ROCK$765")
DASH_PASS_2 = os.getenv("DASH_PASS_2", "RAYANROCKSYT3688500765")

IST_TZ = "Asia/Kolkata"
PAYMENT_TIMER_SECONDS = int(os.getenv("PAYMENT_TIMER_SECONDS", "420"))
PAYMENT_TICK_SECONDS = 1  # countdown edits every second

# Free Fire add-friend / share link (working format)
FF_SHARE_URL = ("https://ffshare.garena.com/?action=qrcode_add_friend&region={region}"
                "&lang=en&uid={uid}&generation_channel=0&version=OB54")


def ff_share_link(uid: str, region: str = "IND") -> str:
    return FF_SHARE_URL.format(uid=str(uid).strip(), region=(region or "IND").upper())


# ─────────────────────────── REGIONS ───────────────────────────
REGIONS = {
    "IND": {"name": "India", "flag": "🇮🇳"},
    "BD":  {"name": "Bangladesh", "flag": "🇧🇩"},
    "ID":  {"name": "Indonesia", "flag": "🇮🇩"},
    "ME":  {"name": "Middle East", "flag": "🌍"},
    "VN":  {"name": "Vietnam", "flag": "🇻🇳"},
    "TH":  {"name": "Thailand", "flag": "🇹🇭"},
    "CIS": {"name": "Cis", "flag": "🌍"},
    "PK":  {"name": "Pakistan", "flag": "🇵🇰"},
    "SG":  {"name": "Singapore", "flag": "🇸🇬"},
    "EU":  {"name": "Europe", "flag": "🇪🇺"},
    "TW":  {"name": "Taiwan", "flag": "🇹🇼"},
    "RU":  {"name": "Russia", "flag": "🇷🇺"},
}


def region_label(code: str) -> str:
    code = (code or "").upper()
    meta = REGIONS.get(code)
    if not meta:
        return code
    return f"{meta['flag']} {meta['name']} ({code})"


# ─────────────────────────── LIKE APIS ───────────────────────────
# Users only ever see V1, V2, V3 … never names, URLs or how many exist.
DEFAULT_LIKE_APIS = [
    "https://bot220.vercel.app//like?uid={uid}&server_name={region}",
    "https://likeapi-ten.vercel.app/like?uid={uid}&server_name={region}",
    "https://silent-like-shop-api-production.up.railway.app/like?uid={uid}&server_name={region}&key=SILENT-OP",
    "https://methodlike.vercel.app/like?uid={uid}&server_name={region}&key=vertex",
    "https://aditya-free-like.onrender.com/like?uid={uid}&server_name={region}&key=free60remain",
    "https://fflikeapi.vercel.app/like?uid={uid}&server_name={server}&key=free40remain",
    "https://www.silent-codex-api.shop/like?uid={uid}&server_name={region}&key=GIVEWAY",
]

# Bump when the list changes — db.init() then wipes and reseeds the slots.
LIKE_API_REVISION = "v5-7apis"

DEFAULT_INFO_APIS = [
    "https://vertex-info-api.vercel.app/get?uid={uid}&region={region}",
    "https://ajay-new-all-region-info-api.vercel.app/ajay-info?uid={uid}&key=Ajay",
]

# ─────────────────────────── PLANS ───────────────────────────
# Prices/USD/Stars unchanged; only like counts changed, 15k plan removed.
PLANS = [
    {"id": 1, "likes": 5555,   "inr": 111,  "usd": 2,  "stars": 33,  "label": "🥉 Starter",   "tag": ""},
    {"id": 2, "likes": 11111,  "inr": 222,  "usd": 4,  "stars": 66,  "label": "🥈 Boost",     "tag": "🔥 Most Popular"},
    {"id": 4, "likes": 22222,  "inr": 444,  "usd": 8,  "stars": 177, "label": "💎 Elite",     "tag": ""},
    {"id": 5, "likes": 30000,  "inr": 666,  "usd": 12, "stars": 222, "label": "👑 Legend",    "tag": ""},
    {"id": 6, "likes": 55555,  "inr": 1111, "usd": 20, "stars": 444, "label": "🔥 Premium",   "tag": "👑 Best Value"},
    {"id": 7, "likes": 77777,  "inr": 1666, "usd": 30, "stars": 666, "label": "⚡ Ultra",     "tag": ""},
    {"id": 8, "likes": 111111, "inr": 2222, "usd": 40, "stars": 888, "label": "🏆 Legendary", "tag": ""},
]

# ─────────────────────────── PAYMENTS ───────────────────────────
UPI_ID = os.getenv("UPI_ID", "ayeshataj2300@oksbi")
UPI_NAME = os.getenv("UPI_NAME", "Ayesha Taj")
USDT_ADDRESS = os.getenv("USDT_ADDRESS", "0x707d4c5F6f86BbC0395c39e3bB66e87eae6373Da")
USDT_NETWORK = "BNB Smart Chain (BEP20)"

# ─────────────────────────── SOCIALS / ABOUT ───────────────────────────
SOCIALS = [
    {"key": "youtube",   "emoji": "📺", "title": "Youtube",   "handle": "@RAYANROCKS-FF",
     "url": "https://youtube.com/@RAYANROCKS-FF", "qr": "qr_yt.jpg"},
    {"key": "instagram", "emoji": "📸", "title": "Instagram", "handle": "@rayanrocksyt",
     "url": "https://instagram.com/rayanrocksyt", "qr": "qr_ig.jpg"},
    {"key": "telegram",  "emoji": "💬", "title": "Telegram",  "handle": "Rocks Community",
     "url": LOG_GROUP_LINK, "qr": "qr_tg.jpg"},
    {"key": "freefire",  "emoji": "🎮", "title": "Free Fire", "handle": "RAYANROCKSYT • 3688500765",
     "url": FF_SHARE_URL.format(uid="3688500765", region="IND"), "qr": "qr_ff.jpg"},
]

FF_PROFILE = {"name": "RAYANROCKSYT", "uid": "3688500765", "region": "IND", "server": "India 🇮🇳"}
FF_PROFILE_LINK = FF_SHARE_URL.format(uid=FF_PROFILE["uid"], region=FF_PROFILE["region"])

# Site artwork (7 generated images)
SITE_IMAGES = [f"auto{i}.jpg" for i in range(1, 8)]

# Referral economy — 5 credits = 1111 autolike likes, multiples of 5 only
REFER_CREDIT_PER_INVITE = 1
CREDIT_REDEEM_UNIT = 5
LIKES_PER_CREDIT_UNIT = 1111
CREDITS_PER_1K_LIKES = CREDIT_REDEEM_UNIT  # legacy alias

USER_LIKE_COOLDOWN_HOURS = 24
MAX_AUTOLIKE_RUNS = 7
