"""ROCKS AUTOLIKES — Telegram bot (v4 MAX).

Runs together with the mini app from start.py, sharing one SQLite database.
Everything is inline-button driven, every screen has Back / More.
"""
import asyncio
import html
import json
import logging
import os
import random
import re
import secrets
import string
import time
from datetime import datetime, timedelta

from telegram import (InlineKeyboardButton as B, InlineKeyboardMarkup as M,
                      InputFile, LabeledPrice, Update)
from telegram.constants import ParseMode
from telegram.error import BadRequest
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler,
                          ContextTypes, MessageHandler, PreCheckoutQueryHandler,
                          filters)

import config
import db
import likes as engine
import ui
from style import LINE, fancy, progress_bar, wrap

logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s", level=logging.INFO)
log = logging.getLogger("rocks")

BASE = os.path.dirname(os.path.abspath(__file__))
BANNER = os.path.join(BASE, "static", "banner.jpg")
HERO_VIDEO = os.path.join(BASE, "static", "hero.mp4")

UID_RE = re.compile(r"^\d{6,14}$")


def is_admin(uid: int) -> bool:
    return int(uid) in config.ADMIN_IDS


def valid_region(code: str) -> bool:
    return (code or "").upper() in config.REGIONS


async def send_card(target, text: str, markup=None, context=None):
    """Send the banner/video card with the text under it (falls back to text)."""
    try:
        if os.path.exists(HERO_VIDEO):
            with open(HERO_VIDEO, "rb") as f:
                return await target.reply_video(video=f, caption=text, parse_mode=ParseMode.HTML,
                                                reply_markup=markup, supports_streaming=True)
        if os.path.exists(BANNER):
            with open(BANNER, "rb") as f:
                return await target.reply_photo(photo=f, caption=text, parse_mode=ParseMode.HTML,
                                                reply_markup=markup)
    except Exception as e:  # noqa: BLE001
        log.warning("card send failed: %s", e)
    return await target.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=markup,
                                   disable_web_page_preview=True)


async def edit(q, text: str, markup=None):
    try:
        if q.message and (q.message.photo or q.message.video):
            await q.edit_message_caption(caption=text, parse_mode=ParseMode.HTML, reply_markup=markup)
        else:
            await q.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=markup,
                                      disable_web_page_preview=True)
    except BadRequest as e:
        if "not modified" not in str(e).lower():
            try:
                await q.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=markup,
                                           disable_web_page_preview=True)
            except Exception:
                pass


async def log_to_group(context, text: str):
    chat_id = db.get_setting("log_chat_id") or config.LOG_GROUP_ID
    if not chat_id:
        return
    try:
        await context.bot.send_message(int(chat_id), text, parse_mode=ParseMode.HTML,
                                       disable_web_page_preview=True)
    except Exception as e:  # noqa: BLE001
        log.warning("log group failed: %s", e)


def touch_user(update: Update):
    u = update.effective_user
    if u:
        db.upsert_user(u.id, u.username or "", u.first_name or "")
    return u


# ══════════════════════════ COMMANDS ══════════════════════════
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    args = context.args or []
    if args and args[0].startswith("ref"):
        await handle_referral(u.id, args[0][3:], context)
    await send_card(update.message, ui.start_text(u.first_name or "Player", is_admin(u.id)),
                    ui.main_menu(is_admin(u.id)), context)


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await update.message.reply_text(ui.help_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=M([ui.back_row(more="m:more")]))


async def cmd_cmds(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await update.message.reply_text(ui.cmds_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=M([ui.back_row(more="m:more")]))


async def cmd_about(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await update.message.reply_text(about_home_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=ui.about_menu())


def about_home_text() -> str:
    body = [
        f"ℹ️ <b>{fancy('About Rocks Autolikes')}</b> 🔥", "",
        f"🎮 {fancy('Free Fire Uid')}: <b>{config.FF_PROFILE['uid']}</b>",
        f"👤 {fancy('Name')}: <b>{config.FF_PROFILE['name']}</b>",
        f"🌍 {fancy('Server')}: <b>{config.FF_PROFILE['server']}</b>", "",
        f"📺 {fancy('Youtube')}: <b>@RAYANROCKS-FF</b>",
        f"📸 {fancy('Instagram')}: <b>@rayanrocksyt</b>",
        f"💬 {fancy('Telegram')}: <b>{config.OWNER_HANDLE}</b>", "",
        f"👇 {fancy('Open Any Page For Its Scanner And Link')} 📱",
    ]
    return wrap("\n".join(body))


async def cmd_app(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    body = f"📱 <b>{fancy('Rocks Autolikes Mini App')}</b>\n\n🌐 {fancy('Tap Below To Open The Full Dashboard')} 🚀"
    from telegram import WebAppInfo
    await update.message.reply_text(wrap(body), parse_mode=ParseMode.HTML, reply_markup=M([
        [B("📱 Oᴘᴇᴎ Mɪᴎɪ Aᴘᴘ", web_app=WebAppInfo(url=config.PUBLIC_URL))],
        [B("🌐 Oᴘᴇᴎ Iᴎ Bʀᴏᴡꜱᴇʀ", url=config.PUBLIC_URL)],
        ui.back_row(),
    ]))


async def cmd_plans(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await update.message.reply_text(ui.plans_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=ui.plans_keyboard())


async def cmd_regions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(ui.regions_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=M([ui.back_row(more="m:more")]))


async def cmd_balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    await update.message.reply_text(balance_text(u.id), parse_mode=ParseMode.HTML,
                                    reply_markup=M([ui.back_row(more="m:more")]))


def balance_text(user_id: int) -> str:
    row = db.get_user(user_id) or {}
    body = (
        f"💰 <b>{fancy('Your Wallet')}</b> 👛\n\n"
        f"🎟 {fancy('Credits')}: <b>{row.get('credits',0)}</b>\n"
        f"❤️ {fancy('Like Balance')}: <b>{row.get('likes_balance',0):,}</b>\n"
        f"👥 {fancy('Referrals')}: <b>{row.get('refer_count',0)}</b>\n"
        f"📊 {fancy('Likes Received Total')}: <b>{row.get('total_likes',0):,}</b>\n\n"
        f"🎁 {config.CREDITS_PER_1K_LIKES} {fancy('Credits')} = <b>1000 {fancy('Likes')}</b> ⚡"
    )
    return wrap(body)


# ─────────────────────── LIVE PROGRESS ───────────────────────
async def run_with_progress(status_msg, uid: str, region: str, target: int):
    """Run send_likes in a worker thread while editing the live percentage."""
    loop = asyncio.get_running_loop()
    latest: dict = {}
    last_edit = {"t": 0.0, "text": ""}

    def on_progress(state: dict):
        latest.clear()
        latest.update(state)
        now = time.time()
        if state.get("stage") != "done" and now - last_edit["t"] < 1.5:
            return
        last_edit["t"] = now
        text = ui.progress_text(state, uid, region)
        if text == last_edit["text"]:
            return
        last_edit["text"] = text
        asyncio.run_coroutine_threadsafe(_safe_edit(status_msg, text), loop)

    return await asyncio.to_thread(engine.send_likes, uid, region, target, on_progress=on_progress)


async def _safe_edit(msg, text: str):
    try:
        await msg.edit_text(text, parse_mode=ParseMode.HTML)
    except BadRequest:
        pass
    except Exception:  # noqa: BLE001
        pass


# ─────────────────────── LIKE ───────────────────────

async def cmd_like(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    chat = update.effective_chat
    admin = is_admin(u.id)
    log_chat = db.get_setting("log_chat_id") or config.LOG_GROUP_ID

    if not admin:
        if chat.type == "private" or (log_chat and str(chat.id) != str(log_chat)):
            return await update.message.reply_text(
                wrap(f"🚫 <b>{fancy('Likes Work Only In Our Community Group')}</b> 💬\n\n"
                     f"👉 {fancy('Join And Use The Command There')} 🔗"),
                parse_mode=ParseMode.HTML,
                reply_markup=M([[B("💬 Jᴏɪᴎ Gʀᴏᴜᴘ", url=config.LOG_GROUP_LINK)], ui.back_row()]))

    args = context.args or []
    if len(args) < 2:
        return await update.message.reply_text(
            wrap(f"⚠️ <b>{fancy('Wrong Format')}</b>\n\n✅ <code>/like ind 3688500765</code>\n"
                 f"🌍 {fancy('First Region Then Uid')}"),
            parse_mode=ParseMode.HTML, reply_markup=M([ui.back_row(more="m:regions")]))

    region, uid = args[0].upper(), args[1].strip()
    if not valid_region(region):
        return await update.message.reply_text(ui.regions_text(), parse_mode=ParseMode.HTML,
                                               reply_markup=M([ui.back_row()]))
    if not UID_RE.match(uid):
        return await update.message.reply_text(
            wrap(f"❌ <b>{fancy('Invalid Uid')}</b> 🔢"), parse_mode=ParseMode.HTML)

    if not admin:
        row = db.get_user(u.id) or {}
        gap = db.ts() - int(row.get("last_like_at") or 0)
        if gap < config.USER_LIKE_COOLDOWN_HOURS * 3600:
            left = config.USER_LIKE_COOLDOWN_HOURS * 3600 - gap
            return await update.message.reply_text(
                wrap(f"⏳ <b>{fancy('Daily Limit Reached')}</b>\n\n"
                     f"🕐 {fancy('Try Again In')}: <b>{left//3600}ʜ {(left%3600)//60}ᴍ</b>\n"
                     f"💎 {fancy('Buy A Plan For Unlimited Autolike')} 🛒"),
                parse_mode=ParseMode.HTML, reply_markup=M([[B("💎 Vɪᴇᴡ Pʟᴀᴎꜱ", callback_data="m:plans")], ui.back_row()]))

    target = 100
    if len(args) >= 3 and args[2].isdigit():
        target = max(1, min(int(args[2]), 999999 if admin else 100))

    status = await update.message.reply_text(
        ui.progress_text({"stage": "lookup", "pct": 1}, uid, region), parse_mode=ParseMode.HTML)
    res = await run_with_progress(status, uid, region, target)


    if res["given"] <= 0:
        await status.edit_text(
            wrap(f"🚫 <b>{fancy('Autolike Already Sended')}</b> ⏳\n\n"
                 f"👤 {fancy('Player')}: <b>{res['nickname']}</b>\n"
                 f"❤️ {fancy('Current Likes')}: <b>{res['after']:,}</b>\n"
                 f"🕐 {fancy('Try Again After 24 Hours')}"),
            parse_mode=ParseMode.HTML, reply_markup=M([ui.back_row(more="m:more")]))
        return

    db.log_like(uid, region, res["nickname"], res["before"], res["after"], res["given"],
                res["sources"], "like", u.id)
    db.run("UPDATE users SET last_like_at=?, total_likes=total_likes+? WHERE user_id=?",
           (db.ts(), res["given"], u.id))
    text = ui.like_result_text(res)
    await status.delete()
    await send_card(update.message, text, M([
        [B("🔁 Sᴇᴎᴅ Aɢᴀɪᴎ", callback_data="m:like"), B("🔎 Iᴎꜰᴏ", callback_data="m:info")],
        ui.back_row(more="m:more")]), context)
    await log_to_group(context, wrap(
        f"📥 <b>{fancy('New Like Request')}</b> ❤️\n"
        f"👤 {fancy('By')}: <a href='tg://user?id={u.id}'>{html.escape(u.first_name or 'User')}</a>\n"
        f"🆔 {fancy('Uid')}: <b>{uid}</b> • {config.region_label(region)}\n"
        f"❤️ {fancy('Given')}: <b>{res['given']}</b> ({res['before']:,} ➜ {res['after']:,})"))


async def cmd_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    args = context.args or []
    if len(args) < 2:
        return await update.message.reply_text(
            wrap(f"⚠️ <b>{fancy('Wrong Format')}</b>\n\n✅ <code>/info ind 3688500765</code>"),
            parse_mode=ParseMode.HTML, reply_markup=M([ui.back_row(more="m:regions")]))
    region, uid = args[0].upper(), args[1].strip()
    if not UID_RE.match(uid):
        return await update.message.reply_text(wrap(f"❌ <b>{fancy('Invalid Uid')}</b> 🔢"),
                                               parse_mode=ParseMode.HTML)
    msg = await update.message.reply_text(wrap(f"🔎 {fancy('Searching Player')}...\n{progress_bar(35)}"),
                                          parse_mode=ParseMode.HTML)
    info = await asyncio.to_thread(engine.get_info, uid, region if valid_region(region) else "IND")
    await msg.edit_text(ui.info_text(info), parse_mode=ParseMode.HTML,
                        reply_markup=M([[B("❤️ Sᴇᴎᴅ Lɪᴋᴇꜱ", callback_data="m:like"),
                                         B("📖 Fᴜʟʟ Iᴎꜰᴏ", callback_data=f"fi:{region}:{uid}")],
                                        ui.back_row(more="m:more")]))


async def send_full_info(target, context, uid: str, region: str):
    msg = await target.reply_text(wrap(f"📖 {fancy('Loading Full Player Report')}...\n{progress_bar(40)}"),
                                  parse_mode=ParseMode.HTML)
    info = await asyncio.to_thread(engine.get_info, uid, region if valid_region(region) else "IND")
    text = ui.full_info_text(info)
    try:
        await msg.edit_text(text, parse_mode=ParseMode.HTML,
                            reply_markup=M([[B("❤️ Sᴇᴎᴅ Lɪᴋᴇꜱ", callback_data="m:like")],
                                            ui.back_row(more="m:more")]))
    except BadRequest:
        await msg.delete()
        for i in range(0, len(text), 3500):
            await target.reply_text(text[i:i + 3500], parse_mode=ParseMode.HTML)


async def cmd_fullinfo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    args = context.args or []
    if len(args) < 2:
        return await update.message.reply_text(
            wrap(f"⚠️ <b>{fancy('Wrong Format')}</b>\n\n✅ <code>/fullinfo ind 3688500765</code>"),
            parse_mode=ParseMode.HTML, reply_markup=M([ui.back_row(more="m:regions")]))
    region, uid = args[0].upper(), args[1].strip()
    if not UID_RE.match(uid):
        return await update.message.reply_text(wrap(f"❌ <b>{fancy('Invalid Uid')}</b> 🔢"),
                                               parse_mode=ParseMode.HTML)
    await send_full_info(update.message, context, uid, region)



# ─────────────────────── AUTOLIKE (admin) ───────────────────────
async def cmd_autolike(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    if not is_admin(u.id):
        return await update.message.reply_text(
            wrap(f"🚫 <b>{fancy('Autolike Is Admin Only')}</b> 👑\n💎 {fancy('Buy A Plan To Get Your Slot')}"),
            parse_mode=ParseMode.HTML, reply_markup=M([[B("💎 Pʟᴀᴎꜱ", callback_data="m:plans")], ui.back_row()]))
    args = context.args or []
    if len(args) < 3:
        return await update.message.reply_text(
            wrap(f"⚠️ <b>{fancy('Format')}</b>: <code>/autolike ind 3688500765 500</code>\n"
                 f"🌍 {fancy('Region')} ➜ 🆔 {fancy('Uid')} ➜ ❤️ {fancy('Likes')}"),
            parse_mode=ParseMode.HTML, reply_markup=M([ui.back_row()]))
    region, uid, amount = args[0].upper(), args[1], args[2]
    if not valid_region(region) or not UID_RE.match(uid) or not amount.isdigit():
        return await update.message.reply_text(wrap(f"❌ <b>{fancy('Invalid Input')}</b>"), parse_mode=ParseMode.HTML)
    amount = int(amount)
    info = await asyncio.to_thread(engine.get_info, uid, region)
    db.run("""INSERT INTO autolikes(uid,region,nickname,owner_id,likes_target,likes_left,created_at,total_days)
              VALUES(?,?,?,?,?,?,?,?)
              ON CONFLICT(uid,region) DO UPDATE SET likes_target=excluded.likes_target,
                    likes_left=autolikes.likes_left+excluded.likes_left, paused=0""",
           (uid, region, info.get("nickname", ""), u.id, min(amount, 500), amount, db.ts(), 0))
    await update.message.reply_text(wrap(
        f"✅ <b>{fancy('Autolike Slot Added')}</b> 🤖\n\n"
        f"👤 {fancy('Player')}: <b>{info.get('nickname','?')}</b>\n"
        f"🆔 {fancy('Uid')}: <b>{uid}</b>\n"
        f"🌍 {fancy('Region')}: <b>{config.region_label(region)}</b>\n"
        f"❤️ {fancy('Likes Queue')}: <b>{amount:,}</b>\n"
        f"⏰ {fancy('Runs Per Day')}: <b>{db.get_setting('runs_per_day','1')}</b>"),
        parse_mode=ParseMode.HTML, reply_markup=M([[B("📋 Lɪꜱᴛ", callback_data="a:auto"),
                                                    B("▶️ Rᴜᴎ Aʟʟ", callback_data="a:runall")], ui.back_row()]))


async def cmd_listauto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text(autolist_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=M([[B("▶️ Rᴜᴎ Aʟʟ", callback_data="a:runall")],
                                                    ui.back_row("a:panel", more="m:more")]))


def autolist_text() -> str:
    rows = db.q("SELECT * FROM autolikes ORDER BY id DESC LIMIT 40")
    if not rows:
        return wrap(f"📭 <b>{fancy('No Autolike Slots Yet')}</b>")
    out = [f"🤖 <b>{fancy('Autolike Slots')}</b> ({len(rows)})", ""]
    for r in rows:
        done = r["likes_sent"]
        total = max(1, r["likes_sent"] + r["likes_left"])
        pct = 100 * done / total
        state = "⏸ Pᴀᴜꜱᴇᴅ" if r["paused"] else "✅ Aᴄᴛɪᴠᴇ"
        out.append(
            f"🆔 <b>{r['uid']}</b> • {config.REGIONS.get(r['region'],{}).get('flag','🌍')} {r['region']} • {state}\n"
            f"   👤 {r['nickname'] or '?'} • ❤️ {done:,}/{total:,}\n   {progress_bar(pct)}")
    return wrap("\n".join(out))


async def cmd_removeauto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return
    db.run("DELETE FROM autolikes WHERE uid=?", (context.args[0],))
    await update.message.reply_text(wrap(f"🗑 <b>{fancy('Slot Removed')}</b> ✅"), parse_mode=ParseMode.HTML)


async def cmd_pause(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return
    db.run("UPDATE autolikes SET paused=1 WHERE uid=?", (context.args[0],))
    await update.message.reply_text(wrap(f"⏸ <b>{fancy('Slot Paused')}</b>"), parse_mode=ParseMode.HTML)


async def cmd_resume(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return
    db.run("UPDATE autolikes SET paused=0 WHERE uid=?", (context.args[0],))
    await update.message.reply_text(wrap(f"▶️ <b>{fancy('Slot Resumed')}</b>"), parse_mode=ParseMode.HTML)


async def run_all(context, chat_id=None, actor=0):
    rows = db.q("SELECT * FROM autolikes WHERE paused=0")
    if not rows:
        if chat_id:
            await context.bot.send_message(chat_id, wrap(f"📭 {fancy('Nothing To Run')}"), parse_mode=ParseMode.HTML)
        return
    msg = None
    if chat_id:
        msg = await context.bot.send_message(chat_id, wrap(
            f"▶️ <b>{fancy('Running All Autolike Slots')}</b>\n{progress_bar(0)}\n🤖 0/{len(rows)}"),
            parse_mode=ParseMode.HTML)
    done = 0
    for r in rows:
        target = min(r["likes_target"] or 100, r["likes_left"] or r["likes_target"] or 100)
        res = await asyncio.to_thread(engine.send_likes, r["uid"], r["region"], max(1, target))
        given = res["given"]
        if given > 0:
            db.run("""UPDATE autolikes SET likes_sent=likes_sent+?, likes_left=MAX(0,likes_left-?),
                      last_run_at=?, days_done=days_done+1, nickname=? WHERE id=?""",
                   (given, given, db.ts(), res["nickname"], r["id"]))
            db.log_like(r["uid"], r["region"], res["nickname"], res["before"], res["after"], given,
                        res["sources"], "autolike", actor)
            left = db.one("SELECT likes_left, likes_sent FROM autolikes WHERE id=?", (r["id"],))
            await log_to_group(context, ui.like_result_text(res, {
                "likes_left": left["likes_left"], "likes_total": left["likes_left"] + left["likes_sent"],
                "expire": ui.expire_str(30)}))
        else:
            await log_to_group(context, wrap(
                f"🚫 <b>{fancy('Autolike Already Sended')}</b>\n🆔 {r['uid']} • {config.region_label(r['region'])}"))
        done += 1
        if msg and done % 2 == 0:
            try:
                await msg.edit_text(wrap(f"▶️ <b>{fancy('Running All Autolike Slots')}</b>\n"
                                         f"{progress_bar(100*done/len(rows))}\n🤖 {done}/{len(rows)}"),
                                    parse_mode=ParseMode.HTML)
            except Exception:
                pass
    if msg:
        await msg.edit_text(wrap(f"✅ <b>{fancy('All Slots Completed')}</b>\n{progress_bar(100)}\n"
                                 f"🤖 {done}/{len(rows)} {fancy('Processed')}"), parse_mode=ParseMode.HTML,
                            reply_markup=M([ui.back_row("a:panel", more="m:more")]))


async def cmd_runall(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    await run_all(context, update.effective_chat.id, update.effective_user.id)


async def cmd_setruns(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    if not is_admin(u.id):
        return
    args = context.args or []
    if not args or not args[0].isdigit() or not (1 <= int(args[0]) <= config.MAX_AUTOLIKE_RUNS):
        return await update.message.reply_text(
            wrap(f"⚠️ <code>/setruns 3</code> — {fancy('Choose Between 1 And 11 Runs Per Day')} ⏰"),
            parse_mode=ParseMode.HTML)
    n = int(args[0])
    context.user_data["await"] = {"kind": "runtimes", "need": n, "times": []}
    await update.message.reply_text(wrap(
        f"⏰ <b>{fancy('Runs Per Day')}: {n}</b>\n\n"
        f"🕐 {fancy('Send The Time For Slot')} <b>1</b> ({fancy('Example')} <code>04:00</code>) ⌨️"),
        parse_mode=ParseMode.HTML)


# ─────────────────────── REFER / CODES ───────────────────────
async def handle_referral(user_id: int, inviter_raw: str, context):
    if not inviter_raw.isdigit():
        return
    inviter = int(inviter_raw)
    if inviter == user_id or is_admin(user_id) and inviter == user_id:
        return
    existing = db.one("SELECT * FROM referrals WHERE invitee=?", (user_id,))
    user = db.get_user(user_id)
    if existing or not user:
        return
    # anti-abuse: account must be new to the bot (created in this session) & inviter must exist
    if not db.get_user(inviter):
        return
    db.run("INSERT OR IGNORE INTO referrals(inviter,invitee,created_at) VALUES(?,?,?)",
           (inviter, user_id, db.ts()))
    db.run("UPDATE users SET referred_by=? WHERE user_id=?", (inviter, user_id))
    db.run("UPDATE users SET refer_count=refer_count+1 WHERE user_id=?", (inviter,))
    db.add_credits(inviter, config.REFER_CREDIT_PER_INVITE)
    db.add_credits(user_id, config.REFER_CREDIT_PER_INVITE)
    db.event("referral", 1, {"inviter": inviter, "invitee": user_id})
    try:
        await context.bot.send_message(inviter, wrap(
            f"🎉 <b>{fancy('New Referral Joined')}</b> 🎁\n"
            f"➕ <b>{config.REFER_CREDIT_PER_INVITE}</b> {fancy('Credit Added To Your Wallet')} 💰"),
            parse_mode=ParseMode.HTML)
    except Exception:
        pass


def refer_text(user_id: int, bot_username: str) -> str:
    row = db.get_user(user_id) or {}
    link = f"https://t.me/{bot_username}?start=ref{user_id}"
    body = (
        f"🎁 <b>{fancy('Refer And Earn')}</b> 🚀\n\n"
        f"🔗 {fancy('Your Link')}:\n<code>{link}</code>\n\n"
        f"👥 {fancy('Your Referrals')}: <b>{row.get('refer_count',0)}</b>\n"
        f"🎟 {fancy('Credits')}: <b>{row.get('credits',0)}</b>\n\n"
        f"💡 {fancy('Both Sides Get')} <b>1 {fancy('Credit')}</b> {fancy('Per Invite')} 🤝\n"
        f"🏆 <b>5 {fancy('Credits')}</b> = <b>1000 {fancy('Likes')}</b> ❤️\n"
        f"🛡 {fancy('Self Refers And Fake Accounts Are Blocked')} 🚫"
    )
    return wrap(body)


async def cmd_refer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    await update.message.reply_text(refer_text(u.id, context.bot.username), parse_mode=ParseMode.HTML,
                                    reply_markup=ui.refer_menu())


async def cmd_redeem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    context.user_data["await"] = {"kind": "redeem"}
    await update.message.reply_text(wrap(
        f"🎟 <b>{fancy('Redeem A Code')}</b>\n\n⌨️ {fancy('Send The Code Now')} 👇"),
        parse_mode=ParseMode.HTML, reply_markup=M([ui.back_row("m:refer")]))


def do_redeem(user_id: int, code: str) -> str:
    code = code.strip().upper()
    row = db.one("SELECT * FROM refer_codes WHERE code=?", (code,))
    if not row:
        return wrap(f"❌ <b>{fancy('Invalid Code')}</b> 🚫")
    if row["valid_till"] and row["valid_till"] < db.ts():
        return wrap(f"⌛ <b>{fancy('This Code Expired')}</b> 😢")
    if row["used"] >= row["max_redeems"]:
        return wrap(f"🚫 <b>{fancy('Code Limit Reached')}</b>")
    if db.one("SELECT id FROM redemptions WHERE code=? AND user_id=?", (code, user_id)):
        return wrap(f"⚠️ <b>{fancy('You Already Used This Code')}</b>")
    db.run("INSERT INTO redemptions(code,user_id,created_at) VALUES(?,?,?)", (code, user_id, db.ts()))
    db.run("UPDATE refer_codes SET used=used+1 WHERE code=?", (code,))
    db.add_credits(user_id, row["credits"])
    return wrap(f"✅ <b>{fancy('Code Redeemed')}</b> 🎉\n➕ <b>{row['credits']}</b> {fancy('Credits Added')} 💰")


def claim_screen(user_id: int) -> str:
    row = db.get_user(user_id) or {}
    return ui.claim_text(int(row.get("credits", 0) or 0))


def do_claim(user_id: int, uid: str, region: str) -> str:
    """Spend credits in blocks of CREDIT_REDEEM_UNIT, each block = free autolike likes."""
    row = db.get_user(user_id) or {}
    credits = int(row.get("credits", 0) or 0)
    unit = config.CREDIT_REDEEM_UNIT
    blocks = credits // unit
    if blocks < 1:
        return wrap(f"⚠️ <b>{fancy('Not Enough Credits')}</b>\n🎟 {fancy('You Have')}: <b>{credits}</b>\n"
                    f"🎯 {fancy('Needed')}: <b>{unit}</b>")
    spend = blocks * unit
    likes = blocks * config.LIKES_PER_CREDIT_UNIT
    left = credits - spend
    db.run("UPDATE users SET credits=credits-? WHERE user_id=?", (spend, user_id))
    db.run("""INSERT INTO autolikes(uid,region,owner_id,likes_target,likes_left,created_at)
              VALUES(?,?,?,?,?,?)
              ON CONFLICT(uid,region) DO UPDATE SET likes_left=autolikes.likes_left+excluded.likes_left,
                    paused=0""",
           (uid, region, user_id, min(likes, 500), likes, db.ts()))
    return wrap(
        f"🎉 <b>{fancy('Free Autolike Activated')}</b> 🤖\n\n"
        f"🪪 {fancy('Uid')}: <b>{uid}</b>\n"
        f"🌍 {fancy('Region')}: <b>{config.region_label(region)}</b>\n"
        f"❤️ {fancy('Autolike Likes')}: <b>{likes:,}</b>\n"
        f"🎟 {fancy('Credits Spent')}: <b>{spend}</b>\n"
        f"🧮 {fancy('Credits Left')}: <b>{left}</b>\n\n"
        f"⚡ {fancy('Likes Start Flowing On The Next Run')} 🚀")


async def cmd_claim(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    context.user_data["await"] = {"kind": "claim_region"}
    await update.message.reply_text(claim_screen(u.id), parse_mode=ParseMode.HTML,
                                    reply_markup=ui.region_keyboard("rg:claim"))



async def cmd_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    if not is_admin(u.id):
        return
    args = context.args or []
    if len(args) < 3:
        return await update.message.reply_text(wrap(
            f"🎟 <b>{fancy('Generate Credit Code')}</b>\n\n"
            f"✅ <code>/code &lt;credits&gt; &lt;valid_days&gt; &lt;max_users&gt;</code>\n"
            f"📝 {fancy('Example')}: <code>/code 5 7 20</code>"), parse_mode=ParseMode.HTML)
    credits, days, users = int(args[0]), int(args[1]), int(args[2])
    code = "ROCKS" + "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(6))
    db.run("""INSERT INTO refer_codes(code,credits,max_redeems,valid_till,created_by,created_at)
              VALUES(?,?,?,?,?,?)""",
           (code, credits, users, db.ts() + days * 86400, u.id, db.ts()))
    await update.message.reply_text(wrap(
        f"✅ <b>{fancy('Code Created')}</b> 🎟\n\n"
        f"🔑 <code>{code}</code>\n🎁 {fancy('Credits')}: <b>{credits}</b>\n"
        f"👥 {fancy('Max Users')}: <b>{users}</b>\n📅 {fancy('Valid Days')}: <b>{days}</b>"),
        parse_mode=ParseMode.HTML, reply_markup=M([ui.back_row("a:panel")]))


async def cmd_genkey(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    if not is_admin(u.id):
        return
    args = context.args or []
    if not args or not args[0].isdigit():
        return await update.message.reply_text(wrap(
            f"🔑 <code>/genkey 10000 [days]</code> — {fancy('Create A Buyer Key')}"), parse_mode=ParseMode.HTML)
    total = int(args[0])
    days = int(args[1]) if len(args) > 1 and args[1].isdigit() else 30
    code = "RK-" + "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
    db.run("""INSERT INTO keys(code,likes_total,likes_left,owner_id,created_at,expires_at)
              VALUES(?,?,?,?,?,?)""", (code, total, total, u.id, db.ts(), db.ts() + days * 86400))
    await update.message.reply_text(wrap(
        f"✅ <b>{fancy('Buyer Key Created')}</b> 🔑\n\n"
        f"🔐 <code>{code}</code>\n❤️ {fancy('Likes')}: <b>{total:,}</b>\n📅 {fancy('Valid Days')}: <b>{days}</b>\n\n"
        f"💡 {fancy('Buyer Can Split It Across Many Uids With')} <code>/usekey</code>"),
        parse_mode=ParseMode.HTML)


async def cmd_usekey(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    args = context.args or []
    if len(args) < 4:
        return await update.message.reply_text(wrap(
            f"🔑 <code>/usekey &lt;key&gt; &lt;region&gt; &lt;uid&gt; &lt;likes&gt;</code>\n"
            f"📝 {fancy('Example')}: <code>/usekey RK-XXXX ind 3688500765 1000</code>"), parse_mode=ParseMode.HTML)
    code, region, uid, amount = args[0].upper(), args[1].upper(), args[2], args[3]
    row = db.one("SELECT * FROM keys WHERE code=? AND active=1", (code,))
    if not row:
        return await update.message.reply_text(wrap(f"❌ <b>{fancy('Invalid Key')}</b>"), parse_mode=ParseMode.HTML)
    if row["expires_at"] and row["expires_at"] < db.ts():
        return await update.message.reply_text(wrap(f"⌛ <b>{fancy('Key Expired')}</b>"), parse_mode=ParseMode.HTML)
    if not amount.isdigit() or not UID_RE.match(uid) or not valid_region(region):
        return await update.message.reply_text(wrap(f"❌ <b>{fancy('Invalid Input')}</b>"), parse_mode=ParseMode.HTML)
    amount = int(amount)
    if amount > row["likes_left"]:
        return await update.message.reply_text(wrap(
            f"🚫 <b>{fancy('Not Enough Likes On This Key')}</b>\n❤️ {fancy('Left')}: <b>{row['likes_left']:,}</b>"),
            parse_mode=ParseMode.HTML)
    db.run("UPDATE keys SET likes_left=likes_left-?, bound_user=COALESCE(bound_user,?) WHERE code=?",
           (amount, u.id, code))
    db.run("""INSERT INTO autolikes(uid,region,owner_id,key_code,likes_target,likes_left,created_at)
              VALUES(?,?,?,?,?,?,?)
              ON CONFLICT(uid,region) DO UPDATE SET likes_left=autolikes.likes_left+excluded.likes_left,
                    key_code=excluded.key_code, paused=0""",
           (uid, region, u.id, code, min(amount, 500), amount, db.ts()))
    left = db.one("SELECT likes_left FROM keys WHERE code=?", (code,))["likes_left"]
    await update.message.reply_text(wrap(
        f"✅ <b>{fancy('Autolike Activated')}</b> 🤖\n\n"
        f"🆔 {fancy('Uid')}: <b>{uid}</b> • {config.region_label(region)}\n"
        f"❤️ {fancy('Assigned')}: <b>{amount:,}</b>\n"
        f"🔑 {fancy('Key Balance Left')}: <b>{left:,}</b>"),
        parse_mode=ParseMode.HTML, reply_markup=M([ui.back_row(more="m:more")]))


# ─────────────────────── PAYMENTS ───────────────────────
async def open_payment(update_or_q, context, plan_id: int, currency: str, user):
    plan = next((p for p in config.PLANS if p["id"] == plan_id), None)
    if not plan:
        return
    amount = plan["inr"] if currency == "INR" else plan["usd"]
    order_id = db.run("""INSERT INTO purchases(user_id,username,likes,amount,currency,method,status,created_at)
                         VALUES(?,?,?,?,?,?,'pending',?)""",
                      (user.id, user.username or "", plan["likes"], amount, currency,
                       "UPI" if currency == "INR" else "USDT", db.ts()))
    qr = "qr_upi.jpg" if currency == "INR" else "qr_usdt.jpg"
    path = os.path.join(BASE, "static", qr)
    chat_id = update_or_q.message.chat_id if hasattr(update_or_q, "message") else update_or_q.chat_id
    with open(path, "rb") as f:
        msg = await context.bot.send_photo(chat_id, photo=f,
                                           caption=ui.payment_text(plan, currency, order_id, config.PAYMENT_TIMER_SECONDS),
                                           parse_mode=ParseMode.HTML,
                                           reply_markup=ui.pay_timer_keyboard(order_id))
    context.application.create_task(payment_timer(context, msg, plan, currency, order_id))


async def payment_timer(context, msg, plan, currency, order_id):
    deadline = time.time() + config.PAYMENT_TIMER_SECONDS
    while time.time() < deadline:
        await asyncio.sleep(1)
        row = db.one("SELECT status FROM purchases WHERE id=?", (order_id,))
        if not row or row["status"] != "pending":
            return
        left = int(deadline - time.time())
        try:
            await msg.edit_caption(caption=ui.payment_text(plan, currency, order_id, left),
                                   parse_mode=ParseMode.HTML, reply_markup=ui.pay_timer_keyboard(order_id))
        except BadRequest:
            pass
        except Exception:
            return
    row = db.one("SELECT status FROM purchases WHERE id=?", (order_id,))
    if row and row["status"] == "pending":
        db.run("UPDATE purchases SET status='expired' WHERE id=?", (order_id,))
        try:
            await msg.delete()
        except Exception:
            pass
        try:
            await context.bot.send_message(msg.chat_id, wrap(
                f"⌛ <b>{fancy('Order')} #{order_id} {fancy('Expired')}</b> 🚫\n"
                f"🕐 {fancy('The Payment Window Closed')}\n💎 {fancy('Tap Plans To Start Again')}"),
                parse_mode=ParseMode.HTML, reply_markup=M([[B("💎 Pʟᴀᴎꜱ", callback_data="m:plans")], ui.back_row()]))
        except Exception:
            pass


async def notify_admins(context, text, markup=None):
    for aid in config.ADMIN_IDS:
        try:
            await context.bot.send_message(aid, text, parse_mode=ParseMode.HTML, reply_markup=markup)
        except Exception:
            pass


async def cmd_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text(orders_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=M([ui.back_row("a:panel", more="m:more")]))


def orders_text() -> str:
    rows = db.q("SELECT * FROM purchases WHERE status IN ('pending','paid') ORDER BY id DESC LIMIT 20")
    if not rows:
        return wrap(f"📭 <b>{fancy('No Pending Orders')}</b> ✅")
    out = [f"🧾 <b>{fancy('Pending Orders')}</b>", ""]
    for r in rows:
        out.append(f"#️⃣ <b>{r['id']}</b> • {r['status'].upper()} • {r['currency']} {r['amount']}\n"
                   f"   👤 @{r['username'] or r['user_id']} • ❤️ {r['likes']:,}\n"
                   f"   ✅ <code>/approve {r['id']}</code>")
    return wrap("\n".join(out))


async def cmd_approve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return
    oid = int(context.args[0])
    row = db.one("SELECT * FROM purchases WHERE id=?", (oid,))
    if not row:
        return await update.message.reply_text(wrap(f"❌ {fancy('Order Not Found')}"), parse_mode=ParseMode.HTML)
    db.run("UPDATE purchases SET status='approved', approved_at=? WHERE id=?", (db.ts(), oid))
    db.add_likes_balance(row["user_id"], row["likes"])
    db.event("sale", row["amount"], {"currency": row["currency"], "likes": row["likes"]})
    code = "RK-" + "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
    db.run("""INSERT INTO keys(code,likes_total,likes_left,owner_id,bound_user,created_at,expires_at)
              VALUES(?,?,?,?,?,?,?)""",
           (code, row["likes"], row["likes"], update.effective_user.id, row["user_id"], db.ts(), db.ts() + 30 * 86400))
    try:
        await context.bot.send_message(row["user_id"], wrap(
            f"🎉 <b>{fancy('Payment Approved')}</b> ✅\n\n"
            f"❤️ {fancy('Likes')}: <b>{row['likes']:,}</b>\n🔑 {fancy('Your Key')}: <code>{code}</code>\n\n"
            f"💡 <code>/usekey {code} ind 3688500765 1000</code>\n"
            f"🎯 {fancy('Split It Across As Many Uids As You Want')} 🚀"),
            parse_mode=ParseMode.HTML)
    except Exception:
        pass
    await update.message.reply_text(wrap(f"✅ <b>{fancy('Order Approved')}</b> #{oid}\n🔑 <code>{code}</code>"),
                                    parse_mode=ParseMode.HTML)
    await log_to_group(context, wrap(
        f"💰 <b>{fancy('New Sale')}</b> 🎉\n🧾 #{oid} • {row['currency']} {row['amount']}\n"
        f"❤️ {fancy('Likes')}: <b>{row['likes']:,}</b>"))


async def precheckout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.pre_checkout_query.answer(ok=True)


async def on_successful_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    sp = update.message.successful_payment
    payload = sp.invoice_payload
    plan = next((p for p in config.PLANS if f"plan{p['id']}" == payload), None)
    u = update.effective_user
    likes_amt = plan["likes"] if plan else 0
    oid = db.run("""INSERT INTO purchases(user_id,username,likes,amount,currency,method,status,created_at,approved_at)
                    VALUES(?,?,?,?,?,?,'approved',?,?)""",
                 (u.id, u.username or "", likes_amt, sp.total_amount, "STARS", "Stars", db.ts(), db.ts()))
    db.add_likes_balance(u.id, likes_amt)
    db.event("sale", sp.total_amount, {"currency": "STARS", "likes": likes_amt})
    code = "RK-" + "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
    db.run("""INSERT INTO keys(code,likes_total,likes_left,owner_id,bound_user,created_at,expires_at)
              VALUES(?,?,?,?,?,?,?)""", (code, likes_amt, likes_amt, u.id, u.id, db.ts(), db.ts() + 30 * 86400))
    await update.message.reply_text(wrap(
        f"⭐ <b>{fancy('Stars Payment Received')}</b> 🎉\n❤️ {fancy('Likes')}: <b>{likes_amt:,}</b>\n"
        f"🔑 <code>{code}</code>"), parse_mode=ParseMode.HTML)
    await log_to_group(context, wrap(f"⭐ <b>{fancy('New Stars Sale')}</b> #{oid} • {sp.total_amount} ⭐"))


# ─────────────────────── ADMIN / SYSTEM ───────────────────────
async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await update.message.reply_text(stats_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=M([ui.back_row(more="m:more")]))


def stats_text() -> str:
    t = db.totals()
    body = (
        f"📊 <b>{fancy('Live Statistics')}</b> 📈\n\n"
        f"👥 {fancy('Users')}: <b>{t['users']:,}</b>\n"
        f"❤️ {fancy('Likes Delivered')}: <b>{t['likes_sent']:,}</b>\n"
        f"🤖 {fancy('Autolike Slots')}: <b>{t['autolikes']:,}</b>\n"
        f"📡 {fancy('Active Sources')}: <b>{t['apis']}</b>\n"
        f"🧾 {fancy('Orders Completed')}: <b>{t['orders']:,}</b>\n"
        f"💰 {fancy('Revenue')}: <b>₹{t['revenue_inr']:,.0f}</b> • <b>${t['revenue_usd']:,.0f}</b>"
    )
    return wrap(body)


def analytics_text(rng: str) -> str:
    a = db.analytics(rng)
    peak = max((s["likes"] for s in a["series"]), default=0) or 1
    spark = "".join("▁▂▃▄▅▆▇█"[min(7, int(7 * s["likes"] / peak))] for s in a["series"][-24:])
    body = (
        f"📊 <b>{fancy('Analytics')} — {fancy(rng.title())}</b> 📈\n\n"
        f"❤️ {fancy('Likes Sent')}: <b>{a['likes_sent']:,}</b>\n"
        f"⚡ {fancy('Like Runs')}: <b>{a['like_runs']:,}</b>\n"
        f"🧾 {fancy('Orders')}: <b>{a['orders']:,}</b>\n"
        f"💰 {fancy('Sales')}: <b>₹{a['sales_inr']:,.0f}</b> • <b>${a['sales_usd']:,.0f}</b>\n"
        f"🛒 {fancy('Likes Sold')}: <b>{a['likes_sold']:,}</b>\n"
        f"👥 {fancy('New Users')}: <b>{a['new_users']:,}</b>\n\n"
        f"📉 {fancy('Trend')}: <code>{spark}</code>"
    )
    return wrap(body)


async def cmd_analytics(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    rng = (context.args[0].lower() if context.args else "week")
    await update.message.reply_text(analytics_text(rng if rng in db.RANGES else "week"),
                                    parse_mode=ParseMode.HTML, reply_markup=ui.analytics_kb())


async def cmd_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text(panel_text(), parse_mode=ParseMode.HTML, reply_markup=ui.admin_menu())


def panel_text() -> str:
    t = db.totals()
    return wrap(
        f"👑 <b>{fancy('Owner Dashboard')}</b> 🛠\n\n"
        f"👥 {fancy('Users')}: <b>{t['users']:,}</b> • 🤖 {fancy('Slots')}: <b>{t['autolikes']}</b>\n"
        f"❤️ {fancy('Likes')}: <b>{t['likes_sent']:,}</b> • 📡 {fancy('Apis')}: <b>{t['apis']}</b>\n"
        f"💰 {fancy('Revenue')}: <b>₹{t['revenue_inr']:,.0f}</b> / <b>${t['revenue_usd']:,.0f}</b>\n\n"
        f"👇 {fancy('Choose A Tool')} ⚙️")


async def cmd_addapi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return
    url = context.args[0]
    kind = "info" if (len(context.args) > 1 and context.args[1].lower() == "info") else "like"
    db.run("INSERT OR IGNORE INTO apis(url,kind,position) VALUES(?,?,?)", (url, kind, 999))
    await update.message.reply_text(wrap(f"✅ <b>{fancy('Source Added')}</b> 📡 ({kind})"), parse_mode=ParseMode.HTML)


async def cmd_delapi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return
    rows = db.like_apis()
    idx = int(context.args[0]) - 1
    if 0 <= idx < len(rows):
        db.run("DELETE FROM apis WHERE id=?", (rows[idx]["id"],))
        await update.message.reply_text(wrap(f"🗑 <b>{fancy('Source Removed')}</b> ✅"), parse_mode=ParseMode.HTML)


def apis_text() -> str:
    rows = db.like_apis()
    out = [f"📡 <b>{fancy('Like Sources')}</b> ({len(rows)})", ""]
    for i, r in enumerate(rows, 1):
        total = r["ok_count"] + r["fail_count"]
        health = 100 * r["ok_count"] / total if total else 0
        dot = "🟢" if health >= 50 else ("🟡" if health > 0 else "🔴")
        out.append(f"{dot} <b>V{i}</b> — ✅ {r['ok_count']} / ❌ {r['fail_count']}  ({health:.0f}%)")
    info = db.info_apis()
    out += ["", f"🔎 <b>{fancy('Info Sources')}</b>: <b>{len(info)}</b> 📊"]
    return wrap("\n".join(out))


async def cmd_listapi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(apis_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=M([ui.back_row(more="m:more")]))


async def cmd_addgroup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return
    db.run("INSERT OR IGNORE INTO groups(link,title) VALUES(?,?)",
           (context.args[0], " ".join(context.args[1:]) or "Group"))
    await update.message.reply_text(wrap(f"✅ <b>{fancy('Group Slot Added')}</b> 💬"), parse_mode=ParseMode.HTML)


async def cmd_bindlog(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    db.set_setting("log_chat_id", str(update.effective_chat.id))
    await update.message.reply_text(wrap(
        f"✅ <b>{fancy('Log Group Bound')}</b> 📝\n🆔 <code>{update.effective_chat.id}</code>"),
        parse_mode=ParseMode.HTML)


async def cmd_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    text = " ".join(context.args or [])
    if not text:
        context.user_data["await"] = {"kind": "broadcast"}
        return await update.message.reply_text(wrap(f"📢 {fancy('Send The Broadcast Message Now')} ⌨️"),
                                               parse_mode=ParseMode.HTML)
    await do_broadcast(context, update.effective_chat.id, text)


async def do_broadcast(context, chat_id, text):
    users = db.q("SELECT user_id FROM users WHERE banned=0")
    sent = fail = 0
    for row in users:
        try:
            await context.bot.send_message(row["user_id"], wrap(f"📢 <b>{fancy('Announcement')}</b>\n\n{text}"),
                                           parse_mode=ParseMode.HTML)
            sent += 1
        except Exception:
            fail += 1
        await asyncio.sleep(0.05)
    await context.bot.send_message(chat_id, wrap(
        f"📢 <b>{fancy('Broadcast Done')}</b>\n✅ {fancy('Sent')}: <b>{sent}</b>\n❌ {fancy('Failed')}: <b>{fail}</b>"),
        parse_mode=ParseMode.HTML)


async def cmd_ban(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return
    db.run("UPDATE users SET banned=1 WHERE user_id=?", (int(context.args[0]),))
    await update.message.reply_text(wrap(f"🚫 <b>{fancy('User Banned')}</b>"), parse_mode=ParseMode.HTML)


async def cmd_unban(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return
    db.run("UPDATE users SET banned=0 WHERE user_id=?", (int(context.args[0]),))
    await update.message.reply_text(wrap(f"✅ <b>{fancy('User Unbanned')}</b>"), parse_mode=ParseMode.HTML)


# ─────────────────────── CALLBACKS ───────────────────────
async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    data = q.data or ""
    u = q.from_user
    db.upsert_user(u.id, u.username or "", u.first_name or "")
    await q.answer()
    admin = is_admin(u.id)

    if data == "m:home":
        return await edit(q, ui.start_text(u.first_name or "Player", admin), ui.main_menu(admin))
    if data == "m:more":
        return await edit(q, wrap(f"➕ <b>{fancy('More Options')}</b>\n\n🧭 {fancy('Everything Else Lives Here')} 👇"),
                          ui.more_menu(admin))
    if data == "m:help":
        return await edit(q, ui.help_text(), M([ui.back_row(more="m:more")]))
    if data == "m:cmds":
        return await edit(q, ui.cmds_text(admin), M([ui.back_row(more="m:more")]))
    if data == "m:services":
        return await edit(q, ui.services_text(), ui.services_kb())
    if data == "m:keys":
        return await edit(q, ui.keys_text(u.id), M([ui.back_row(more="m:more")]))
    if data == "m:fullinfo":
        context.user_data["await"] = {"kind": "full_region"}
        return await edit(q, wrap(f"📖 <b>{fancy('Full Player Report')}</b>\n\n🌍 {fancy('Pick The Region First')} 👇"),
                          ui.region_keyboard("rg:full"))
    if data.startswith("fi:"):
        _, region, uid = data.split(":")
        return await send_full_info(q.message, context, uid, region)

    if data == "m:plans":
        return await edit(q, ui.plans_text(), ui.plans_keyboard())
    if data == "m:stats":
        return await edit(q, stats_text(), M([ui.back_row("m:more")]))
    if data == "m:apis":
        return await edit(q, apis_text(), M([ui.back_row("m:more")]))
    if data == "m:regions":
        return await edit(q, ui.regions_text(), M([ui.back_row("m:more")]))
    if data == "m:bal":
        return await edit(q, balance_text(u.id), M([ui.back_row(more="m:more")]))
    if data == "m:top":
        rows = db.q("""SELECT nickname, uid, SUM(given) s FROM like_logs
                       GROUP BY uid ORDER BY s DESC LIMIT 10""")
        out = [f"🏆 <b>{fancy('Top Players By Likes')}</b>", ""]
        medals = ["🥇", "🥈", "🥉"] + ["🎖"] * 7
        for i, r in enumerate(rows):
            out.append(f"{medals[i]} <b>{r['nickname'] or r['uid']}</b> — ❤️ {r['s']:,}")
        if not rows:
            out.append(f"📭 {fancy('No Data Yet')}")
        return await edit(q, wrap("\n".join(out)), M([ui.back_row("m:more")]))
    if data == "m:about":
        return await edit(q, about_home_text(), ui.about_menu())
    if data.startswith("ab:"):
        key = data.split(":")[1]
        s = next((x for x in config.SOCIALS if x["key"] == key), None)
        if not s:
            return
        text = wrap(
            f"{s['emoji']} <b>{fancy(s['title'])}</b>\n\n"
            f"🔗 {fancy('Handle')}: <b>{s['handle']}</b>\n"
            f"📱 {fancy('Scan The Qr Or Tap The Button Below')} 👇")
        path = os.path.join(BASE, "static", s["qr"])
        try:
            with open(path, "rb") as f:
                await context.bot.send_photo(q.message.chat_id, photo=f, caption=text,
                                             parse_mode=ParseMode.HTML,
                                             reply_markup=ui.about_page_kb(key, s["url"]))
            return
        except Exception:
            return await edit(q, text, ui.about_page_kb(key, s["url"]))
    if data == "m:info":
        context.user_data["await"] = {"kind": "info_region"}
        return await edit(q, wrap(f"🔎 <b>{fancy('Player Info')}</b>\n\n🌍 {fancy('Pick The Region First')} 👇"),
                          ui.region_keyboard("rg:info"))
    if data == "m:like":
        context.user_data["await"] = {"kind": "like_region"}
        return await edit(q, wrap(f"❤️ <b>{fancy('Send Likes')}</b>\n\n🌍 {fancy('Pick The Region First')} 👇"),
                          ui.region_keyboard("rg:like"))
    if data == "m:auto":
        if not admin:
            return await edit(q, wrap(f"🚫 <b>{fancy('Autolike Is Admin Only')}</b> 👑\n"
                                      f"💎 {fancy('Buy A Plan And Use Your Key')} 🔑"),
                              M([[B("💎 Pʟᴀᴎꜱ", callback_data="m:plans")], ui.back_row()]))
        context.user_data["await"] = {"kind": "auto_region"}
        return await edit(q, wrap(f"🤖 <b>{fancy('Add Autolike Slot')}</b>\n\n🌍 {fancy('Pick The Region')} 👇"),
                          ui.region_keyboard("rg:auto"))
    if data == "m:refer":
        return await edit(q, refer_text(u.id, context.bot.username), ui.refer_menu())
    if data == "m:redeem" or data == "rf:redeem":
        context.user_data["await"] = {"kind": "redeem"}
        return await edit(q, wrap(f"🎟 <b>{fancy('Send The Code Now')}</b> ⌨️"), M([ui.back_row("m:refer")]))
    if data == "rf:claim":
        context.user_data["await"] = {"kind": "claim_region"}
        return await edit(q, claim_screen(u.id), ui.region_keyboard("rg:claim"))

    if data == "rf:link":
        return await edit(q, refer_text(u.id, context.bot.username), ui.refer_menu())
    if data == "rf:list":
        rows = db.q("SELECT invitee, created_at FROM referrals WHERE inviter=? ORDER BY id DESC LIMIT 15", (u.id,))
        out = [f"👥 <b>{fancy('Your Referrals')}</b> ({len(rows)})", ""]
        for r in rows:
            out.append(f"✅ <code>{r['invitee']}</code> • {datetime.fromtimestamp(r['created_at']).strftime('%d %b %Y')}")
        if not rows:
            out.append(f"📭 {fancy('No Referrals Yet')} — {fancy('Share Your Link')} 🔗")
        return await edit(q, wrap("\n".join(out)), ui.refer_menu())

    # region pickers
    if data.startswith("rg:"):
        body = data[3:]
        if "#pg:" in body:
            kind, page = body.split("#pg:")
            return await edit(q, q.message.caption or q.message.text or "🌍",
                              ui.region_keyboard(f"rg:{kind}", int(page)))
        kind, code = body.split(":")
        context.user_data["await"] = {"kind": f"{kind}_uid", "region": code}
        return await edit(q, wrap(
            f"🌍 {fancy('Region')}: <b>{config.region_label(code)}</b>\n\n"
            f"🆔 {fancy('Now Send The Uid')} ⌨️"), M([ui.back_row()]))

    # plans / payment
    if data.startswith("p:"):
        pid = int(data.split(":")[1])
        plan = next((x for x in config.PLANS if x["id"] == pid), None)
        text = wrap(
            f"{plan['label']} <b>{plan['likes']:,} {fancy('Likes')}</b> ❤️\n\n"
            f"🇮🇳 {fancy('India')}: <b>₹{plan['inr']}</b>\n"
            f"💵 {fancy('Global')}: <b>${plan['usd']} Uꜱᴅᴛ</b>\n"
            f"⭐ {fancy('Telegram Stars')}: <b>{plan['stars']}</b>\n\n"
            f"⚡ {fancy('Delivery Starts Instantly After Approval')} 🚀")
        return await edit(q, text, ui.plan_pay_keyboard(pid))
    if data.startswith("pay:"):
        _, cur, pid = data.split(":")
        pid = int(pid)
        if cur == "star":
            plan = next((x for x in config.PLANS if x["id"] == pid), None)
            try:
                return await context.bot.send_invoice(
                    chat_id=q.message.chat_id, title=f"{plan['likes']:,} Likes",
                    description=fancy(f"Rocks Autolikes {plan['likes']} likes pack"),
                    payload=f"plan{pid}", provider_token="", currency="XTR",
                    prices=[LabeledPrice(label="Likes", amount=plan["stars"])])
            except Exception as e:  # noqa: BLE001
                return await q.message.reply_text(wrap(f"⚠️ {fancy('Stars Checkout Unavailable')}: {e}"),
                                                  parse_mode=ParseMode.HTML)
        return await open_payment(q, context, pid, "INR" if cur == "inr" else "USD", u)
    if data.startswith("paid:"):
        oid = int(data.split(":")[1])
        db.run("UPDATE purchases SET status='paid' WHERE id=? AND status='pending'", (oid,))
        context.user_data["await"] = {"kind": "proof", "order": oid}
        await edit(q, wrap(
            f"📸 <b>{fancy('Send The Payment Screenshot Plus Transaction Id Now')}</b> ⌨️\n\n"
            f"🕐 {fancy('An Admin Will Verify And Add Your Likes')} ✅"), M([ui.back_row()]))
        return
    if data.startswith("cancel:"):
        oid = int(data.split(":")[1])
        db.run("UPDATE purchases SET status='cancelled' WHERE id=?", (oid,))
        try:
            await q.message.delete()
        except Exception:
            pass
        return await context.bot.send_message(q.message.chat_id, wrap(
            f"❌ <b>{fancy('Order Cancelled')}</b> 🚫\n💎 {fancy('You Can Start Again Anytime')}"),
            parse_mode=ParseMode.HTML, reply_markup=M([[B("💎 Pʟᴀᴎꜱ", callback_data="m:plans")], ui.back_row()]))

    # admin
    if data.startswith("a:") and not admin:
        return await q.answer("👑 Aᴅᴍɪᴎ Oᴎʟʏ", show_alert=True)
    if data == "a:panel":
        return await edit(q, panel_text(), ui.admin_menu())
    if data.startswith("a:an:"):
        return await edit(q, analytics_text(data.split(":")[2]), ui.analytics_kb())
    if data == "a:auto":
        return await edit(q, autolist_text(), M([[B("▶️ Rᴜᴎ Aʟʟ", callback_data="a:runall")],
                                                 ui.back_row("a:panel", more="m:more")]))
    if data == "a:runall":
        await edit(q, wrap(f"▶️ <b>{fancy('Starting All Slots')}</b> 🤖"), M([ui.back_row("a:panel")]))
        return await run_all(context, q.message.chat_id, u.id)
    if data == "a:users":
        rows = db.q("SELECT user_id, username, credits, total_likes FROM users ORDER BY joined_at DESC LIMIT 15")
        out = [f"👥 <b>{fancy('Latest Users')}</b>", ""]
        for r in rows:
            out.append(f"👤 @{r['username'] or r['user_id']} • 🎟 {r['credits']} • ❤️ {r['total_likes']:,}")
        return await edit(q, wrap("\n".join(out)), M([ui.back_row("a:panel", more="m:more")]))
    if data == "a:keys":
        rows = db.q("SELECT * FROM keys ORDER BY created_at DESC LIMIT 12")
        out = [f"🔑 <b>{fancy('Buyer Keys')}</b>", ""]
        for r in rows:
            out.append(f"🔐 <code>{r['code']}</code> • ❤️ {r['likes_left']:,}/{r['likes_total']:,}")
        if not rows:
            out.append(f"📭 {fancy('No Keys Yet')} — <code>/genkey 10000</code>")
        return await edit(q, wrap("\n".join(out)), M([ui.back_row("a:panel", more="m:more")]))
    if data == "a:codes":
        rows = db.q("SELECT * FROM refer_codes ORDER BY created_at DESC LIMIT 12")
        out = [f"🎟 <b>{fancy('Credit Codes')}</b>", ""]
        for r in rows:
            out.append(f"🔑 <code>{r['code']}</code> • 🎁 {r['credits']} • 👥 {r['used']}/{r['max_redeems']}")
        if not rows:
            out.append(f"📭 {fancy('No Codes Yet')} — <code>/code 5 7 20</code>")
        return await edit(q, wrap("\n".join(out)), M([ui.back_row("a:panel", more="m:more")]))
    if data == "a:orders":
        return await edit(q, orders_text(), M([ui.back_row("a:panel", more="m:more")]))
    if data == "a:runs":
        times = db.get_json("run_times", ["04:00"])
        return await edit(q, wrap(
            f"⏰ <b>{fancy('Autolike Run Times')}</b>\n\n"
            f"🔁 {fancy('Runs Per Day')}: <b>{db.get_setting('runs_per_day','1')}</b>\n"
            f"🕐 {fancy('Times')}: <b>{', '.join(times)}</b> (Iꜱᴛ)\n\n"
            f"⚙️ {fancy('Change With')} <code>/setruns 3</code>"), M([ui.back_row("a:panel")]))
    if data == "a:bc":
        context.user_data["await"] = {"kind": "broadcast"}
        return await edit(q, wrap(f"📢 {fancy('Send The Broadcast Message Now')} ⌨️"), M([ui.back_row("a:panel")]))


# ─────────────────────── FREE TEXT ROUTER ───────────────────────
async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message:
        return
    u = touch_user(update)
    state = context.user_data.get("await")
    if not state:
        return
    text = (update.message.text or update.message.caption or "").strip()
    kind = state["kind"]

    if kind == "redeem":
        context.user_data.pop("await", None)
        return await update.message.reply_text(do_redeem(u.id, text), parse_mode=ParseMode.HTML,
                                               reply_markup=ui.refer_menu())

    if kind == "broadcast" and is_admin(u.id):
        context.user_data.pop("await", None)
        return await do_broadcast(context, update.effective_chat.id, text)

    if kind == "runtimes" and is_admin(u.id):
        if not re.match(r"^([01]?\d|2[0-3]):[0-5]\d$", text):
            return await update.message.reply_text(wrap(f"⚠️ {fancy('Send Time Like')} <code>04:00</code>"),
                                                   parse_mode=ParseMode.HTML)
        state["times"].append(text)
        if len(state["times"]) < state["need"]:
            return await update.message.reply_text(wrap(
                f"✅ {fancy('Saved')} <b>{text}</b>\n🕐 {fancy('Now Send Time For Slot')} <b>{len(state['times'])+1}</b>"),
                parse_mode=ParseMode.HTML)
        db.set_setting("runs_per_day", state["need"])
        db.set_setting("run_times", json.dumps(state["times"]))
        context.user_data.pop("await", None)
        schedule_jobs(context.application)
        return await update.message.reply_text(wrap(
            f"✅ <b>{fancy('Schedule Updated')}</b> ⏰\n🔁 {fancy('Runs')}: <b>{state['need']}</b>\n"
            f"🕐 {', '.join(state['times'])} (Iꜱᴛ)"), parse_mode=ParseMode.HTML,
            reply_markup=M([ui.back_row("a:panel")]))

    if kind == "proof":
        oid = state.get("order")
        context.user_data.pop("await", None)
        db.run("UPDATE purchases SET txn=? WHERE id=?", (text[:120], oid))
        await update.message.reply_text(wrap(
            f"✅ <b>{fancy('Proof Received')}</b> 🧾\n"
            f"🕐 {fancy('An Admin Will Verify Shortly And Your Likes Will Be Added')} ⚡"),
            parse_mode=ParseMode.HTML, reply_markup=M([ui.back_row(more="m:more")]))
        cap = wrap(f"🧾 <b>{fancy('Payment Proof')}</b> #{oid}\n"
                   f"👤 @{u.username or u.id}\n🔖 <code>{html.escape(text[:120])}</code>\n"
                   f"✅ <code>/approve {oid}</code>")
        for aid in config.ADMIN_IDS:
            try:
                if update.message.photo:
                    await context.bot.send_photo(aid, update.message.photo[-1].file_id, caption=cap,
                                                 parse_mode=ParseMode.HTML)
                else:
                    await context.bot.send_message(aid, cap, parse_mode=ParseMode.HTML)
            except Exception:
                pass
        return

    if kind.endswith("_uid"):
        region = state.get("region", "IND")
        uid = text.split()[0]
        if not UID_RE.match(uid):
            return await update.message.reply_text(wrap(f"❌ {fancy('Send A Valid Numeric Uid')} 🔢"),
                                                   parse_mode=ParseMode.HTML)
        base = kind[:-4]
        if base == "info":
            context.user_data.pop("await", None)
            info = await asyncio.to_thread(engine.get_info, uid, region)
            return await update.message.reply_text(ui.info_text(info), parse_mode=ParseMode.HTML,
                                                   reply_markup=M([[B("❤️ Sᴇᴎᴅ Lɪᴋᴇꜱ", callback_data="m:like")],
                                                                   ui.back_row(more="m:more")]))
        if base == "like":
            context.user_data.pop("await", None)
            context.args = [region, uid]
            return await cmd_like(update, context)
        if base == "full":
            context.user_data.pop("await", None)
            return await send_full_info(update.message, context, uid, region)
        if base == "claim":
            context.user_data.pop("await", None)
            return await update.message.reply_text(do_claim(u.id, uid, region), parse_mode=ParseMode.HTML,
                                                   reply_markup=ui.refer_menu())
        if base == "auto":
            state["kind"] = "auto_likes"
            state["uid"] = uid
            return await update.message.reply_text(wrap(
                f"❤️ {fancy('How Many Likes Should This Uid Receive')}?\n⌨️ {fancy('Example')}: <code>5000</code>"),
                parse_mode=ParseMode.HTML)


    if kind == "auto_likes" and is_admin(u.id):
        if not text.isdigit():
            return await update.message.reply_text(wrap(f"⚠️ {fancy('Send A Number')} 🔢"), parse_mode=ParseMode.HTML)
        region, uid = state["region"], state["uid"]
        context.user_data.pop("await", None)
        context.args = [region, uid, text]
        return await cmd_autolike(update, context)


# ─────────────────────── SCHEDULER ───────────────────────
def schedule_jobs(app: Application):
    jq = app.job_queue
    for job in jq.jobs():
        if job.name and job.name.startswith("autolike-"):
            job.schedule_removal()
    times = db.get_json("run_times", ["04:00"])
    from datetime import time as dtime
    import zoneinfo
    tz = zoneinfo.ZoneInfo(config.IST_TZ)
    for i, t in enumerate(times):
        try:
            hh, mm = [int(x) for x in t.split(":")]
        except Exception:
            continue
        jq.run_daily(scheduled_run, time=dtime(hour=hh, minute=mm, tzinfo=tz), name=f"autolike-{i}")
    log.info("scheduled %s daily autolike runs: %s", len(times), times)


async def scheduled_run(context: ContextTypes.DEFAULT_TYPE):
    await log_to_group(context, wrap(f"⏰ <b>{fancy('Daily Autolike Started')}</b> 🤖"))
    await run_all(context, None, 0)
    await log_to_group(context, wrap(f"✅ <b>{fancy('Daily Autolike Finished')}</b> 🎉"))


async def on_error(update, context):
    log.error("error: %s", context.error)


# ─────────────────────── EXTRA USER COMMANDS ───────────────────────
START_TIME = time.time()


async def _reply(update, text, markup=None):
    await update.message.reply_text(text, parse_mode=ParseMode.HTML,
                                    reply_markup=markup or M([ui.back_row(more="m:more")]))


async def cmd_services(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, ui.services_text(), ui.services_kb())


async def cmd_mykeys(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    await _reply(update, ui.keys_text(u.id))


async def cmd_myauto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    rows = db.q("SELECT * FROM autolikes WHERE owner_id=? ORDER BY id DESC LIMIT 15", (u.id,))
    out = [f"🤖 <b>{fancy('Your Autolike Slots')}</b>", ""]
    for r in rows:
        state = "⏸ Pᴀᴜꜱᴇᴅ" if r["paused"] else "▶️ Rᴜɴɴɪɴɢ"
        out.append(f"🪪 <b>{r['uid']}</b> • {config.region_label(r['region'])}")
        out.append(f"❤️ Lᴇꜰᴛ: <b>{r['likes_left']:,}</b> • {state}")
        out.append("")
    if not rows:
        out.append(f"📭 {fancy('No Slots Yet')} — 🔑 <code>/usekey</code> {fancy('Or Claim With Credits')}")
    await _reply(update, wrap("\n".join(out)))


async def cmd_mystats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    await _reply(update, balance_text(u.id))


async def cmd_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    rows = db.q("SELECT * FROM like_logs WHERE actor=? ORDER BY id DESC LIMIT 12", (u.id,))
    out = [f"🧾 <b>{fancy('Your Recent Activity')}</b>", ""]
    for r in rows:
        when = datetime.fromtimestamp(r["created_at"]).strftime("%d %b %Y %H:%M")
        out.append(f"🪪 <b>{r['uid']}</b> • ❤️ <b>{r['given']}</b>")
        out.append(f"📅 {when}")
        out.append("")
    if not rows:
        out.append(f"📭 {fancy('Nothing Here Yet')}")
    await _reply(update, wrap("\n".join(out)))


async def cmd_orderstatus(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    rows = db.q("SELECT * FROM purchases WHERE user_id=? ORDER BY id DESC LIMIT 10", (u.id,))
    out = [f"🧾 <b>{fancy('Your Orders')}</b>", ""]
    for r in rows:
        out.append(f"#️⃣ <b>{r['id']}</b> • {r['status'].upper()}")
        out.append(f"❤️ Lɪᴋᴇꜱ: <b>{r['likes']:,}</b> • 💰 {r['currency']} {r['amount']}")
        out.append("")
    if not rows:
        out.append(f"📭 {fancy('No Orders Yet')}")
    await _reply(update, wrap("\n".join(out)))


def _own_slot(user_id: int, uid: str):
    return db.one("SELECT * FROM autolikes WHERE owner_id=? AND uid=?", (user_id, uid))


async def cmd_stopauto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    args = context.args or []
    if not args:
        return await _reply(update, wrap(f"⚠️ <code>/stopauto 3688500765</code>"))
    if not _own_slot(u.id, args[0]):
        return await _reply(update, wrap(f"❌ <b>{fancy('Slot Not Found On Your Account')}</b>"))
    db.run("UPDATE autolikes SET paused=1 WHERE owner_id=? AND uid=?", (u.id, args[0]))
    await _reply(update, wrap(f"⏸ <b>{fancy('Autolike Paused')}</b> 🪪 <b>{args[0]}</b>"))


async def cmd_startauto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    args = context.args or []
    if not args:
        return await _reply(update, wrap(f"⚠️ <code>/startauto 3688500765</code>"))
    if not _own_slot(u.id, args[0]):
        return await _reply(update, wrap(f"❌ <b>{fancy('Slot Not Found On Your Account')}</b>"))
    db.run("UPDATE autolikes SET paused=0 WHERE owner_id=? AND uid=?", (u.id, args[0]))
    await _reply(update, wrap(f"▶️ <b>{fancy('Autolike Resumed')}</b> 🪪 <b>{args[0]}</b>"))


async def cmd_keyinfo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    args = context.args or []
    if not args:
        return await _reply(update, wrap(f"⚠️ <code>/keyinfo RK-XXXXXXXX</code>"))
    row = db.one("SELECT * FROM keys WHERE code=?", (args[0].upper(),))
    if not row:
        return await _reply(update, wrap(f"❌ <b>{fancy('Key Not Found')}</b>"))
    till = datetime.fromtimestamp(row["expires_at"]).strftime("%d %b %Y") if row["expires_at"] else "—"
    await _reply(update, wrap(
        f"🔑 <b>{fancy('Key Details')}</b>\n\n"
        f"🔐 <code>{row['code']}</code>\n"
        f"❤️ Lᴇꜰᴛ: <b>{row['likes_left']:,}</b>/<b>{row['likes_total']:,}</b>\n"
        f"📅 Vᴀʟɪᴅ Tɪʟʟ: <b>{till}</b>\n"
        f"⚙️ Sᴛᴀᴛᴜꜱ: <b>{'Aᴄᴛɪᴠᴇ' if row['active'] else 'Dɪꜱᴀʙʟᴇᴅ'}</b>"))


async def cmd_splitkey(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await cmd_usekey(update, context)


async def cmd_addfriend(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    args = context.args or []
    uid = args[1] if len(args) > 1 else (args[0] if args else config.FF_PROFILE["uid"])
    region = args[0].upper() if len(args) > 1 and valid_region(args[0].upper()) else "IND"
    link = config.ff_share_link(uid, region)
    await _reply(update, wrap(
        f"🎮 <b>{fancy('In Game Add Friend Link')}</b>\n\n"
        f"🪪 Uɪᴅ: <b>{uid}</b>\n🌍 Rᴇɢɪᴏɴ: <b>{config.region_label(region)}</b>\n\n"
        f"🔗 {link}"),
        M([[B("🎮 Oᴘᴇɴ Iɴ Fʀᴇᴇ Fɪʀᴇ", url=link)], ui.back_row(more="m:more")]))


async def cmd_ffshare(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await cmd_addfriend(update, context)


async def cmd_pay(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, ui.plans_text(), ui.plans_keyboard())


async def cmd_upi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, wrap(
        f"🇮🇳 <b>{fancy('Upi Payment')}</b>\n\n"
        f"💎 {fancy('Pick A Plan First So The Amount And Timer Are Correct')} 👇"), ui.plans_keyboard())


async def cmd_usdt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, wrap(
        f"💵 <b>{fancy('Usdt Payment')}</b>\n\n"
        f"🔗 Nᴇᴛᴡᴏʀᴋ: <b>{config.USDT_NETWORK}</b>\n"
        f"💎 {fancy('Pick A Plan To Get The Address And Timer')} 👇"), ui.plans_keyboard())


async def cmd_stars(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, wrap(
        f"⭐ <b>{fancy('Telegram Stars Checkout')}</b>\n\n"
        f"💎 {fancy('Pick A Plan Then Tap Stars')} 👇"), ui.plans_keyboard())


async def cmd_credits(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    await _reply(update, claim_screen(u.id), ui.refer_menu())


async def cmd_myrefs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    rows = db.q("SELECT invitee, created_at FROM referrals WHERE inviter=? ORDER BY id DESC LIMIT 15", (u.id,))
    out = [f"👥 <b>{fancy('Your Referrals')}</b> ({len(rows)})", ""]
    for r in rows:
        out.append(f"✅ <code>{r['invitee']}</code> • {datetime.fromtimestamp(r['created_at']).strftime('%d %b %Y')}")
    if not rows:
        out.append(f"📭 {fancy('No Referrals Yet')}")
    await _reply(update, wrap("\n".join(out)), ui.refer_menu())


async def cmd_top(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    rows = db.q("SELECT nickname, uid, SUM(given) s FROM like_logs GROUP BY uid ORDER BY s DESC LIMIT 10")
    medals = ["🥇", "🥈", "🥉"] + ["🎖"] * 7
    out = [f"🏆 <b>{fancy('Top Players By Likes')}</b>", ""]
    for i, r in enumerate(rows):
        out.append(f"{medals[i]} <b>{r['nickname'] or r['uid']}</b> — ❤️ {r['s']:,}")
    if not rows:
        out.append(f"📭 {fancy('No Data Yet')}")
    await _reply(update, wrap("\n".join(out)))


async def cmd_runs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    times = db.get_json("run_times", ["04:00"])
    await _reply(update, wrap(
        f"⏰ <b>{fancy('Autolike Run Times')}</b>\n\n"
        f"🔁 Rᴜɴꜱ Pᴇʀ Dᴀʏ: <b>{db.get_setting('runs_per_day', '1')}</b>\n"
        f"🕐 Tɪᴍᴇꜱ: <b>{', '.join(times)}</b> (Iꜱᴛ)\n"
        f"📈 Mᴀxɪᴍᴜᴍ: <b>{config.MAX_AUTOLIKE_RUNS}</b> Pᴇʀ Dᴀʏ"))


async def cmd_faq(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, wrap(
        f"❓ <b>{fancy('Common Questions')}</b>\n\n"
        f"🔹 Iꜱ Iᴛ Sᴀꜰᴇ: <b>Yᴇꜱ, Oɴʟʏ Yᴏᴜʀ Uɪᴅ Iꜱ Nᴇᴇᴅᴇᴅ</b>\n"
        f"🔹 Dᴇʟɪᴠᴇʀʏ: <b>Wɪᴛʜɪɴ Mɪɴᴜᴛᴇꜱ</b>\n"
        f"🔹 Aᴜᴛᴏʟɪᴋᴇ Rᴜɴꜱ: <b>Uᴘ Tᴏ {config.MAX_AUTOLIKE_RUNS} Pᴇʀ Dᴀʏ</b>\n"
        f"🔹 Fʀᴇᴇ Lɪᴋᴇꜱ: <b>{config.CREDIT_REDEEM_UNIT} Cʀᴇᴅɪᴛꜱ = {config.LIKES_PER_CREDIT_UNIT:,} Lɪᴋᴇꜱ</b>\n"
        f"🔹 Sᴜᴘᴘᴏʀᴛ: <b>{config.OWNER_HANDLE}</b>"))


async def cmd_rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, wrap(
        f"📜 <b>{fancy('Service Rules')}</b>\n\n"
        f"🔹 Oɴᴇ Fʀᴇᴇ Lɪᴋᴇ Rᴇǫᴜᴇꜱᴛ Eᴠᴇʀʏ <b>{config.USER_LIKE_COOLDOWN_HOURS}ʜ</b>\n"
        f"🔹 Nᴏ Fᴀᴋᴇ Aᴄᴄᴏᴜɴᴛꜱ Fᴏʀ Rᴇꜰᴇʀʀᴀʟꜱ\n"
        f"🔹 Sᴇɴᴅ Rᴇᴀʟ Pᴀʏᴍᴇɴᴛ Pʀᴏᴏꜰ Oɴʟʏ\n"
        f"🔹 Aʙᴜꜱᴇ Mᴇᴀɴꜱ A Pᴇʀᴍᴀɴᴇɴᴛ Bᴀɴ"))


async def cmd_terms(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, wrap(
        f"📄 <b>{fancy('Terms Of Use')}</b>\n\n"
        f"🔹 Lɪᴋᴇꜱ Aʀᴇ Dᴇʟɪᴠᴇʀᴇᴅ Bʏ Pᴜʙʟɪᴄ Gᴀᴍᴇ Aᴘɪꜱ\n"
        f"🔹 Dᴇʟɪᴠᴇʀʏ Dᴇᴘᴇɴᴅꜱ Oɴ Dᴀɪʟʏ Gᴀᴍᴇ Lɪᴍɪᴛꜱ\n"
        f"🔹 Nᴏ Aᴄᴄᴏᴜɴᴛ Lᴏɢɪɴ Oʀ Pᴀꜱꜱᴡᴏʀᴅ Iꜱ Eᴠᴇʀ Aꜱᴋᴇᴅ"))


async def cmd_privacy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, wrap(
        f"🔒 <b>{fancy('Privacy Note')}</b>\n\n"
        f"🔹 Wᴇ Sᴛᴏʀᴇ Oɴʟʏ Yᴏᴜʀ Tᴇʟᴇɢʀᴀᴍ Iᴅ, Nᴀᴍᴇ Aɴᴅ Oʀᴅᴇʀꜱ\n"
        f"🔹 Nᴏ Pᴀꜱꜱᴡᴏʀᴅꜱ, Nᴏ Pᴀʏᴍᴇɴᴛ Cᴀʀᴅꜱ\n"
        f"🔹 Dᴇʟᴇᴛɪᴏɴ Oɴ Rᴇǫᴜᴇꜱᴛ Vɪᴀ {config.OWNER_HANDLE}"))


async def cmd_refund(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, wrap(
        f"🛡 <b>{fancy('Refund Policy')}</b>\n\n"
        f"🔹 Nᴏᴛ Dᴇʟɪᴠᴇʀᴇᴅ ➜ Fᴜʟʟ Rᴇꜰᴜɴᴅ Oʀ Rᴇ Dᴇʟɪᴠᴇʀʏ\n"
        f"🔹 Sʜᴀʀᴇ Yᴏᴜʀ Oʀᴅᴇʀ Iᴅ Aɴᴅ Txɴ Iᴅ Wɪᴛʜ {config.OWNER_HANDLE}"))


async def cmd_speed(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, wrap(
        f"⚡ <b>{fancy('Delivery Speed')}</b>\n\n"
        f"🔹 Fɪʀꜱᴛ Lɪᴋᴇꜱ: <b>Uɴᴅᴇʀ A Mɪɴᴜᴛᴇ</b>\n"
        f"🔹 Aᴜᴛᴏʟɪᴋᴇ: <b>Uᴘ Tᴏ {config.MAX_AUTOLIKE_RUNS} Rᴜɴꜱ Dᴀɪʟʏ</b>"))


async def cmd_ping(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    t0 = time.time()
    msg = await update.message.reply_text("🏓 ...")
    await msg.edit_text(wrap(f"🏓 <b>{fancy('Pong')}</b>\n⚡ {(time.time()-t0)*1000:.0f}ᴍꜱ"),
                        parse_mode=ParseMode.HTML)


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    t = db.totals()
    await _reply(update, wrap(
        f"📡 <b>{fancy('Service Status')}</b>\n\n"
        f"🟢 Bᴏᴛ: <b>Oɴʟɪɴᴇ</b>\n"
        f"🟢 Aᴜᴛᴏʟɪᴋᴇ Eɴɢɪɴᴇ: <b>Rᴜɴɴɪɴɢ</b>\n"
        f"👥 Uꜱᴇʀꜱ: <b>{t['users']}</b>\n"
        f"❤️ Lɪᴋᴇꜱ Dᴇʟɪᴠᴇʀᴇᴅ: <b>{t['likes_sent']:,}</b>"))


async def cmd_uptime(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    s = int(time.time() - START_TIME)
    await _reply(update, wrap(
        f"⏱ <b>{fancy('Bot Uptime')}</b>\n🕐 <b>{s//3600}ʜ {(s%3600)//60}ᴍ {s%60}ꜱ</b>"))


async def cmd_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    await _reply(update, wrap(
        f"🪪 <b>{fancy('Your Telegram Id')}</b>\n\n"
        f"🆔 <code>{u.id}</code>\n"
        f"👤 Nᴀᴍᴇ: <b>{html.escape(u.first_name or 'Player')}</b>\n"
        f"🔗 Uꜱᴇʀɴᴀᴍᴇ: <b>@{u.username or '—'}</b>"))


async def cmd_me(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = touch_user(update)
    await _reply(update, balance_text(u.id))


async def cmd_dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, wrap(
        f"🌐 <b>{fancy('Web Dashboard')}</b>\n\n"
        f"🔑 {fancy('Login With Your Purchase Key To Manage Autolike')}\n"
        f"🔗 {config.PUBLIC_URL}"),
        M([[B("🌐 Oᴘᴇɴ Wᴇʙꜱɪᴛᴇ", url=config.PUBLIC_URL)], ui.back_row(more="m:more")]))


async def cmd_version(update: Update, context: ContextTypes.DEFAULT_TYPE):
    touch_user(update)
    await _reply(update, wrap(
        f"🧬 <b>{fancy('Bot Version')}</b>\n\n"
        f"🔖 Rᴇʟᴇᴀꜱᴇ: <b>ROCKS AUTOLIKES v5</b>\n"
        f"📡 Sᴏᴜʀᴄᴇ Sᴇᴛ: <b>{config.LIKE_API_REVISION}</b>\n"
        f"🔁 Rᴜɴꜱ Pᴇʀ Dᴀʏ: <b>Uᴘ Tᴏ {config.MAX_AUTOLIKE_RUNS}</b>"))


# ─────────────────────── EXTRA ADMIN COMMANDS ───────────────────────
async def cmd_delkey(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return
    db.run("UPDATE keys SET active=0 WHERE code=?", (context.args[0].upper(),))
    await _reply(update, wrap(f"🚫 <b>{fancy('Key Disabled')}</b> 🔑"))


async def cmd_reject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return
    oid = int(context.args[0])
    db.run("UPDATE purchases SET status='rejected' WHERE id=?", (oid,))
    await _reply(update, wrap(f"🚫 <b>{fancy('Order Rejected')}</b> #{oid}"))


async def cmd_addcredits(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or len(context.args or []) < 2:
        return await _reply(update, wrap(f"⚠️ <code>/addcredits 123456789 5</code>"))
    uid, amount = int(context.args[0]), int(context.args[1])
    db.add_credits(uid, amount)
    await _reply(update, wrap(f"✅ <b>{fancy('Credits Added')}</b> 🎟 <b>{amount}</b> ➜ <code>{uid}</code>"))


async def cmd_addlikes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or len(context.args or []) < 2:
        return await _reply(update, wrap(f"⚠️ <code>/addlikes 123456789 5000</code>"))
    uid, amount = int(context.args[0]), int(context.args[1])
    db.add_likes_balance(uid, amount)
    await _reply(update, wrap(f"✅ <b>{fancy('Like Balance Added')}</b> ❤️ <b>{amount:,}</b>"))


async def cmd_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    rows = db.q("SELECT user_id, username, credits, total_likes FROM users ORDER BY joined_at DESC LIMIT 20")
    out = [f"👥 <b>{fancy('Latest Users')}</b>", ""]
    for r in rows:
        out.append(f"👤 @{r['username'] or r['user_id']} • 🎟 {r['credits']} • ❤️ {r['total_likes']:,}")
    await _reply(update, wrap("\n".join(out)))


async def cmd_finduser(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return await _reply(update, wrap(f"⚠️ <code>/finduser rayan</code>"))
    term = context.args[0].lstrip("@")
    rows = db.q("SELECT * FROM users WHERE username LIKE ? OR CAST(user_id AS TEXT)=? LIMIT 10",
                (f"%{term}%", term))
    out = [f"🔎 <b>{fancy('User Search')}</b>", ""]
    for r in rows:
        out.append(f"👤 @{r['username'] or '—'} • 🆔 <code>{r['user_id']}</code>")
        out.append(f"🎟 Cʀᴇᴅɪᴛꜱ: <b>{r['credits']}</b> • ❤️ <b>{r['total_likes']:,}</b>")
        out.append("")
    if not rows:
        out.append(f"📭 {fancy('No Match')}")
    await _reply(update, wrap("\n".join(out)))


async def cmd_backup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    try:
        with open(config.DB_PATH, "rb") as f:
            await update.message.reply_document(InputFile(f, filename="rocks.db"),
                                               caption=wrap(f"💾 <b>{fancy('Database Backup')}</b>"),
                                               parse_mode=ParseMode.HTML)
    except Exception as e:  # noqa: BLE001
        await _reply(update, wrap(f"⚠️ {fancy('Backup Failed')}: {html.escape(str(e))}"))


async def cmd_cleanup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    db.run("DELETE FROM autolikes WHERE likes_left<=0")
    await _reply(update, wrap(f"🧹 <b>{fancy('Finished Slots Removed')}</b> ✅"))


COMMAND_MAP: dict[str, object] = {
    # ── core ──
    "start": cmd_start, "help": cmd_help, "menu": cmd_start, "home": cmd_start,
    "cmds": cmd_cmds, "commands": cmd_cmds, "allcmds": cmd_cmds,
    "about": cmd_about, "app": cmd_app, "miniapp": cmd_app, "website": cmd_app,
    "site": cmd_app, "web": cmd_app,
    # ── plans / buying ──
    "plans": cmd_plans, "buy": cmd_plans, "packages": cmd_plans, "price": cmd_plans,
    "prices": cmd_plans, "shop": cmd_plans, "store": cmd_plans,
    "pay": cmd_pay, "payment": cmd_pay, "upi": cmd_upi, "gpay": cmd_upi,
    "usdt": cmd_usdt, "crypto": cmd_usdt, "stars": cmd_stars, "star": cmd_stars,
    # ── regions / info ──
    "regions": cmd_regions, "servers": cmd_regions, "region": cmd_regions,
    "info": cmd_info, "player": cmd_info, "check": cmd_info, "uid": cmd_info,
    "fullinfo": cmd_fullinfo, "full": cmd_fullinfo, "rawinfo": cmd_fullinfo,
    "allinfo": cmd_fullinfo, "profile": cmd_fullinfo,
    # ── likes ──
    "like": cmd_like, "likes": cmd_like, "sendlike": cmd_like, "boost": cmd_like,
    "speed": cmd_speed,
    # ── autolike ──
    "autolike": cmd_autolike, "auto": cmd_autolike, "daily": cmd_autolike,
    "listauto": cmd_listauto, "myauto": cmd_myauto, "myslots": cmd_myauto,
    "removeauto": cmd_removeauto, "delauto": cmd_removeauto,
    "pause": cmd_pause, "resume": cmd_resume,
    "stopauto": cmd_stopauto, "startauto": cmd_startauto,
    "runs": cmd_runs, "runall": cmd_runall, "setruns": cmd_setruns,
    "history": cmd_history, "log": cmd_history, "mylogs": cmd_history,
    # ── keys ──
    "genkey": cmd_genkey, "usekey": cmd_usekey, "mykeys": cmd_mykeys,
    "keys": cmd_mykeys, "keyinfo": cmd_keyinfo, "splitkey": cmd_splitkey,
    "split": cmd_splitkey, "delkey": cmd_delkey,
    # ── orders ──
    "orders": cmd_orders, "myorders": cmd_orders, "orderstatus": cmd_orderstatus,
    "order": cmd_orderstatus, "approve": cmd_approve, "reject": cmd_reject,
    # ── referral / credits ──
    "refer": cmd_refer, "referral": cmd_refer, "invite": cmd_refer,
    "myrefs": cmd_myrefs, "refs": cmd_myrefs, "credits": cmd_credits,
    "balance": cmd_balance, "wallet": cmd_balance, "redeem": cmd_redeem,
    "claim": cmd_claim, "code": cmd_code, "gift": cmd_code,
    # ── social / services ──
    "services": cmd_services, "more": cmd_services, "ffservices": cmd_services,
    "addfriend": cmd_addfriend, "friend": cmd_addfriend, "ffshare": cmd_ffshare,
    "share": cmd_ffshare, "top": cmd_top, "leaderboard": cmd_top,
    # ── help pages ──
    "faq": cmd_faq, "rules": cmd_rules, "terms": cmd_terms, "tos": cmd_terms,
    "privacy": cmd_privacy, "refund": cmd_refund, "support": cmd_about,
    "owner": cmd_about, "contact": cmd_about,
    # ── diagnostics ──
    "ping": cmd_ping, "status": cmd_status, "uptime": cmd_uptime,
    "id": cmd_id, "myid": cmd_id, "me": cmd_me, "mystats": cmd_mystats,
    "version": cmd_version, "ver": cmd_version,
    # ── admin ──
    "panel": cmd_panel, "admin": cmd_panel, "dashboard": cmd_dashboard,
    "dash": cmd_dashboard, "stats_all": cmd_stats, "gstats": cmd_stats,
    "analytics": cmd_analytics, "graph": cmd_analytics,
    "addapi": cmd_addapi, "delapi": cmd_delapi, "listapi": cmd_listapi,
    "addgroup": cmd_addgroup, "bindlog": cmd_bindlog, "broadcast": cmd_broadcast,
    "ban": cmd_ban, "unban": cmd_unban, "addcredits": cmd_addcredits,
    "addlikes": cmd_addlikes, "users": cmd_users, "userlist": cmd_users,
    "finduser": cmd_finduser, "search": cmd_finduser, "backup": cmd_backup,
    "cleanup": cmd_cleanup,
}
COMMAND_MAP["stats"] = cmd_stats


def build_app() -> Application:

    if not config.BOT_TOKEN:
        raise SystemExit("❌ TELEGRAM_BOT_TOKEN env var is missing")
    db.init()
    app = Application.builder().token(config.BOT_TOKEN).concurrent_updates(True).build()
    add = app.add_handler
    for name, fn in COMMAND_MAP.items():
        add(CommandHandler(name, fn))
    log.info("registered %s commands", len(COMMAND_MAP))
    add(CallbackQueryHandler(on_callback))
    add(PreCheckoutQueryHandler(precheckout))
    add(MessageHandler(filters.SUCCESSFUL_PAYMENT, on_successful_payment))
    add(MessageHandler((filters.TEXT | filters.PHOTO) & ~filters.COMMAND, on_text))
    app.add_error_handler(on_error)
    app.post_init = _post_init
    return app



async def _post_init(app: Application):
    schedule_jobs(app)
    log.info("🔥 ROCKS AUTOLIKES bot online as @%s", app.bot.username)


def main():
    app = build_app()
    app.run_polling(drop_pending_updates=True, close_loop=False)


if __name__ == "__main__":
    main()
