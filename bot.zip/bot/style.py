"""ROCKS AUTOLIKES — text styling engine.

Rules (from the owner):
  • Every word must be written like  Rᴀʏᴀɴ  → first letter normal CAPITAL,
    every remaining letter in SMALL-CAPS unicode.
  • Every small-caps  n  must be rendered as  ᴎ  (capital N is untouched).
  • No premium/custom emojis anywhere — normal emojis only, used a lot.
"""

SMALL_CAPS = {
    "a": "ᴀ", "b": "ʙ", "c": "ᴄ", "d": "ᴅ", "e": "ᴇ", "f": "ꜰ", "g": "ɢ",
    "h": "ʜ", "i": "ɪ", "j": "ᴊ", "k": "ᴋ", "l": "ʟ", "m": "ᴍ", "n": "ᴎ",
    "o": "ᴏ", "p": "ᴘ", "q": "ǫ", "r": "ʀ", "s": "ꜱ", "t": "ᴛ", "u": "ᴜ",
    "v": "ᴠ", "w": "ᴡ", "x": "x", "y": "ʏ", "z": "ᴢ",
}

# characters that must never be transformed (urls / handles / ids)
_SKIP_PREFIX = ("http://", "https://", "@", "t.me", "/", "#", "0x")


def _word(word: str) -> str:
    if not word:
        return word
    if word.lower().startswith(_SKIP_PREFIX) or any(ch.isdigit() for ch in word):
        return word
    out = []
    first_done = False
    for ch in word:
        if ch.isalpha():
            if not first_done:
                out.append(ch.upper())
                first_done = True
            else:
                out.append(SMALL_CAPS.get(ch.lower(), ch))
        else:
            out.append(ch)
    return "".join(out)


def fancy(text: str) -> str:
    """Apply the Rᴀʏᴀɴ font rule to a whole block of text, line by line."""
    if not text:
        return text
    lines = []
    for line in text.split("\n"):
        lines.append(" ".join(_word(w) for w in line.split(" ")))
    return "\n".join(lines)


def bold(text: str) -> str:
    return f"<b>{text}</b>"


LINE = "━━━━━━━━━━━━━━━━━━━━━━"
SHORT_LINE = "━━━━━━━━━"
OWNER_HANDLE = "@rockschatbot"

HEADER = (
    f"{LINE}\n"
    f"🚨 {fancy('Free Fire Services Available')}:\n"
    f"{LINE}"
)

FOOTER = (
    f"{LINE}\n"
    f"👑 {fancy('Owner')}: {OWNER_HANDLE}\n"
    f"{LINE}"
)

SUPPORT_FOOTER = (
    f"{LINE}\n"
    f"📩 Support: {OWNER_HANDLE}\n"
    f"{LINE}"
)


def wrap(body: str, header: bool = False) -> str:
    """Wrap a message body with the mandatory footer (and optional header)."""
    parts = []
    if header:
        parts.append(HEADER)
    parts.append(body.strip())
    parts.append(FOOTER)
    return "<b>" + "\n\n".join(parts) + "</b>"


def wrap_support(body: str, title: str = "") -> str:
    """Top rule + title + bottom support footer (the likes result card)."""
    parts = []
    if title:
        parts.append(f"{LINE}\n{title}\n{LINE}")
    parts.append(body.strip())
    parts.append(SUPPORT_FOOTER)
    return "<b>" + "\n\n".join(parts) + "</b>"


def spoiler(text: str) -> str:
    """Telegram spoiler — tap to reveal, still copyable."""
    return f"<tg-spoiler>{text}</tg-spoiler>"


def progress_bar(pct: float, width: int = 12) -> str:
    pct = max(0.0, min(100.0, float(pct)))
    filled = int(round(width * pct / 100.0))
    return "▰" * filled + "▱" * (width - filled) + f"  {pct:.0f}%"

