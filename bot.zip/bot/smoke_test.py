"""ROCKS AUTOLIKES — smoke test (syntax + website endpoints).

Runs against a throwaway database in a temp folder, so the real data is never touched.

    python smoke_test.py
"""
from __future__ import annotations

import compileall
import os
import sys
import tempfile

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

_TMP = tempfile.mkdtemp(prefix="rocks-smoke-")
os.environ["ROCKS_DB"] = os.path.join(_TMP, "smoke.db")
os.environ.setdefault("TELEGRAM_BOT_TOKEN", "")

FAILS: list[str] = []


def check(name: str, cond: bool, extra: str = "") -> None:
    print(f"  {'✅' if cond else '❌'} {name}{(' — ' + extra) if extra else ''}")
    if not cond:
        FAILS.append(name)


def main() -> int:
    print("\n🧪 1/4  byte-compiling every python file")
    ok = compileall.compile_dir(BASE, quiet=1, force=True)
    check("all python files compile", bool(ok))

    print("\n🧪 2/4  importing modules")
    import config  # noqa: F401
    import db
    import likes  # noqa: F401
    import style  # noqa: F401
    import ui  # noqa: F401
    import webapp

    db.init()
    check("modules import", True)
    check("static assets present", all(
        os.path.exists(os.path.join(BASE, "static", f))
        for f in ("banner.jpg", "qr_upi.jpg", "qr_usdt.jpg", "qr_ff.jpg", "qr_ig.jpg", "qr_tg.jpg", "qr_yt.jpg")
    ))

    print("\n🧪 3/4  public endpoints")
    app = webapp.create_app()
    app.config["TESTING"] = True
    c = app.test_client()

    for path in ("/", "/app", "/miniapp", "/health", "/robots.txt",
                 "/api/public/config", "/api/public/stats", "/api/public/buyers"):
        r = c.get(path)
        check(f"GET {path} → 200", r.status_code == 200, str(r.status_code))

    home = c.get("/").get_data(as_text=True)
    check("mini app renders boot payload", "ROCKS AUTOLIKES" in home and "regions" in home)
    check("mini app has all 5 tabs", all(t in home for t in ("Home", "Check", "Buy", "Refer", "About")))

    r = c.post("/api/public/chat", json={"message": "how to buy"})
    check("chatbot replies", r.status_code == 200 and bool(r.get_json().get("reply")))

    r = c.get("/api/public/info?uid=abc&region=IND")
    check("bad uid rejected → 400", r.status_code == 400, str(r.status_code))
    r = c.get("/api/public/info?uid=3688500765&region=XX")
    check("bad region rejected → 400", r.status_code == 400, str(r.status_code))
    r = c.get("/api/public/info?uid=1' OR '1'='1&region=IND")
    check("sqli attempt rejected", r.status_code == 400, str(r.status_code))

    print("\n🧪 4/4  owner dashboard gate")
    r = c.get("/api/dash/tables")
    check("dashboard without token → 401", r.status_code == 401, str(r.status_code))
    r = c.post("/api/dash/login", json={"pass1": "nope", "pass2": "nope"})
    check("wrong passwords → 401", r.status_code == 401, str(r.status_code))
    r = c.post("/api/dash/login", json={"pass1": config.DASH_PASS_1, "pass2": config.DASH_PASS_2})
    tok = (r.get_json() or {}).get("token", "")
    check("correct passwords issue a token", r.status_code == 200 and bool(tok))
    r = c.get("/api/dash/analytics?range=month", headers={"X-Dash-Token": tok})
    check("analytics with token → 200", r.status_code == 200, str(r.status_code))
    r = c.get("/api/dash/tables", headers={"X-Dash-Token": tok})
    check("tables with token → 200", r.status_code == 200, str(r.status_code))

    print()
    if FAILS:
        print(f"❌ {len(FAILS)} check(s) failed: {', '.join(FAILS)}\n")
        return 1
    print("🎉 ALL CHECKS PASSED — bot + website are ready to deploy\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
